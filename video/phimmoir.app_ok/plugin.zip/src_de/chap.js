load("config.js");

function execute(url) {
    // URL format: https://phimmoie.io/phim/<slug>-<id> (or /xem-phim/...)
    var parts = url.split("/");
    var epSlug = parts[parts.length - 1];
    var slug = parts[parts.length - 2];

    Console.log("chap.v4 url=" + url + " epSlug=" + epSlug + " slug=" + slug);

    // 1. Fetch page via Engine (Next.js SPA)
    var html = "";
    try {
        var browser = Engine.newBrowser();
        browser.setUserAgent(UserAgent.android());
        browser.launch(url, 15000);
        html = browser.html().html();
        browser.close();
    } catch (e) {
        Console.log("chap.v4 browser error: " + e);
    }
    if (!html) {
        html = fetchText(url);
    }
    if (!html) return Response.error("Cannot load page.");
    Console.log("chap.v4 html length=" + html.length);

    // 2. Collect __next_f payloads and unescape
    var allData = "";
    var rscParts = html.split('self.__next_f.push([1,"');
    for (var i = 1; i < rscParts.length; i++) {
        var endIdx = rscParts[i].lastIndexOf("\n]");
        if (endIdx === -1) {
            endIdx = rscParts[i].lastIndexOf("])");
            if (endIdx === -1) endIdx = rscParts[i].length;
        }
        var payload = rscParts[i].substring(0, endIdx);
        allData += payload.replace(/\\"/g, '"');
    }
    Console.log("chap.v4 allData length=" + allData.length);

    // 3. Find episodes array containing epSlug
    var tracks = [];
    var seen = {};

    var searchPos = 0;
    while (true) {
        var epKeyIdx = allData.indexOf('"episodes":[', searchPos);
        if (epKeyIdx === -1) break;
        var bracketStart = epKeyIdx + '"episodes":['.length - 1;

        // String-aware bracket scanner
        var depth = 1;
        var end = -1;
        var inStr = false;
        for (var j = bracketStart + 1; j < allData.length; j++) {
            var c = allData.charAt(j);
            if (inStr) {
                if (c === '"') { inStr = false; }
                else if (c === '\\') { j++; }
            } else {
                if (c === '"') { inStr = true; }
                else if (c === '[') { depth++; }
                else if (c === ']') { depth--; if (depth === 0) { end = j + 1; break; } }
            }
        }
        if (end === -1) { searchPos = epKeyIdx + 1; continue; }

        var epJson = allData.substring(bracketStart, end);
        searchPos = end;
        try {
            var arr = JSON.parse(epJson);
            Console.log("chap.v4 parsed " + (arr ? arr.length : 0) + " episodes");
            if (!arr || arr.length === 0) continue;
            for (var k = 0; k < arr.length; k++) {
                var ep = arr[k];
                if (!ep.link) continue;
                var matchSlug = (ep.slug || ep.name || "");
                Console.log("chap.v4 ep=" + ep.name + " slug=" + ep.slug + " epSlug=" + epSlug);
                if (epSlug && matchSlug.indexOf(epSlug) !== -1) {
                    var key = ep.link;
                    if (seen[key]) continue;
                    seen[key] = true;
                    tracks.push({
                        title: ep.server || ("Server " + (tracks.length + 1)),
                        data: ep.link,
                        type: ep.type || "m3u8"
                    });
                    Console.log("chap.v4 MATCH link=" + ep.link + " type=" + ep.type);
                }
            }
        } catch (e) {
            Console.log("chap.v4 parse error: " + e);
        }
    }

    // 4. Fallback: extract m3u8 from raw HTML
    if (tracks.length === 0) {
        Console.log("chap.v4 fallback to m3u8 regex");
        var linkPattern = /https?:\/\/[^\s"'<>\\]+\.m3u8[^\s"'<>\\]*/gi;
        var linkMatch;
        while ((linkMatch = linkPattern.exec(html)) !== null) {
            var link = linkMatch[0];
            if (seen[link]) continue;
            seen[link] = true;
            tracks.push({
                title: "Stream M3U8",
                data: link,
                type: "m3u8"
            });
        }
    }

    // 5. JSON-LD fallback
    if (tracks.length === 0) {
        Console.log("chap.v4 json-ld fallback");
        var ldRe = /"contentUrl"\s*:\s*"([^"]+)"/g;
        var lm;
        while ((lm = ldRe.exec(html)) !== null) {
            var link = lm[1];
            if (!seen[link]) {
                seen[link] = true;
                tracks.push({ title: "Stream", data: link, type: "m3u8" });
            }
        }
    }

    Console.log("chap.v4 tracks=" + tracks.length);
    if (tracks.length === 0) return Response.error("No streaming source found.");
    return Response.success(tracks);
}
