﻿load('config.js');

function execute(url) {
    var isExternalEmbed = url.indexOf('http') === 0 && url.indexOf(BASE_URL.replace('https://', '').replace('http://', '')) === -1;

    // Direct m3u8/mp4 stream — pass through with auto type
    var isDirectStream = url.indexOf('.m3u8') >= 0 || url.indexOf('.mpd') >= 0 || url.indexOf('.mp4') >= 0 || url.indexOf('.webm') >= 0;
    if (isDirectStream) {
        Console.log("track.v3 direct stream: " + url);
        return Response.success({
            data: url,
            type: 'auto',
            headers: { 
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36',
                'Referer': BASE_URL + '/'
            },
            host: BASE_URL,
            timeSkip: []
        });
    }

    if (isExternalEmbed || url.indexOf('embed') >= 0 || url.indexOf('player') >= 0) {
        try {
            var browser = Engine.newBrowser();
            browser.setUserAgent(UserAgent.android());
            var doc = browser.launch(url, 15000);

            var tracks = [];
            doc.select('iframe[src]').forEach(function (iframe) {
                var src = iframe.attr('src');
                if (src) tracks.push({ title: 'Nested Player', data: src, type: 'embed' });
            });

            var html = browser.html().html();
            if (html) {
                var m3u8Re = /https?:\/\/[^"'<>\\s]+\.m3u8[^"'<>\\s]*/gi;
                var m;
                while ((m = m3u8Re.exec(html)) !== null) {
                    tracks.push({ title: 'Stream M3U8', data: m[0], type: 'm3u8' });
                }
                // Also find mp4 sources
                var mp4Re = /https?:\/\/[^"'<>\\s]+\.mp4[^"'<>\\s]*/gi;
                while ((m = mp4Re.exec(html)) !== null) {
                    tracks.push({ title: 'Stream MP4', data: m[0], type: 'mp4' });
                }
            }
            browser.close();

            if (tracks.length > 0) {
                return Response.success({
                    data: tracks[0].data,
                    type: tracks[0].type === 'm3u8' ? 'auto' : tracks[0].type,
                    headers: { 
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                        'Referer': url
                    },
                    host: BASE_URL,
                    timeSkip: []
                });
            }
        } catch (e) { }
    }

    return Response.success({
        data: url,
        type: 'auto',
        headers: { 'Referer': BASE_URL + '/' },
        host: BASE_URL,
        timeSkip: []
    });
}
