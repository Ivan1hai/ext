load("config.js");

function execute(url, page) {
    if (!page) page = "1";

    var pageUrl = url;
    pageUrl = pageUrl.replace(/[?&]page=\d+/, "");
    if (page !== "1") {
        pageUrl = pageUrl + (pageUrl.indexOf("?") === -1 ? "?page=" : "&page=") + page;
    }

    var doc = fetchDoc(pageUrl);
    var list = [];
    var next = null;

    if (doc) {
        list = extractMoviesFromDoc(doc);
        if (!list || list.length === 0) {
            var pageText = doc.text();
            if (pageText) {
                list = extractMoviesFromText(pageText);
            }
        }
        var pt = doc.text();
        if (pt) {
            next = findNextPage(pt, page);
        }
    }

    // If doc failed or list empty, try direct text fetch
    if (!list || list.length === 0) {
        var text = fetchText(pageUrl);
        if (text) {
            list = extractMoviesFromText(text);
            if (!next) {
                next = findNextPage(text, page);
            }
        }
    }

    return Response.success(list, next);
}