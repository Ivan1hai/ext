load("config.js");

function execute(url) {
    // URL format: https://phimmoie.io/phim/<slug>-<id>
    var pathParts = url.split("/");
    var lastPart = pathParts[pathParts.length - 1];
    var slug = lastPart; // e.g. phat-sung-cuoi-cung-phan-4-1786923006

    // Use fetchDoc for JSON-LD parsing (in <script> tags)
    var doc = fetchDoc(BASE_URL + "/phim/" + slug);
    var text = fetchText(BASE_URL + "/phim/" + slug);

    var name = "";
    var altName = "";
    var cover = "";
    var description = "";
    var genres = [];
    var country = "";
    var ongoing = true;
    var epStatus = "";

    // 1. Parse JSON-LD from <script> tags (doc can parse these)
    if (doc) {
        doc.select("script[type=application/ld+json]").forEach(function (script) {
            try {
                var ld = JSON.parse(script.text() || "{}");
                // Handle both @graph array and direct object
                var items = ld["@graph"] || [ld];
                if (!Array.isArray(items)) items = [ld];

                for (var i = 0; i < items.length; i++) {
                    var item = items[i];
                    var type = item["@type"] || "";
                    if (type === "TVSeries" || type === "Movie" || type === "WebSeries") {
                        if (item.name) name = item.name;
                        if (item.alternateName) altName = item.alternateName;
                        if (item.description) description = item.description;
                        if (item.image) cover = item.image;
                        if (item.thumbnailUrl && !cover) cover = item.thumbnailUrl;
                        if (item.genre) genres = Array.isArray(item.genre) ? item.genre : [item.genre];
                        if (item.countryOfOrigin && item.countryOfOrigin.length > 0) {
                            country = item.countryOfOrigin[0].name || "";
                        }
                        if (item.aggregateRating && item.aggregateRating.ratingValue) {
                            epStatus = (epStatus ? epStatus + " | " : "") + "Rating: " + item.aggregateRating.ratingValue + "/10";
                        }
                    }
                }
            } catch (e) { }
        });
    }

    // 2. Fallback: regex from raw text for escaped JSON
    if (!name && text) {
        var escapedSlug = slug.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        var nameRe = new RegExp('\\\\"name\\\\":\\\\"([^\\\\]+)\\\\",\\\\"origin_name\\\\":\\\\"[^\\\\]*\\\\",\\\\"slug\\\\":\\\\"' + escapedSlug + '\\\\"');
        var nm = nameRe.exec(text);
        if (nm) name = nm[1];
    }

    // 3. Get cover + status from embedded data
    if (text) {
        var escapedSlug = slug.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        var dataRe = new RegExp('\\\\"slug\\\\":\\\\"' + escapedSlug + '\\\\",\\\\"thumb_url\\\\":\\\\"([^\\\\]*)\\\\",\\\\"poster_url\\\\":\\\\"([^\\\\]*)\\\\",\\\\"type\\\\":\\\\"([^\\\\]*)\\\\",\\\\"status\\\\":\\\\"([^\\\\]*)\\\\"');
        var dm = dataRe.exec(text);
        if (dm) {
            if (!cover) cover = toAbsolute(dm[2] || dm[1]);
            ongoing = dm[4] !== "completed";
            if (!epStatus) epStatus = dm[4];
        }

        // episode_current
        var epRe = new RegExp('\\\\"slug\\\\":\\\\"' + escapedSlug + '\\\\"[^}]*\\\\"episode_current\\\\":\\\\"([^\\\\]*)\\\\"');
        var em = epRe.exec(text);
        if (em && em[1]) epStatus = em[1];

        // description
        if (!description) {
            var descRe = new RegExp('\\\\"slug\\\\":\\\\"' + escapedSlug + '\\\\".*?\\\\"description\\\\":\\\\"([^\\\\]*?)\\\\"');
            var dsm = descRe.exec(text);
            if (dsm && dsm[1]) description = dsm[1];
        }
    }

    // Build info detail
    var info = [];
    if (altName) info.push("Tên khác: " + altName);
    if (country) info.push("Quốc gia: " + country);
    if (epStatus) info.push("Tình trạng: " + epStatus);

    return Response.success({
        name: name || slug,
        cover: cover,
        author: "Phimmoir",
        description: description,
        detail: info.join("<br>"),
        ongoing: ongoing,
        genres: genres,
        format: "series",
        host: BASE_URL
    });
}