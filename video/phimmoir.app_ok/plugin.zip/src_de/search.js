load("config.js");

function execute(key, page) {
    var q = ("" + key).trim();
    if (!q) return Response.success([]);

    // Site search endpoint (Next.js SSR): /search?q=<keyword>
    var url = BASE_URL + "/search?q=" + encodeURIComponent(q);

    // Cheap plain fetch first
    var html = fetchText(url);

    // Fallback to a rendered browser if the fetch was blocked / empty
    if (!html || html.indexOf("w-full lg:w-3/4") === -1) {
        try {
            var browser = Engine.newBrowser();
            browser.setUserAgent(UserAgent.android());
            browser.launch(url, 15000);
            html = browser.html().html();
            browser.close();
        } catch (e) { }
    }
    if (!html) return Response.success([]);

    var list = extractSearchResults(html);
    Console.log("search.v1 q=" + q + " results=" + list.length);

    // Site search has no working pagination (the page param is ignored) -> no next page
    return Response.success(list, null);
}
