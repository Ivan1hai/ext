load("config.js");

function execute() {
    // Categories extracted from actual site data
    var theloai = [
        { name: "Hành Động", slug: "hanh-dong" },
        { name: "Cổ Trang", slug: "co-trang" },
        { name: "Chiến Tranh", slug: "chien-tranh" },
        { name: "Viễn Tưởng", slug: "vien-tuong" },
        { name: "Kinh Dị", slug: "kinh-di" },
        { name: "Tài Liệu", slug: "tai-lieu" },
        { name: "Bí Ẩn", slug: "bi-an" },
        { name: "Tình Cảm", slug: "tinh-cam" },
        { name: "Tâm Lý", slug: "tam-ly" },
        { name: "Thể Thao", slug: "the-thao" },
        { name: "Phiêu Lưu", slug: "phieu-luu" },
        { name: "Âm Nhạc", slug: "am-nhac" },
        { name: "Gia Đình", slug: "gia-dinh" },
        { name: "Học Đường", slug: "hoc-duong" },
        { name: "Hài Hước", slug: "hai-huoc" },
        { name: "Hình Sự", slug: "hinh-su" },
        { name: "Võ Thuật", slug: "vo-thuat" },
        { name: "Khoa Học", slug: "khoa-hoc" },
        { name: "Thần Thoại", slug: "than-thoai" },
        { name: "Chính Kịch", slug: "chinh-kich" },
        { name: "Kinh Điển", slug: "kinh-dien" },
        { name: "Hoạt Hình", slug: "hoat-hinh" },
    ];

    var quocgia = [
        { name: "Trung Quốc", slug: "trung-quoc" },
        { name: "Thái Lan", slug: "thai-lan" },
        { name: "Hồng Kông", slug: "hong-kong" },
        { name: "Pháp", slug: "phap" },
        { name: "Đức", slug: "duc" },
        { name: "Hàn Quốc", slug: "han-quoc" },
        { name: "Âu Mỹ", slug: "au-my" },
        { name: "Ấn Độ", slug: "an-do" },
        { name: "Canada", slug: "canada" },
        { name: "Tây Ban Nha", slug: "tay-ban-nha" },
        { name: "Indonesia", slug: "indonesia" },
        { name: "Nhật Bản", slug: "nhat-ban" },
        { name: "Đài Loan", slug: "dai-loan" },
        { name: "Anh", slug: "anh" },
        { name: "Nga", slug: "nga" },
        { name: "Úc", slug: "uc" },
        { name: "Brazil", slug: "brazil" },
        { name: "Ý", slug: "y" },
        { name: "Việt Nam", slug: "viet-nam" },
        { name: "Quốc Gia Khác", slug: "quoc-gia-khac" }
    ];

    var result = [];

    for (var i = 0; i < theloai.length; i++) {
        result.push({
            title: "Thể loại: " + theloai[i].name,
            input: BASE_URL + "/the-loai/" + theloai[i].slug + "?page=1",
            script: "gen.js"
        });
    }

    for (var j = 0; j < quocgia.length; j++) {
        result.push({
            title: "Quốc gia: " + quocgia[j].name,
            input: BASE_URL + "/quoc-gia/" + quocgia[j].slug + "?page=1",
            script: "gen.js"
        });
    }

    return Response.success(result);
}