load("config.js");

function execute(url) {
    // URL format: https://phimmoie.io/phim/<slug>
    var slug = url.split("/").pop();
    if (!slug) return Response.error("Invalid URL");

    Console.log("toc.v4 slug=" + slug);

    // 1. Fetch detail page (Next.js SPA — use Engine for CF)
    var html = "";
    try {
        var browser = Engine.newBrowser();
        browser.setUserAgent(UserAgent.android());
        var doc = browser.launch(url, 15000);
        html = browser.html().html();
        browser.close();
    } catch (e) {
        Console.log("toc.v4 browser error: " + e);
    }

    if (!html || html.length < 100) {
        Console.log("toc.v4 fallback to fetchText");
        html = fetchText(url);
    }
    if (!html) return Response.error("Cannot load page.");
    Console.log("toc.v4 html length=" + html.length);

    // 2. Collect all __next_f RSC payloads and unescape
    var allData = "";
    var parts = html.split('self.__next_f.push([1,"');
    Console.log("toc.v4 rsc parts=" + parts.length);
    for (var i = 1; i < parts.length; i++) {
        // Raw payload ends with \n"])" (newline + quote + ] + ) + possibly \n)
        // Find the closing ]) after the last " in this chunk
        var endIdx = parts[i].lastIndexOf("\n]");
        if (endIdx === -1) {
            endIdx = parts[i].lastIndexOf("])");
            if (endIdx === -1) endIdx = parts[i].length;
        }
        var payload = parts[i].substring(0, endIdx);
        // Unescape: \" (backslash+quote) -> " 
        allData += payload.replace(/\\"/g, '"');
    }
    Console.log("toc.v4 allData length=" + allData.length);

    // 3. Find slug in data — try multiple patterns
    var slugIdx = allData.indexOf("\"slug\":\"" + slug + "\"");
    Console.log("toc.v4 slug idx (quoted): " + slugIdx);
    if (slugIdx === -1) {
        // Fallback: unquoted or in URL
        slugIdx = allData.indexOf(slug);
        Console.log("toc.v4 slug idx (raw): " + slugIdx);
    }

    if (slugIdx === -1) {
        return Response.error("Movie not found in page data. len=" + html.length + " sample=" + html.substring(0, 200));
    }

    // 4. Find episodes array after slug context
    var epKeyIdx = allData.indexOf("\"episodes\":[", slugIdx);
    if (epKeyIdx === -1) {
        // Try searching wider
        epKeyIdx = allData.indexOf("\"episodes\":[");
    }
    Console.log("toc.v4 episodes idx: " + epKeyIdx);
    if (epKeyIdx === -1) {
        return Response.error("No episodes found in page data.");
    }
    var bracketStart = epKeyIdx + "\"episodes\":[".length - 1;

    // 5. Parse movieId in vicinity
    var targetMovieId = "";
    var nearby = allData.substring(Math.max(0, epKeyIdx - 500), epKeyIdx + 100);
    var mid = nearby.match(/\"movieId\":\"(\\d+)\"/);
    if (mid) targetMovieId = mid[1];
    Console.log("toc.v4 movieId=" + targetMovieId);

    // 6. String-aware bracket scanner
    var depth = 1;
    var end = -1;
    var inStr = false;
    for (var j = bracketStart + 1; j < allData.length; j++) {
        var c = allData.charAt(j);
        if (inStr) {
            if (c === '"') { inStr = false; }
            else if (c === '\\') { j++; }
        } else {
            if (c === '"') { inStr = true; }
            else if (c === '[') { depth++; }
            else if (c === ']') { depth--; if (depth === 0) { end = j + 1; break; } }
        }
    }
    if (end === -1) {
        return Response.error("No episodes found (parse error).");
    }

    var epJson = allData.substring(bracketStart, end);
    var rawEpisodes = [];
    var seen = {};

    try {
        var arr = JSON.parse(epJson);
        Console.log("toc.v4 parsed episodes: " + (arr ? arr.length : 0));
        if (arr && arr.length > 0) {
            for (var k = 0; k < arr.length; k++) {
                var ep = arr[k];
                if (!ep.link) continue;
                var key = (ep.slug || ep.name) + "|" + ep.link;
                if (seen[key]) continue;
                seen[key] = true;
                rawEpisodes.push({
                    name: ep.name || "",
                    link: ep.link,
                    server: ep.server || "Default",
                    slug: ep.slug || ""
                });
            }
        }
    } catch (e) {
        Console.log("toc.v4 parse error: " + e);
        return Response.error("Failed to parse episodes: " + e);
    }

    if (rawEpisodes.length === 0) return Response.error("No episodes found.");

    // 7. Group by server
    var serverOrder = [];
    var serverEpisodes = {};
    var seenSlugs = {};
    for (var i = 0; i < rawEpisodes.length; i++) {
        var ep = rawEpisodes[i];
        var srv = ep.server;
        if (!serverEpisodes[srv]) {
            serverEpisodes[srv] = [];
            serverOrder.push(srv);
            seenSlugs[srv] = {};
        }
        var epslug = ep.slug || ep.name;
        if (seenSlugs[srv][epslug]) continue;
        seenSlugs[srv][epslug] = true;
        serverEpisodes[srv].push(ep);
    }

    // 8. Sort episodes within each server
    for (var s = 0; s < serverOrder.length; s++) {
        var srv = serverOrder[s];
        serverEpisodes[srv].sort(function (a, b) {
            var na = parseInt(a.name) || 0;
            var nb = parseInt(b.name) || 0;
            if (na && nb && na !== nb) return na - nb;
            return a.name.localeCompare(b.name);
        });
    }

    // 9. Build result
    var result = [];
    for (var s = 0; s < serverOrder.length; s++) {
        var srv = serverOrder[s];
        var eps = serverEpisodes[srv];
        if (eps.length === 0) continue;
        result.push({ name: srv, type: "section" });
        for (var e = 0; e < eps.length; e++) {
            result.push({
                name: eps[e].name || ("Tập " + (e + 1)),
                url: eps[e].link,
                host: BASE_URL
            });
        }
    }

    if (result.length === 0) return Response.error("No episodes found.");
    return Response.success(result);
}
