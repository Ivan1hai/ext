load("config.js");

function execute() {
    var text = fetchText(BASE_URL + "/");
    if (!text) return Response.success([]);

    var list = extractMoviesFromText(text);
    return Response.success(list, null);
}