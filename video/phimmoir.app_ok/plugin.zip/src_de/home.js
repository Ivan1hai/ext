load("config.js");

function execute() {
    return Response.success([
        { title: "Phim Mới Cập Nhật", input: BASE_URL, script: "update.js" },
        { title: "Phim Bộ", input: BASE_URL + "/danh-sach/phim-bo", script: "gen.js" },
        { title: "Phim Lẻ", input: BASE_URL + "/danh-sach/phim-le", script: "gen.js" },
        { title: "Phim Thuyết Minh", input: BASE_URL + "/danh-sach/phim-thuyet-minh", script: "gen.js" },
        { title: "Phim Chiếu Rạp", input: BASE_URL + "/danh-sach/phim-chieu-rap", script: "gen.js" },
    ]);
}