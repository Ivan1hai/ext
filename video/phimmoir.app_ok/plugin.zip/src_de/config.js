const BASE_URL = "https://phimmoie.io";
const API_URL = "https://phimmoie.io";

function cleanText(text) {
    return (text || "").replace(/\s+/g, " ").trim();
}

function toAbsolute(url) {
    if (!url) return "";
    var raw = ("" + url).trim();
    if (!raw) return "";
    if (raw.startsWith("http://")) return "https://" + raw.substring(7);
    if (raw.startsWith("https://")) return raw;
    if (raw.startsWith("//")) return "https:" + raw;
    return BASE_URL + (raw.startsWith("/") ? "" : "/") + raw;
}

function normalizeUrl(url) {
    if (!url) return BASE_URL;
    return toAbsolute(url);
}

function buildHeaders() {
    return {
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
        "Cache-Control": "no-cache",
        Pragma: "no-cache",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
    };
}

function fetchDoc(url) {
    var finalUrl = normalizeUrl(url);
    var response = null;
    try { response = fetch(finalUrl, { headers: buildHeaders() }); } catch (e) { }
    if (response && response.ok) return response.html();
    try { response = fetch(finalUrl); } catch (e) { }
    if (response && response.ok) return response.html();
    return null;
}

function fetchText(url) {
    var finalUrl = normalizeUrl(url);
    var response = null;
    try { response = fetch(finalUrl, { headers: buildHeaders() }); } catch (e) { }
    if (response && response.ok) { try { return response.text(); } catch (e) { } }
    try { response = fetch(finalUrl); } catch (e) { }
    if (response && response.ok) { try { return response.text(); } catch (e) { } }
    return "";
}

// Extract movies from raw text (Next.js SSR with escaped JSON strings)
function extractMoviesFromText(text) {
    var list = [];
    if (!text) return list;
    var seen = {};

    var re = /\\"name\\":\\"([^\\]+)\\",\\"origin_name\\":\\"([^\\]*)\\",\\"slug\\":\\"([^\\]+)\\",\\"thumb_url\\":\\"([^\\]*)\\",\\"poster_url\\":\\"([^\\]*)\\"/g;
    var m;
    while ((m = re.exec(text)) !== null) {
        var slug = m[3];
        if (seen[slug]) continue;
        seen[slug] = true;

        var pos = m.index + m[0].length;
        var nearby = text.substring(pos, pos + 500);
        var epMatch = nearby.match(/\\"episode_current\\":\\"([^\\]*)\\"/);
        var qualityMatch = nearby.match(/\\"quality\\":\\"([^\\]*)\\"/);
        var langMatch = nearby.match(/\\"language\\":\\"([^\\]*)\\"/);

        var epText = epMatch ? epMatch[1] : "";
        var quality = qualityMatch ? qualityMatch[1] : "";
        var lang = langMatch ? langMatch[1] : "";

        var desc = [];
        if (epText) desc.push(epText);
        if (quality) desc.push(quality);
        if (lang) desc.push(lang);

        list.push({
            name: m[1].trim(),
            link: BASE_URL + "/phim/" + slug,
            cover: toAbsolute(m[5] || m[4]),
            description: desc.join(" - "),
            tag: epText || quality,
            host: BASE_URL
        });
    }
    return list;
}

// Recursively search for items array in JSON tree
function findItemsInJson(obj, depth) {
    if (!obj || typeof obj !== "object" || depth > 10) return null;
    if (Array.isArray(obj)) {
        // Check if this array contains objects with slug/name
        if (obj.length > 0 && obj[0] && typeof obj[0] === "object" && (obj[0].slug || obj[0].name)) {
            return obj;
        }
        // Recurse into first few elements
        for (var i = 0; i < Math.min(obj.length, 3); i++) {
            var found = findItemsInJson(obj[i], depth + 1);
            if (found) return found;
        }
        return null;
    }
    // Check common key names
    var keys = ["items", "data", "movies", "films", "list", "results", "docs"];
    for (var k = 0; k < keys.length; k++) {
        if (obj[keys[k]] && Array.isArray(obj[keys[k]]) && obj[keys[k]].length > 0) {
            return obj[keys[k]];
        }
    }
    // Recurse into all object values
    for (var key in obj) {
        if (!obj.hasOwnProperty(key)) continue;
        var found = findItemsInJson(obj[key], depth + 1);
        if (found) return found;
    }
    return null;
}

// Extract movies from __NEXT_DATA__ or any script JSON
function extractMoviesFromDoc(doc) {
    var list = [];
    if (!doc) return list;
    var seen = {};

    // Try all script tags containing JSON data
    var scripts = doc.select("script");
    for (var s = 0; s < scripts.size(); s++) {
        var scriptText = scripts.get(s).text() || "";
        if (!scriptText || scriptText.length < 100) continue;

        try {
            var json = JSON.parse(scriptText);
            var items = findItemsInJson(json, 0);
            if (!items || !Array.isArray(items)) continue;

            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                if (!item || typeof item !== "object") continue;
                var slug = item.slug || "";
                if (!slug || seen[slug]) continue;
                seen[slug] = true;

                list.push({
                    name: item.name || item.title || "",
                    link: BASE_URL + "/phim/" + slug,
                    cover: toAbsolute(item.poster_url || item.thumb_url || item.image || ""),
                    description: item.episode_current || item.quality || item.year || "",
                    tag: item.episode_current || item.quality || "",
                    host: BASE_URL
                });
            }
            if (list.length > 0) break; // Found data, stop
        } catch (e) { }
    }

    return list;
}

// Extract search results from the /search?q= page (Next.js RSC payload)
function extractSearchResults(html) {
    var list = [];
    if (!html) return list;

    // Rebuild the unescaped RSC data blob
    var allData = "";
    var parts = html.split('self.__next_f.push([1,"');
    for (var i = 1; i < parts.length; i++) {
        var endIdx = parts[i].lastIndexOf("\n]");
        if (endIdx === -1) {
            endIdx = parts[i].lastIndexOf("])");
            if (endIdx === -1) endIdx = parts[i].length;
        }
        allData += parts[i].substring(0, endIdx).replace(/\\"/g, '"');
    }

    // Scope to the results column (between the lg:w-3/4 main and the lg:w-1/4 sidebar)
    var mainIdx = allData.indexOf("w-full lg:w-3/4");
    var sideIdx = allData.indexOf("w-full lg:w-1/4");
    var scope = allData;
    if (mainIdx !== -1) {
        scope = allData.substring(mainIdx, (sideIdx > mainIdx) ? sideIdx : allData.length);
    }

    var seen = {};
    var re = /"title":"([^"]+)","href":"(\/phim\/[^"]+)"/g;
    var m;
    while ((m = re.exec(scope)) !== null) {
        var name = m[1];
        var href = m[2];
        var slug = href.substring(href.lastIndexOf("/") + 1);
        if (!slug || seen[slug]) continue;
        seen[slug] = true;

        var after = scope.substring(m.index + m[0].length, m.index + m[0].length + 800);
        var cm = after.match(/"src":"(\/storage\/[^"]+)"/);
        var lm = after.match(/"children":"((?:Thuyết Minh|Lồng Tiếng|Vietsub|Phụ Đề)[^"]*)"/);

        list.push({
            name: name,
            link: BASE_URL + "/phim/" + slug,
            cover: cm ? toAbsolute(cm[1]) : "",
            description: lm ? lm[1] : "",
            host: BASE_URL
        });
    }
    return list;
}

// Parse next page number from text (handles /page/N and ?page=N patterns)
function findNextPage(text, currentPage) {
    if (!currentPage) currentPage = "1";
    var next = parseInt(currentPage) + 1;
    var nextStr = "" + next;
    if (text.indexOf("/page/" + next) !== -1) {
        return nextStr;
    }
    if (text.indexOf("?page=" + next) !== -1 || text.indexOf("&page=" + next) !== -1) {
        return nextStr;
    }
    return null;
}