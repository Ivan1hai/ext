load('config.js');

function execute(url) {
    url = normalizeUrl(url);

    var res = fetch(url, { headers: { "User-Agent": UserAgent.chrome() } });
    if (!res.ok) return Response.error("Cannot load: " + res.status);

    var html = res.text();
    var tracks = [];

    // Find all m3u8 sources
    var m3u8Regex = /https?:\/\/[^'"\s]+\.m3u8[^'"\s]*/g;
    var m;
    var seen = {};
    while ((m = m3u8Regex.exec(html)) !== null) {
        var link = m[0];
        if (!seen[link]) {
            seen[link] = true;
            tracks.push({
                title: "Server " + (tracks.length + 1),
                data: link
            });
        }
    }

    // Fallback: var source = '...m3u8'
    if (tracks.length === 0) {
        var srcMatch = html.match(/var\s+source\s*=\s*'([^']+)'/);
        if (srcMatch && srcMatch[1]) {
            tracks.push({
                title: "Server 1",
                data: srcMatch[1]
            });
        }
    }

    if (tracks.length === 0) return Response.error("No stream found");
    return Response.success(tracks);
}
