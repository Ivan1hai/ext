load('config.js');

function execute(key, page) {
    if (!page) page = "1";

    var q = ("" + key).trim();
    if (!q) return Response.success([]);

    var searchUrl = BASE_URL + "/?s=" + encodeURIComponent(q);
    if (page !== "1") {
        searchUrl = BASE_URL + "/page/" + page + "/?s=" + encodeURIComponent(q);
    }

    var res = fetch(searchUrl, { headers: { "User-Agent": UserAgent.chrome() } });
    if (!res.ok) return Response.error("Search failed: " + res.status);

    var doc = res.html();
    var data = [];
    var seen = {};

    doc.select("div.card").forEach(function(card) {
        var linkEl = card.select("a[href*=xem-phim]").first();
        if (!linkEl) return;

        var link = (linkEl.attr("href") || "") + "";
        if (!link || seen[link]) return;
        seen[link] = true;

        link = absoluteUrl(link);

        var title = cleanText(linkEl.attr("title") || linkEl.text());

        var imgEl = card.select("img").first();
        var cover = imgEl ? absoluteUrl(imgEl.attr("src") || "") : "";

        var catEl = card.select(".card__category").first();
        var category = catEl ? cleanText(catEl.text()) : "";

        if (title && link) {
            data.push({
                name: title,
                link: link,
                cover: cover,
                description: category,
                host: BASE_URL
            });
        }
    });

    var nextPage = null;
    if (data.length >= 10) {
        nextPage = String(parseInt(page) + 1);
    }

    return Response.success(data, nextPage);
}
