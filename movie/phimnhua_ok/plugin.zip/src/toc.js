load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    return Response.success([
        { name: "Full", url: url, host: BASE_URL }
    ]);
}
