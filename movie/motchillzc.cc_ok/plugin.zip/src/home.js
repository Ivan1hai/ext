load("config.js");

function execute() {
    return Response.success([
        { title: "Phim mới cập nhật", input: BASE_URL, script: "update.js" },
        { title: "Phim bộ", input: BASE_URL + "/danh-sach/phim-bo", script: "gen.js" },
        { title: "Phim lẻ", input: BASE_URL + "/danh-sach/phim-le", script: "gen.js" },
        { title: "Hoạt hình", input: BASE_URL + "/the-loai/hoat-hinh", script: "gen.js" },
        { title: "Thể loại: Hành Động", input: BASE_URL + "/the-loai/hanh-dong", script: "gen.js" },
        { title: "Thể loại: Tình Cảm", input: BASE_URL + "/the-loai/tinh-cam", script: "gen.js" },
        { title: "Thể loại: Cổ Trang", input: BASE_URL + "/the-loai/co-trang", script: "gen.js" },
        { title: "Quốc gia: Trung Quốc", input: BASE_URL + "/quoc-gia/trung-quoc", script: "gen.js" },
        { title: "Quốc gia: Hàn Quốc", input: BASE_URL + "/quoc-gia/han-quoc", script: "gen.js" },
        { title: "Quốc gia: Âu Mỹ", input: BASE_URL + "/quoc-gia/au-my", script: "gen.js" },
        { title: "Quốc gia: Nhật Bản", input: BASE_URL + "/quoc-gia/nhat-ban", script: "gen.js" },
        { title: "Quốc gia: Thái Lan", input: BASE_URL + "/quoc-gia/thai-lan", script: "gen.js" },
    ]);
}