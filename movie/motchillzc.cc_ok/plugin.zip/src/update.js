load("config.js");

function execute() {
    var doc = fetchDoc(BASE_URL);
    if (!doc) return Response.success([]);

    var list = [];

    // Find the "tab-tv-series" panel which contains latest updated series
    var allItems = doc.select("li.item");
    var seen = {};

    allItems.forEach(function(item) {
        var linkEl = item.select("a[href]").first();
        if (!linkEl) return;

        var link = normalizeUrl(linkEl.attr("href"));
        if (!link || link.indexOf("/phim/") === -1) return;
        if (seen[link]) return;
        seen[link] = true;

        var labelEl = item.select("span.label").first();
        var label = labelEl ? cleanText(labelEl.text()) : "";

        var title = cleanText(linkEl.attr("title") || linkEl.text());

        var imgEl = item.select("img").first();
        var cover = imgEl ? toAbsolute(imgEl.attr("src") || "") : "";

        if (title && link) {
            list.push({
                name: title,
                link: link,
                cover: cover,
                description: label,
                host: BASE_URL
            });
        }
    });

    return Response.success(list, null);
}