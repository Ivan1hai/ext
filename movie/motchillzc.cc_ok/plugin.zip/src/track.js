load("config.js");

function execute(url) {
    return Response.success({
        data: url,
        type: "native",
        headers: {},
        host: BASE_URL,
        timeSkip: []
    });
}