load("config.js");

function execute(url, page) {
    if (!page) page = "1";

    var pageUrl = url;
    if (page !== "1") {
        pageUrl = url.replace(/\/+$/, "") + "/page/" + page;
    }

    var doc = fetchDoc(pageUrl);
    if (!doc) return null;

    var list = extractItemList(doc);

    // Check for next page
    var next = null;
    var pageText = doc.text();
    if (page !== "1") {
        if (pageText.indexOf("/page/" + (parseInt(page) + 1)) !== -1) {
            next = "" + (parseInt(page) + 1);
        }
    } else {
        if (pageText.indexOf("/page/2") !== -1) {
            next = "2";
        }
    }

    return Response.success(list, next);
}