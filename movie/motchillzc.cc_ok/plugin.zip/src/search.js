load("config.js");

function execute(key, page) {
    if (!page) page = "1";

    var q = ("" + key).trim();
    if (!q) return Response.success([]);

    var searchUrl = BASE_URL + "/?s=" + encodeURIComponent(q);
    if (page !== "1") {
        searchUrl = BASE_URL + "/page/" + page + "/?s=" + encodeURIComponent(q);
    }

    var doc = fetchDoc(searchUrl);
    if (!doc) return Response.success([]);

    var list = [];
    var seen = {};

    doc.select("li.item").forEach(function(item) {
        var linkEl = item.select("a[href]").first();
        if (!linkEl) return;

        var link = normalizeUrl(linkEl.attr("href"));
        if (!link || seen[link]) return;
        seen[link] = true;

        var title = cleanText(linkEl.attr("title") || linkEl.text());

        var labelEl = item.select("span.label").first();
        var label = labelEl ? cleanText(labelEl.text()) : "";

        var imgEl = item.select("img").first();
        var cover = imgEl ? toAbsolute(imgEl.attr("src") || "") : "";

        if (title && link) {
            list.push({
                name: title,
                link: link,
                cover: cover,
                description: label,
                host: BASE_URL
            });
        }
    });

    // Fallback: search result page uses article + h2 + a pattern
    if (list.length === 0) {
        doc.select("article h2 a[href], h2 a[href]").forEach(function(a) {
            var link = normalizeUrl(a.attr("href"));
            if (!link || seen[link]) return;
            seen[link] = true;

            var title = cleanText(a.text());
            var imgEl = a.parent().select("img").first();
            if (!imgEl) { var parent = a.parent(); while (parent) { imgEl = parent.select("img").first(); if (imgEl) break; parent = parent.parent(); } }
            var cover = imgEl ? toAbsolute(imgEl.attr("src") || "") : "";

            if (title && link) {
                list.push({
                    name: title,
                    link: link,
                    cover: cover,
                    description: "",
                    host: BASE_URL
                });
            }
        });
    }

    // Check for next page
    var next = null;
    var pageText = doc.text();
    if (pageText.indexOf("/page/" + (parseInt(page) + 1) + "/?s=") !== -1) {
        next = "" + (parseInt(page) + 1);
    }

    return Response.success(list, next);
}