load("config.js");

function execute(url) {
    var doc = fetchDoc(url);
    if (!doc) return Response.error("Cannot load player page.");

    var tracks = [];

    // Find server buttons with data-link attribute
    doc.select("a.streaming-server, a[data-link]").forEach(function(a) {
        var link = a.attr("data-link") || "";
        var dataType = a.attr("data-type") || "";
        var name = cleanText(a.text()) || "Server " + (tracks.length + 1);

        if (link) {
            tracks.push({
                title: name,
                data: link,
                type: dataType
            });
        }
    });

    // If no server buttons, try JSON-LD
    if (tracks.length === 0) {
        doc.select("script[type=application/ld+json]").forEach(function(script) {
            try {
                var ld = JSON.parse(script.text() || "{}");
                if (ld.contentUrl) {
                    tracks.push({
                        title: "VIP #1",
                        data: ld.contentUrl,
                        type: "m3u8"
                    });
                }
                if (ld.embedUrl) {
                    tracks.push({
                        title: "VIP #2",
                        data: ld.embedUrl,
                        type: "embed"
                    });
                }
            } catch (e) {}
        });
    }

    return Response.success(tracks);
}