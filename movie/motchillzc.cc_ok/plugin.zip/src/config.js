const BASE_URL = "https://motchillzc.cc";

function cleanText(text) {
    return (text || "").replace(/\s+/g, " ").trim();
}

function toAbsolute(url) {
    if (!url) return "";
    var raw = ("" + url).trim();
    if (!raw) return "";
    if (raw.startsWith("http://")) return "https://" + raw.substring(7);
    if (raw.startsWith("https://")) return raw;
    if (raw.startsWith("//")) return "https:" + raw;
    return BASE_URL + (raw.startsWith("/") ? "" : "/") + raw;
}

function normalizeUrl(url) {
    if (!url) return BASE_URL;
    return toAbsolute(url);
}

function buildHeaders() {
    return {
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
        "Cache-Control": "no-cache",
        Pragma: "no-cache",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
    };
}

function fetchDoc(url) {
    var finalUrl = normalizeUrl(url);
    var response = null;
    try { response = fetch(finalUrl, { headers: buildHeaders() }); } catch (e) {}
    if (response && response.ok) return response.html();
    try { response = fetch(finalUrl); } catch (e) {}
    if (response && response.ok) return response.html();
    return null;
}

function fetchText(url) {
    var finalUrl = normalizeUrl(url);
    var response = null;
    try { response = fetch(finalUrl, { headers: buildHeaders() }); } catch (e) {}
    if (response && response.ok) { try { return response.text(); } catch (e) {} }
    try { response = fetch(finalUrl); } catch (e) {}
    if (response && response.ok) { try { return response.text(); } catch (e) {} }
    return "";
}

function extractItemList(doc) {
    var list = [];
    if (!doc) return list;
    doc.select("li.item").forEach(function(item) {
        var labelEl = item.select("span.label").first();
        var label = labelEl ? cleanText(labelEl.text()) : "";
        var linkEl = item.select("a[href]").first();
        if (!linkEl) return;
        var link = normalizeUrl(linkEl.attr("href"));
        var title = cleanText(linkEl.attr("title") || linkEl.text());
        var imgEl = item.select("img").first();
        var cover = imgEl ? toAbsolute(imgEl.attr("src") || "") : "";
        if (title && link) {
            list.push({
                name: title,
                link: link,
                cover: cover,
                description: label,
                host: BASE_URL
            });
        }
    });
    return list;
}