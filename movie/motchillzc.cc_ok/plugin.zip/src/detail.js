load("config.js");

function execute(url) {
    var slug = url.split("/").pop();
    if (!slug) return Response.error("Invalid URL");

    var doc = fetchDoc(BASE_URL + "/phim/" + slug);
    if (!doc) return Response.error("Cannot load detail page.");

    var name = "";
    var altName = "";
    var cover = "";
    var description = "";
    var genres = [];
    var country = "";
    var ongoing = true;
    var epStatus = "";

    // Name from og:title meta
    var ogTitle = doc.select("meta[property=og\\:title]").first();
    if (ogTitle) name = cleanText(ogTitle.attr("content") || "");

    // Name from JSON-LD
    var ldScripts = doc.select("script[type=application/ld+json]");
    ldScripts.forEach(function(script) {
        try {
            var ld = JSON.parse(script.text() || "{}");
            if (ld.name && !name) name = ld.name;
            if (ld.alternateName) altName = ld.alternateName;
            if (ld.description && !description) description = ld.description;
            if (ld.genre) genres = ld.genre;
            if (ld.countryOfOrigin) {
                var co = ld.countryOfOrigin;
                country = typeof co === "string" ? co : co.name || "";
            }
        } catch (e) {}
    });

    // Fallback name from title tag
    if (!name) {
        var titleEl = doc.select("title").first();
        if (titleEl) {
            name = cleanText(titleEl.text());
            name = name.replace(/^Phim /, "").replace(/ - Motchill.*$/, "").replace(/ Vietsub.*$/, "").trim();
        }
    }

    // Cover from og:image
    var ogImg = doc.select("meta[property=og\\:image]").first();
    if (ogImg) cover = ogImg.attr("content") || "";

    // Cover fallback from img in detail page
    if (!cover) {
        var imgEl = doc.select("img.img-film, .poster-link img, img[src*=poster]").first();
        if (imgEl) cover = toAbsolute(imgEl.attr("src") || "");
    }

    // Description from tab content
    if (!description) {
        var descEl = doc.select("div.tab").first();
        if (descEl) {
            description = cleanText(descEl.text());
        }
    }

    // Badge for status
    var badgeEl = doc.select("span.badge, span.label").first();
    if (badgeEl) {
        var badgeText = cleanText(badgeEl.text());
        if (badgeText.indexOf("Hoàn tất") !== -1) {
            ongoing = false;
            epStatus = badgeText;
        } else {
            epStatus = badgeText;
        }
    }

    // Build detail info
    var info = [];
    if (altName) info.push("Tên khác: " + altName);
    if (country) info.push("Quốc gia: " + country);
    if (epStatus) info.push("Tình trạng: " + epStatus);

    return Response.success({
        name: name,
        cover: cover,
        author: "MotChill",
        description: description,
        detail: info.join("<br>"),
        ongoing: ongoing,
        genres: genres,
        format: "series",
        host: BASE_URL
    });
}