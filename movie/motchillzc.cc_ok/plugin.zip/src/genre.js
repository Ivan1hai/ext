load("config.js");

function execute() {
    var genres = [
        { name: "Hành Động", url: BASE_URL + "/the-loai/hanh-dong" },
        { name: "Cổ Trang", url: BASE_URL + "/the-loai/co-trang" },
        { name: "Chiến Tranh", url: BASE_URL + "/the-loai/chien-tranh" },
        { name: "Viễn Tưởng", url: BASE_URL + "/the-loai/vien-tuong" },
        { name: "Kinh Dị", url: BASE_URL + "/the-loai/kinh-di" },
        { name: "Tài Liệu", url: BASE_URL + "/the-loai/tai-lieu" },
        { name: "Bí Ẩn", url: BASE_URL + "/the-loai/bi-an" },
        { name: "Phim 18+", url: BASE_URL + "/the-loai/phim-18" },
        { name: "Tình Cảm", url: BASE_URL + "/the-loai/tinh-cam" },
        { name: "Tâm Lý", url: BASE_URL + "/the-loai/tam-ly" },
        { name: "Thể Thao", url: BASE_URL + "/the-loai/the-thao" },
        { name: "Phiêu Lưu", url: BASE_URL + "/the-loai/phieu-luu" },
        { name: "Âm Nhạc", url: BASE_URL + "/the-loai/am-nhac" },
        { name: "Gia Đình", url: BASE_URL + "/the-loai/gia-dinh" },
        { name: "Học Đường", url: BASE_URL + "/the-loai/hoc-duong" },
        { name: "Hài Hước", url: BASE_URL + "/the-loai/hai-huoc" },
        { name: "Hình Sự", url: BASE_URL + "/the-loai/hinh-su" },
        { name: "Võ Thuật", url: BASE_URL + "/the-loai/vo-thuat" },
        { name: "Khoa Học", url: BASE_URL + "/the-loai/khoa-hoc" },
        { name: "Thần Thoại", url: BASE_URL + "/the-loai/than-thoai" },
        { name: "Chính Kịch", url: BASE_URL + "/the-loai/chinh-kich" },
        { name: "Kinh Điển", url: BASE_URL + "/the-loai/kinh-dien" },
        { name: "Phim Ngắn", url: BASE_URL + "/the-loai/phim-ngan" },
        { name: "Hoạt Hình", url: BASE_URL + "/the-loai/hoat-hinh" },
    ];

    var countries = [
        { name: "Trung Quốc", url: BASE_URL + "/quoc-gia/trung-quoc" },
        { name: "Hàn Quốc", url: BASE_URL + "/quoc-gia/han-quoc" },
        { name: "Âu Mỹ", url: BASE_URL + "/quoc-gia/au-my" },
        { name: "Nhật Bản", url: BASE_URL + "/quoc-gia/nhat-ban" },
        { name: "Thái Lan", url: BASE_URL + "/quoc-gia/thai-lan" },
        { name: "Ấn Độ", url: BASE_URL + "/quoc-gia/an-do" },
        { name: "Đài Loan", url: BASE_URL + "/quoc-gia/dai-loan" },
        { name: "Hồng Kông", url: BASE_URL + "/quoc-gia/hong-kong" },
        { name: "Anh", url: BASE_URL + "/quoc-gia/anh" },
        { name: "Pháp", url: BASE_URL + "/quoc-gia/phap" },
        { name: "Canada", url: BASE_URL + "/quoc-gia/canada" },
        { name: "Úc", url: BASE_URL + "/quoc-gia/uc" },
        { name: "Tây Ban Nha", url: BASE_URL + "/quoc-gia/tay-ban-nha" },
        { name: "Việt Nam", url: BASE_URL + "/quoc-gia/viet-nam" },
    ];

    var result = [];

    result.push({ title: "Danh sách: Phim bộ", input: BASE_URL + "/danh-sach/phim-bo", script: "gen.js" });
    result.push({ title: "Danh sách: Phim lẻ", input: BASE_URL + "/danh-sach/phim-le", script: "gen.js" });

    for (var i = 0; i < genres.length; i++) {
        result.push({ title: "Thể loại: " + genres[i].name, input: genres[i].url, script: "gen.js" });
    }

    for (var i = 0; i < countries.length; i++) {
        result.push({ title: "Quốc gia: " + countries[i].name, input: countries[i].url, script: "gen.js" });
    }

    return Response.success(result);
}