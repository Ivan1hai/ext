load("config.js");

function execute(url) {
    var slug = url.split("/").pop();
    if (!slug) return Response.error("Invalid URL");

    // Fetch first episode watch page to get server sections + episode lists
    var watchUrl = BASE_URL + "/xem-phim/" + slug + "/tap-1-sv-0";
    var html = fetchText(watchUrl);
    if (!html) return Response.error("Cannot load episode page.");

    var result = [];

    // Split by server-episode-block to get each server section
    var sections = html.split("server-episode-block");
    var hasMultiple = sections.length > 2;

    for (var i = 1; i < sections.length; i++) {
        var section = sections[i];

        // Extract server name: <i class="fa fa-film"></i> NAME
        var serverMatch = section.match(/<i[^>]*class="[^"]*fa-film[^"]*"[^>]*><\/i>\s*([^<]+)/);
        var serverName = serverMatch ? serverMatch[1].trim() : "";

        if (hasMultiple && serverName) {
            result.push({
                name: serverName,
                type: "section"
            });
        }

        // Find the list-episode div
        var leMatch = section.match(/<div\s+class="list-episode">([\s\S]*?)<\/div>/);
        if (!leMatch) continue;

        var epHtml = leMatch[1];
        var linkRegex = /<a\s+[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
        var m;

        while ((m = linkRegex.exec(epHtml)) !== null) {
            var epNum = m[2].trim();
            result.push({
                name: "Tập " + epNum,
                url: m[1],
                host: BASE_URL
            });
        }
    }

    // Fallback: if regex failed, try doc.select approach
    if (result.length === 0) {
        var doc = fetchDoc(watchUrl);
        if (!doc) return Response.error("Cannot find episode list.");

        // Check for multiple server blocks
        var listEp = doc.select("div.list-episode").first();
        if (listEp) {
            listEp.select("a[href]").forEach(function(a) {
                var epUrl = normalizeUrl(a.attr("href"));
                var epNum = cleanText(a.text());
                if (epNum && epUrl) {
                    result.push({
                        name: "Tập " + epNum,
                        url: epUrl,
                        host: BASE_URL
                    });
                }
            });
        }
    }

    if (result.length === 0) return Response.error("Cannot find episode list.");

    return Response.success(result);
}