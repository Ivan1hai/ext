// Alphapolis (アルファポリス) - Japanese novel posting site
// Site is behind AWS WAF (JS challenge) + reCAPTCHA v2 for chapter body.
// Strategy: use Engine browser to solve WAF, then XHR (sync) inside the page
// to grab the RAW server-rendered HTML (SSR content lives in #novelBody),
// because the Vue app wipes it from the DOM after mount.
var BASE_URL = "https://www.alphapolis.co.jp";
var UA = "Mozilla/5.0 (Linux; Android 11; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";

// Fetch raw HTML of a page using the browser (passes AWS WAF), returning raw text.
function apRaw(url, timeout) {
    var browser = null;
    try {
        browser = Engine.newBrowser();
        browser.setUserAgent(UA);
        browser.launch(url, timeout || 25000);
        sleep(2500); // let AWS WAF challenge finish + cookie set
        browser.callJs(
            "(function(){" +
            "var d=document.getElementById('__ap_raw');" +
            "if(!d){d=document.createElement('div');d.id='__ap_raw';document.body.appendChild(d);}" +
            "try{var x=new XMLHttpRequest();x.open('GET',"+JSON.stringify(url)+",false);x.send(null);" +
            "var raw=x.responseText;" +
            "d.setAttribute('data-status',x.status);" +
            "d.setAttribute('data-enc',encodeURIComponent(raw));}" +
            "catch(e){d.setAttribute('data-status','0');d.setAttribute('data-err',''+e);}" +
            "})();", 6000);
        var doc = browser.html();
        var out = null;
        if (doc) {
            var el = doc.select("#__ap_raw");
            if (el) {
                var e = el.first();
                if (e) {
                    var status = e.attr("data-status") || "0";
                    var enc = e.attr("data-enc") || "";
                    if (status === "200" && enc) {
                        try { out = decodeURIComponent(enc); } catch (de) { out = null; }
                    }
                }
            }
        }
        return out;
    } catch (e) {
        return null;
    } finally {
        try { if (browser) browser.close(); } catch (ce) {}
    }
}

// Fetch raw HTML and parse it into a Document.
function apDoc(url, timeout) {
    var raw = apRaw(url, timeout);
    if (!raw || raw.length < 100) return null;
    try { return Html.parse(raw); } catch (e) { return null; }
}

// Extract JSON payload of <script id="app-cover-data"> (detail page metadata + TOC)
function apCoverData(doc) {
    try {
        if (!doc) return null;
        var el = doc.select("#app-cover-data");
        if (!el) return null;
        var e = el.first();
        if (!e) return null;
        return JSON.parse(e.html());
    } catch (err) {
        return null;
    }
}

function absUrl(href) {
    if (!href) return "";
    if (href.indexOf("http") === 0) return href;
    if (href.indexOf("//") === 0) return "https:" + href;
    return BASE_URL + (href.indexOf("/") === 0 ? href : "/" + href);
}

// Strip html tags -> plain text (keeps <br> as newline)
function apText(html) {
    if (!html) return "";
    return html
        .replace(/<br\s*\/?>/gi, "\n")
        .replace(/<\/p>/gi, "\n")
        .replace(/<[^>]+>/g, "")
        .replace(/&nbsp;/g, " ")
        .replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'")
        .replace(/[ \t]+\n/g, "\n")
        .replace(/\n{3,}/g, "\n\n")
        .trim();
}
