load("config.js");

var CATS = [
    ["ファンタジー", "110400"], ["恋愛", "110500"], ["ミステリー", "110100"],
    ["ホラー", "110200"], ["SF", "110300"], ["キャラ文芸", "111400"],
    ["ライト文芸", "111500"], ["青春", "110600"], ["大衆娯楽", "110800"],
    ["現代文学", "110700"], ["経済・企業", "111000"], ["歴史・時代", "111100"],
    ["児童書・童話", "111200"], ["絵本", "111300"], ["ｴｯｾｲ・ﾉﾝﾌｨｸｼｮﾝ", "111600"]
];

function execute() {
    var out = [];
    for (var i = 0; i < CATS.length; i++) {
        out.push({
            title: CATS[i][0],
            input: BASE_URL + "/novel/index?category_ids=" + CATS[i][1] + "&page=1",
            script: "genrecontent.js"
        });
    }
    return Response.success(out);
}
