load("config.js");

function execute(url) {
    url = String(url || "").replace(/\/+$/, "");
    var doc = apDoc(url, 30000);
    if (!doc) return Response.error("Khong tai duoc trang muc luc: " + url);

    var cover = apCoverData(doc);
    var list = [];
    if (cover && cover.chapterEpisodes) {
        for (var g = 0; g < cover.chapterEpisodes.length; g++) {
            var eps = cover.chapterEpisodes[g].episodes || [];
            for (var i = 0; i < eps.length; i++) {
                var e = eps[i];
                list.push({
                    name: e.mainTitle || ("Episode " + e.episodeNo),
                    url: absUrl(e.url),
                    host: "alphapolis.co.jp"
                });
            }
        }
    }
    if (list.length === 0) {
        var links = doc.select("a.p-table-of-contents__episode-link");
        for (var j = 0; j < links.size(); j++) {
            var a = links.get(j);
            list.push({ name: a.text(), url: absUrl(a.attr("href")), host: "alphapolis.co.jp" });
        }
    }
    if (list.length === 0) return Response.error("Khong tim thay danh sach chuong");
    return Response.success(list);
}
