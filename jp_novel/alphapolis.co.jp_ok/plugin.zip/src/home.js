load("config.js");

function execute() {
    return Response.success([
        { title: "Mới cập nhật", input: BASE_URL + "/novel/index?sort=episode_recent", script: "homecontent.js" },
        { title: "Đã hoàn thành", input: BASE_URL + "/novel/index?complete=1&sort=completed", script: "homecontent.js" },
        { title: "Truyện mới", input: BASE_URL + "/novel/index?is_inside=1&sort=recent", script: "homecontent.js" },
        { title: "Truyện Hot", input: BASE_URL + "/novel/ranking/hot", script: "homecontent.js" },
        { title: "Truyện Đề cử", input: BASE_URL + "/novel/recommended", script: "homecontent.js" }
    ]);
}
