load("config.js");

function execute(url) {
    url = String(url || "").replace(/\/+$/, "");
    var doc = apDoc(url, 30000);
    if (!doc) return Response.error("Khong tai duoc trang chi tiet (WAF/JS challenge): " + url);

    var cover = apCoverData(doc);
    var title = "", author = "", coverImg = "";
    if (cover && cover.content) {
        title = cover.content.title || "";
        author = (cover.content.user && cover.content.user.name) || "";
        coverImg = cover.content.coverImageUrl || "";
    }
    if (!title) {
        var h1 = doc.select("h1").first();
        if (h1) title = h1.text();
    }
    if (!author) {
        var au = doc.select(".p-novel-episode__author").first();
        if (au) author = au.text();
    }
    // cover: <img src="...cdn-image.alphapolis.co.jp/cover/..."> hoac /cont_access.php?citi_cont_id=
    var imgs = doc.select("img[src]");
    for (var i = 0; i < imgs.size(); i++) {
        var src = imgs.get(i).attr("src") || "";
        if (src.indexOf("/cover/") >= 0 || src.indexOf("cont_access.php") >= 0) { coverImg = absUrl(src); break; }
    }
    var desc = "";
    var md = doc.select("meta[name=description]").first();
    if (md) desc = md.attr("content") || "";

    var total = 0;
    if (cover && cover.chapterEpisodes) {
        for (var g = 0; g < cover.chapterEpisodes.length; g++) {
            total += (cover.chapterEpisodes[g].episodes || []).length;
        }
    }

    var genres = [];
    var catA = doc.select("a[href*='/novel/index?category_ids=']");
    for (var c = 0; c < catA.size(); c++) {
        var a = catA.get(c);
        var t = a.text();
        if (t && t.indexOf("小説") < 0 && t.indexOf("Fantasy") < 0) {
            genres.push({ title: t, input: absUrl(a.attr("href")), script: "" });
        }
    }
    if (genres.length > 12) genres = genres.slice(0, 12);

    return Response.success({
        name: title,
        cover: coverImg,
        host: "alphapolis.co.jp",
        author: author,
        description: apText(desc).slice(0, 2000),
        detail: "So chuong: " + total,
        ongoing: true,
        genres: genres
    });
}
