load("config.js");

    // Parse result cards. Two layouts exist:
    //  - list page  : section.c-content (a.c-content__cover / h2.c-content__title)
    //  - search page: div.content-block.novels (a.cover / h2.title)
    function apCards(doc) {
        var out = [];
        var secs = doc.select("section.c-content");
        var i, a, card;
        for (i = 0; i < secs.size(); i++) {
            card = secs.get(i);
            a = card.select("a.c-content__cover[href], h2.c-content__title a[href]").first();
            if (!a) a = card.select("a[href*='/novel/']").first();
            if (!a) continue;
            var href = a.attr("href") || "";
            if (!/\/novel\/\d+\/\d+/.test(href)) continue;
            var t = card.select("h2.c-content__title").first();
            var name = t ? t.text() : a.attr("alt") || "";
            var im = card.select("img[src]").first();
            var cover = im ? absUrl(im.attr("src") || "") : "";
            var au = card.select(".c-content__author a, .author a").first();
            var author = au ? au.text() : "";
            var de = card.select(".c-content__abstract, .summary").first();
            var desc = de ? apText(de.text()) : "";
            out.push({ name: name, link: absUrl(href), host: "alphapolis.co.jp", cover: cover, description: desc, author: author });
        }
        if (out.length > 0) return out;

        var blocks = doc.select("div.content-block.novels");
        for (i = 0; i < blocks.size(); i++) {
            card = blocks.get(i);
            a = card.select("h2.title a[href]").first();
            if (!a) continue;
            href = a.attr("href") || "";
            name = a.text();
            im = card.select("a.cover img[src]").first();
            cover = im ? absUrl(im.attr("src") || "") : "";
            au = card.select(".author a").first();
            author = au ? au.text() : "";
            de = card.select(".summary").first();
            desc = de ? apText(de.text()) : "";
            out.push({ name: name, link: absUrl(href), host: "alphapolis.co.jp", cover: cover, description: desc, author: author });
        }
        return out;
    }

function execute(key, page) {
    if (!key) return Response.success([], "");
    var p = parseInt(page || "1", 10);
    if (!p || p < 1) p = 1;
    var url = BASE_URL + "/search?query=" + encodeURIComponent(key) + "&category=novel&page=" + p;
    var doc = apDoc(url, 30000);
    if (!doc) return Response.error("Khong tai duoc ket qua tim kiem");
    var cards = apCards(doc);
    var next = cards.length >= 10 ? String(p + 1) : "";
    return Response.success(cards, next);
}
