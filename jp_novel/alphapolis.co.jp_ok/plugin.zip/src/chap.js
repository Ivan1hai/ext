load("config.js");

function execute(url) {
    url = String(url || "").replace(/\/+$/, "");
    var doc = apDoc(url, 30000);
    if (!doc) return Response.error("Khong tai duoc chuong (WAF): " + url);

    var el = doc.select("#novelBody").first();
    if (!el) {
        var el2 = doc.select(".p-novel-episode__text").first();
        if (el2) el = el2;
    }
    if (!el) return Response.error("Khong tim thay noi dung chuong: " + url);

    var html = el.html();
    var txt = apText(html);
    if (!txt || txt.length < 20) {
        // raw HTML may keep content as escaped text nodes; fallback
        txt = apText(el.text());
    }
    if (!txt) return Response.error("Chuong rong (co the bi gioi han doc thu vien): " + url);
    // gộp các <br> liên tiếp (nguồn có cả <br> lẫn newline thô)
    return Response.success(txt.replace(/\n/g, "<br>").replace(/(<br>){2,}/g, "<br>"));
}
