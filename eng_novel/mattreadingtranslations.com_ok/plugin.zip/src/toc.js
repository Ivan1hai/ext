load("config.js");

function execute(url) {
    let pageUrl = normalizeUrl(url);
    let doc = fetchDoc(pageUrl);
    if (!doc) return Response.error("Cannot load chapter list page.");

    let chapters = parseTocPage(doc);
    if (chapters.length === 0) return Response.error("Cannot find chapter list.");

    let nextUrl = "";
    let pagination = doc.select("div.pagination").first();
    if (pagination) {
        let links = pagination.select("a.page-numbers");
        let foundCurrent = false;
        for (let i = 0; i < links.size(); i++) {
            let el = links.get(i);
            if (foundCurrent) {
                let href = el.attr("href");
                if (href) {
                    nextUrl = normalizeUrl(href);
                }
                break;
            }
            if (el.hasClass("current")) {
                foundCurrent = true;
            }
        }
    }

    return Response.success(chapters, nextUrl);
}
