load("config.js");

function execute(url, page) {
    var base = removeTrailingSlash(BASE_URL);
    var items = [];
    var nextUrl = null;

    // Determine API path from input URL
    var apiUrl = null;
    var sortOrder = "-updated_at";

    if (url.indexOf("/truyen/truyen-moi") >= 0) {
        apiUrl = base + "/story/chapters/recent/?page=" + (page || 1) + "&page_size=20";
    } else if (url.indexOf("/truyen/truyen-hoan-thanh") >= 0) {
        apiUrl = base + "/story/stories/completed/?page=" + (page || 1) + "&page_size=20";
    } else if (url.indexOf("/truyen/xep-hang/admin") >= 0) {
        apiUrl = base + "/story/top/nominations/?page=" + (page || 1) + "&type=admin&page_size=20";
    } else if (url.indexOf("/truyen/xep-hang/view") >= 0) {
        apiUrl = base + "/story/top/nominations/?page=" + (page || 1) + "&type=view&page_size=20";
    } else if (url.indexOf("/truyen/xep-hang/user") >= 0) {
        apiUrl = base + "/story/top/nominations/?page=" + (page || 1) + "&type=user&page_size=20";
    } else if (url.indexOf("/truyen/the-loai/") >= 0) {
        var genreMatch = url.match(/\/truyen\/the-loai\/([^\/\?#]+)/);
        if (genreMatch) {
            apiUrl = base + "/story/list/" + genreMatch[1] + "/?page=" + (page || 1) + "&page_size=20";
        }
    } else if (url.indexOf("/search") >= 0) {
        var qMatch = url.match(/[?&]q=([^&]+)/);
        if (qMatch) {
            apiUrl = base + "/story/user/search/?q=" + encodeURIComponent(decodeURIComponent(qMatch[1])) + "&page=" + (page || 1) + "&page_size=20";
        }
    }

    // Try API first
    if (apiUrl) {
        var data = fetchJson(apiUrl);
        if (data && data.results) {
            data.results.forEach(function (r) {
                // Recent chapters: {number, story: {title, slug, cover_image, description}}
                // Others: {title, slug, cover_image, description} directly
                var s = r.story || r;
                if (!s.slug) return;
                items.push({
                    name: cleanText(decodeHtmlEntities(s.title || s.slug)),
                    link: base + "/truyen/" + s.slug,
                    cover: absoluteUrl(s.cover_image || ""),
                    description: cleanText(decodeHtmlEntities(s.description || ""))
                });
            });
            if (data.next) nextUrl = data.next;
        }
    }

    // Fallback: browser scrape (if API fails or no apiUrl matched)
    if (items.length === 0) {
        var doc = fetchDocument(url);
        if (doc) {
            var coverImgs = doc.select("img[src*='/media/stories/']");
            var seen = {};
            coverImgs.forEach(function (img) {
                var src = img.attr("src");
                if (!src) return;
                var m = src.match(/\/media\/stories\/([a-z0-9-]+)\.[a-z]+/i);
                if (!m) return;
                var slug = m[1];
                if (seen[slug]) return;
                seen[slug] = true;

                var title = cleanText(decodeHtmlEntities(img.attr("alt"))) || slug;
                var titleLinks = doc.select("a[href*='/truyen/" + slug + "']");
                for (var i = 0; i < titleLinks.length; i++) {
                    var a = titleLinks.get(i);
                    var href = a.attr("href");
                    if (!href || /\/the-loai\/|\/tac-gia\/|\/chuong-/.test(href)) continue;
                    var txt = cleanText(decodeHtmlEntities(a.text())).replace(/\s+/g, " ").trim();
                    if (txt && txt.length >= 3) {
                        title = txt;
                        break;
                    }
                }

                items.push({
                    name: title,
                    link: base + "/truyen/" + slug,
                    cover: absoluteUrl(src),
                    description: ""
                });
            });
        }
    }

    return Response.success(items, nextUrl);
}