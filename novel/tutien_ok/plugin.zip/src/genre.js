load("config.js");

function execute() {
    var doc = fetchDocument(removeTrailingSlash(BASE_URL) + "/truyen/the-loai");
    if (!doc) return Response.success([]);

    var genres = [];
    var seen = {};

    // Genre links: <a href="/truyen/the-loai/{slug}">
    doc.select("a[href*='/truyen/the-loai/']").forEach(function (el) {
        var name = cleanText(decodeHtmlEntities(el.text()));
        var href = absoluteUrl(el.attr("href"));
        if (!name || !href) return;

        var key = normalizeKeyword(name);
        if (!key || seen[key]) return;
        seen[key] = true;

        genres.push({
            title: name,
            input: href,
            script: "gen.js"
        });
    });

    return Response.success(genres);
}