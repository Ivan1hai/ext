var BASE_URL = "https://tutien.pro";

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}

function removeTrailingSlash(text) {
    return text ? text.replace(/\/+$/, "") : "";
}

function trimSlashes(text) {
    return text ? text.replace(/^\/+|\/+$/g, "") : "";
}

function cleanText(text) {
    return text ? text.replace(/\s+/g, " ").trim() : "";
}

function decodeHtmlEntities(text) {
    if (!text) return "";
    return text
        .replace(/&#(\d+);/g, function (_, c) { return String.fromCharCode(parseInt(c, 10)); })
        .replace(/&#x([0-9a-fA-F]+);/g, function (_, c) { return String.fromCharCode(parseInt(c, 16)); })
        .replace(/&nbsp;/gi, " ")
        .replace(/&amp;/gi, "&")
        .replace(/&quot;/gi, '"')
        .replace(/&#039;|&apos;/gi, "'")
        .replace(/&lt;/gi, "<")
        .replace(/&gt;/gi, ">")
        .replace(/&hellip;/gi, "...");
}

function absoluteUrl(url) {
    if (!url) return "";
    if (url.indexOf("//") === 0) return "https:" + url;
    if (/^https?:\/\//i.test(url)) return url;
    if (url.charAt(0) === "/") return removeTrailingSlash(BASE_URL) + url;
    return removeTrailingSlash(BASE_URL) + "/" + url.replace(/^\/+/, "");
}

function normalizeUrl(url) {
    if (!url) return removeTrailingSlash(BASE_URL);
    return absoluteUrl(url).replace(/^https?:\/\/[^\/]+/i, removeTrailingSlash(BASE_URL));
}

function getImageUrl(element) {
    if (!element) return "";
    var url = element.attr("data-src");
    if (!url) url = element.attr("data-lazy-src");
    if (!url) url = element.attr("src");
    return absoluteUrl(url);
}

function parseIntSafe(text, fallback) {
    var value = parseInt(text, 10);
    return isNaN(value) ? fallback : value;
}

function getNovelSlug(url) {
    var parts = trimSlashes(url).split("/");
    if (parts.length >= 2 && parts[0] === "truyen") {
        return parts[1];
    }
    var match = url.match(/\/truyen\/([^\/?#]+)/);
    return match ? match[1] : "";
}

function getNovelBaseUrl(url) {
    var slug = getNovelSlug(url);
    if (!slug) return "";
    return removeTrailingSlash(BASE_URL) + "/truyen/" + slug;
}

function normalizeKeyword(text) {
    text = cleanText(decodeHtmlEntities(text)).toLowerCase();
    if (!text) return "";
    var map = {
        a: /[àáạảãâầấậẩẫăằắặẳẵ]/g,
        e: /[èéẹẻẽêềếệểễ]/g,
        i: /[ìíịỉĩ]/g,
        o: /[òóọỏõôồốộổỗơờớợởỡ]/g,
        u: /[ùúụủũưừứựửữ]/g,
        y: /[ỳýỵỷỹ]/g,
        d: /đ/g
    };
    for (var k in map) {
        text = text.replace(map[k], k);
    }
    return text.replace(/[^a-z0-9\s-]/g, " ").replace(/\s+/g, " ").trim();
}

// Try to fetch JSON from API path
function fetchJson(url) {
    try {
        var response = fetch(url, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36",
                "Accept": "application/json"
            }
        });
        if (response && response.ok) {
            return JSON.parse(response.text());
        }
    } catch (e) {}
    return null;
}

// Browser fetch for SPA pages
function fetchDocument(url, timeout) {
    var targetUrl = normalizeUrl(url);
    var t = timeout || 20000;

    try {
        if (typeof Engine !== "undefined" && Engine && typeof Engine.newBrowser === "function") {
            var browser = Engine.newBrowser();
            if (browser) {
                if (typeof browser.launch === "function") {
                    browser.launch(targetUrl, t);
                }
                if (typeof browser.html === "function") {
                    return browser.html();
                }
            }
        }
    } catch (e) {}

    // Fallback: plain fetch (won't work for SPA but try)
    try {
        var response = fetch(targetUrl, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "vi-VN,vi;q=0.9"
            }
        });
        if (response && response.ok) {
            return response.html();
        }
    } catch (e) {}

    return null;
}

function stripHtml(html) {
    if (!html) return "";
    return cleanText(decodeHtmlEntities(
        html.replace(/<br\s*\/?>/gi, "\n")
            .replace(/<\/p>/gi, "\n")
            .replace(/<[^>]+>/g, " ")
    ));
}

function sanitizeContentHtml(html) {
    if (!cleanText(html)) return "";
    var doc = Html.parse("<div id='root'>" + html + "</div>");
    var root = doc.select("#root").first();
    if (!root) return html;
    root.select("script, style, iframe, form, noscript").remove();
    return root.html();
}