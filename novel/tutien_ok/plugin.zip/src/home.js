load("config.js");

function execute() {
    var base = removeTrailingSlash(BASE_URL);

    return Response.success([
        {
            title: "Mới cập nhật",
            input: base + "/truyen/truyen-moi",
            script: "gen.js"
        },
        {
            title: "Đã hoàn thành",
            input: base + "/truyen/truyen-hoan-thanh",
            script: "gen.js"
        },
        {
            title: "BTV đề cử",
            input: base + "/truyen/xep-hang/admin",
            script: "gen.js"
        },
        {
            title: "Top lượt đọc",
            input: base + "/truyen/xep-hang/view",
            script: "gen.js"
        },
        {
            title: "Top đề cử",
            input: base + "/truyen/xep-hang/user",
            script: "gen.js"
        }
    ]);
}