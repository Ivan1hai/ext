load("config.js");

function execute(url) {
    var base = removeTrailingSlash(BASE_URL);
    var slug = getNovelSlug(url);
    if (!slug) return null;

    // Primary: find story_id via search API, then fetch chapters
    var data = fetchJson(base + "/story/user/search/?q=" + encodeURIComponent(slug) + "&page=1&page_size=10");
    var storyId = null;
    if (data && data.results) {
        for (var i = 0; i < data.results.length; i++) {
            if (data.results[i].slug === slug) {
                storyId = data.results[i].id;
                break;
            }
        }
    }

    var chapterList = [];

    if (storyId) {
        // API returns newest first (DESC). Fetch all pages.
        for (var p = 1; p <= 200; p++) {
            var chData = fetchJson(base + "/story/stories/" + storyId + "/chapters/?page=" + p + "&page_size=100");
            if (!chData || !chData.results || chData.results.length === 0) break;

            chData.results.forEach(function (c) {
                chapterList.push(c);
            });

            if (!chData.next) break;
        }
    }

    var chapters = [];

    if (chapterList.length > 0) {
        // Sort by number ASC (oldest first)
        chapterList.sort(function (a, b) {
            return (a.number || 0) - (b.number || 0);
        });

        chapterList.forEach(function (c) {
            chapters.push({
                name: "Chương " + c.number + (c.title ? ": " + c.title : ""),
                url: base + "/truyen/" + slug + "/chuong-" + c.number,
                host: BASE_URL
            });
        });
    } else {
        // Fallback: browser scrape chapter list
        var doc = fetchDocument(url);
        if (doc) {
            var seenCh = {};
            doc.select("a[href*='/chuong-']").forEach(function (el) {
                var href = el.attr("href");
                if (!href) return;
                var chMatch = href.match(/chuong-(\d+)/);
                if (!chMatch) return;
                var num = parseInt(chMatch[1], 10);
                if (seenCh[num]) return;
                seenCh[num] = true;

                var title = cleanText(decodeHtmlEntities(el.text())).replace(/\s+/g, " ").trim();
                if (!title) title = "Chương " + num;

                chapters.push({
                    name: title,
                    url: absoluteUrl(href),
                    host: BASE_URL
                });
            });

            // Sort ascending by chapter number
            chapters.sort(function (a, b) {
                var na = parseInt((a.url.match(/chuong-(\d+)/) || [, 0])[1], 10);
                var nb = parseInt((b.url.match(/chuong-(\d+)/) || [, 0])[1], 10);
                return na - nb;
            });
        }
    }

    return Response.success(chapters);
}