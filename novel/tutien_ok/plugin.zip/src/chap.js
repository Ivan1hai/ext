load("config.js");

function execute(url) {
    var base = removeTrailingSlash(BASE_URL);

    // Extract slug and chapter number from URL
    var match = url.match(/\/truyen\/([^\/]+)\/chuong-(\d+)/);
    if (!match) {
        // Try alternate URL pattern
        match = url.match(/\/story\/([^\/]+)\/chapter-(\d+)/);
    }
    if (!match) return null;

    var slug = match[1];
    var number = match[2];

    // Primary: API
    var data = fetchJson(base + "/story/" + slug + "/chapter-" + number + "/");
    if (data && data.content) {
        // Convert \n\n to paragraph breaks
        var html = data.content
            .split(/\n+/)
            .map(function (p) { return "<p>" + p.trim() + "</p>"; })
            .join("");
        return Response.success(html);
    }

    // Fallback: browser scrape
    var doc = fetchDocument(url);
    if (!doc) return null;

    var contentDiv = doc.select("#chapter-content").first()
        || doc.select(".whitespace-pre-wrap").first()
        || doc.select("div[id*='chapter']").first();

    if (contentDiv) {
        contentDiv.select("script, style, noscript").remove();
        var content = contentDiv.html();
        if (!content || !cleanText(content)) {
            content = contentDiv.text();
            if (content) {
                content = "<p>" + content.replace(/\n+/g, "</p><p>") + "</p>";
            }
        }
        if (content) return Response.success(sanitizeContentHtml(content));
    }

    return null;
}