load("config.js");

function execute(key, page) {
    var base = removeTrailingSlash(BASE_URL);
    var pageNumber = parseIntSafe(page, 1);
    var items = [];
    var nextUrl = null;

    // Primary: search API
    var data = fetchJson(base + "/story/user/search/?q=" + encodeURIComponent(key || "") + "&page=" + pageNumber + "&page_size=20");
    if (data && data.results) {
        data.results.forEach(function (r) {
            if (!r.slug) return;
            items.push({
                name: cleanText(decodeHtmlEntities(r.title || r.slug)),
                link: base + "/truyen/" + r.slug,
                cover: absoluteUrl(r.cover_image || ""),
                description: cleanText(decodeHtmlEntities(r.description || ""))
            });
        });
        if (data.next) nextUrl = data.next;
    }

    // Fallback: browser
    if (items.length === 0) {
        var doc = fetchDocument(base + "/search?q=" + encodeURIComponent(key || ""));
        if (doc) {
            var coverImgs = doc.select("img[src*='/media/stories/']");
            var seen = {};
            coverImgs.forEach(function (img) {
                var src = img.attr("src");
                if (!src) return;
                var m = src.match(/\/media\/stories\/([a-z0-9-]+)\.[a-z]+/i);
                if (!m) return;
                var slug = m[1];
                if (seen[slug]) return;
                seen[slug] = true;

                var title = cleanText(decodeHtmlEntities(img.attr("alt"))) || slug;
                var titleLinks = doc.select("a[href*='/truyen/" + slug + "']");
                for (var i = 0; i < titleLinks.length; i++) {
                    var a = titleLinks.get(i);
                    var href = a.attr("href");
                    if (!href || /\/the-loai\/|\/tac-gia\/|\/chuong-/.test(href)) continue;
                    var txt = cleanText(decodeHtmlEntities(a.text())).replace(/\s+/g, " ").trim();
                    if (txt && txt.length >= 3) {
                        title = txt;
                        break;
                    }
                }

                items.push({
                    name: title,
                    link: base + "/truyen/" + slug,
                    cover: absoluteUrl(src),
                    description: ""
                });
            });
        }
    }

    return Response.success(items, nextUrl);
}