load("config.js");

function execute(url) {
    var base = removeTrailingSlash(BASE_URL);
    var slug = getNovelSlug(url);
    if (!slug) return null;

    // Primary: API
    var data = fetchJson(base + "/story/stories/?page=1&page_size=100");
    var story = null;
    if (data && data.results) {
        for (var i = 0; i < data.results.length; i++) {
            if (data.results[i].slug === slug) {
                story = data.results[i];
                break;
            }
        }
    }

    // Try detail endpoint if not found in page 1
    if (!story) {
        var detail = fetchJson(base + "/story/" + slug + "/");
        if (detail && detail.slug) story = detail;
    }

    if (story) {
        var status = story.is_completed ? "Hoàn thành" : "Đang tiến hành";
        if (story.status === "paused") status = "Tạm ngưng";

        var author = (story.author && story.author.name) || "";
        var description = cleanText(decodeHtmlEntities(story.description || ""));
        var cover = absoluteUrl(story.cover_image || "");

        var genres = [];
        var seenG = {};
        if (story.genres) {
            story.genres.forEach(function (g) {
                if (!g || !g.name) return;
                var key = normalizeKeyword(g.name);
                if (seenG[key]) return;
                seenG[key] = true;
                genres.push({
                    title: g.name,
                    input: base + "/truyen/the-loai/" + g.slug,
                    script: "gen.js"
                });
            });
        }

        var detailParts = [];
        if (author) detailParts.push("<b>Tác giả:</b> " + author);
        if (status) detailParts.push("<b>Tình trạng:</b> " + status);
        if (story.total_chapters) detailParts.push("<b>Số chương:</b> " + story.total_chapters);

        return Response.success({
            name: cleanText(decodeHtmlEntities(story.title || slug)),
            cover: cover,
            author: author,
            description: description,
            detail: detailParts.join("<br>"),
            host: BASE_URL,
            genres: genres,
            ongoing: status !== "Hoàn thành"
        });
    }

    // Fallback: browser scrape
    var doc = fetchDocument(url);
    if (!doc) return null;

    var name = "";
    var titleLink = doc.select("a[href*='/truyen/']").first();
    if (titleLink) name = cleanText(decodeHtmlEntities(titleLink.text())).replace(/\s+/g, " ").trim();
    if (!name) {
        var ogTitle = doc.select("meta[property='og:title']").attr("content");
        if (ogTitle) name = cleanText(decodeHtmlEntities(ogTitle));
    }

    var cover = "";
    if (slug) {
        var covers = doc.select("img[src*='media/stories/']");
        for (var i = 0; i < covers.length; i++) {
            var src = covers.get(i).attr("src");
            if (src && src.indexOf(slug) >= 0) {
                cover = absoluteUrl(src);
                break;
            }
        }
    }
    if (!cover) {
        var ogImage = doc.select("meta[property='og:image']").attr("content");
        if (ogImage) cover = absoluteUrl(ogImage);
    }

    var author = "";
    var authorLink = doc.select("a[href*='/tac-gia/']").first();
    if (authorLink) author = cleanText(authorLink.text()).replace(/\s+/g, " ").trim();

    var description = "";
    var descP = doc.select("p").first();
    if (descP) description = cleanText(decodeHtmlEntities(descP.text()));

    var status = "Đang tiến hành";
    var bodyText = doc.select("body").text();
    if (bodyText.indexOf("Hoàn thành") >= 0) status = "Hoàn thành";

    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: description,
        detail: "<b>Tác giả:</b> " + author + "<br><b>Tình trạng:</b> " + status,
        host: BASE_URL,
        genres: [],
        ongoing: status !== "Hoàn thành"
    });
}