// home.js - dich tieng hoa
function execute() {
    return Response.success([
        { title: "M\u1edbi c\u1eadp nh\u1eadt", input: "tim-kiem?sort=updatedAt:desc", script: "updated.js" },
        { title: "X\u1ebfp h\u1ea1ng truy\u1ec7n", input: "xep-hang", script: "homecontent.js" }
    ]);
}