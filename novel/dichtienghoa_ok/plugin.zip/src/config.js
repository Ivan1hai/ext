// config.js - dichtienghoa.net
var BASE_URL = "https://dichtienghoa.net";

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch { }
// CSS selectors used by site (Nuxt SSR HTML + Vue hydration)
var SEL = {
    heroH1: "h1.title",
    // home sections: list under each H2/H3 title
    homeSectionHeads: "h2,h3",
    // home tab sections (clickable "Xem thêm" button etc) - cards: a[href*=/truyen/]
    homeNovelLinks: "a[href^=\"/truyen/\"]",
    // search page - search input + suggestion list
    searchInput: "input.search-input",
    // detail page
    detailCover: ".header img, .image-box img",
    detailTitle: "h1.title",
    detailAuthor: ".info-box .author a, .meta-author",
    detailDesc: ".description, .intro",
    detailStatus: ".status",
    // chapter list (after clicking "Mục lục")
    chapListItems: ".chapter.clickable",
    chapTitle: ".chapter-title",
    // chapter body page
    chapBody: ".chapter-body",
    chapPageTitle: "h1.chapter-title",
    // pagination buttons in tab-panel
    pageBtn: ".tab-panel button"
};

// util: js extract text safe
function clean(s) {
    return (s || "").replace(/\s+/g, " ").trim();
}

function makeBrowser(timeout) {
    var b = Engine.newBrowser();
    return b;
}