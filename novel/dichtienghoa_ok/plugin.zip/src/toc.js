function parseNuxtChapters(html, storyId) {
    var match = String(html || "").match(/<script[^>]*id=["']__NUXT_DATA__["'][^>]*>([\s\S]*?)<\/script>/i);
    if (!match) return [];
    var payload = JSON.parse(match[1]), list = [], seen = {};
    for (var i = 0; i < payload.length; i++) {
        var row = payload[i];
        if (!row || typeof row !== "object" || typeof row.id !== "number" || typeof row.title !== "number") continue;
        var chapterId = payload[row.id], title = payload[row.title];
        if (typeof chapterId !== "string" || !/^\d+$/.test(chapterId) || typeof title !== "string" || !/^Chương\s*\d+/i.test(title) || seen[chapterId]) continue;
        seen[chapterId] = true;
        list.push({ name: title.replace(/\s+/g, " ").trim(), url: "/truyen/" + storyId + "/" + chapterId, host: "https://dichtienghoa.net" });
    }
    return list;
}

function execute(url) {
    var m = (url || "").match(/\/truyen\/(\d+)/);
    if (!m) return Response.error("URL truyen khong hop le");
    var storyId = m[1], browser = Engine.newBrowser();
    try {
        // page.js sinh /truyen/<id>?page=N; toc chỉ parse một trang.
        browser.launch("https://dichtienghoa.net" + url, 15000);
        var result = parseNuxtChapters(String(browser.html().html()), storyId);
        browser.close();
        return result.length ? Response.success(result) : Response.error("Khong thay chapter trong Nuxt SSR");
    } catch (e) {
        try { browser.close(); } catch (x) {}
        return Response.error("Tai muc luc SSR loi: " + e);
    }
}