// search.js - dichtienghoa.net
function execute(key, page) {
    key = (key || "").trim();
    if (!key) return Response.success([], "");
    var browser = Engine.newBrowser();
    var doc;
    try {
        browser.launch("https://dichtienghoa.net/tim-kiem?q=" + encodeURIComponent(key), 15000);
        sleep(6000);
        browser.callJs(extractSearchScript(), 2000);
        doc = browser.html();

        var data = doc.select("#vbook-search-data").attr("data-items") || "";
        var rows = data.split("\u0002");
        var list = [];
        for (var i = 0; i < rows.length; i++) {
            if (rows[i].length === 0) continue;
            var parts = rows[i].split("\u0001");
            list.push({ name: parts[0], link: parts[1], cover: parts[2] || "", description: "", host: "https://dichtienghoa.net" });
        }
        browser.close();
        return Response.success(list);
    } catch (e) {
        try { browser.close(); } catch (x) { }
        return Response.error("Khong the tim kiem");
    }
}

function extractSearchScript() {
    return "(function(){" +
        "var re=/\\/truyen\\/(\\d+)$/;" +
        "var out=[];" +
        "document.querySelectorAll('a[href*=\"/truyen/\"]').forEach(function(a){" +
        "var h=(a.getAttribute('href')||'').split('?')[0];" +
        "var m=h.match(re);if(!m)return;" +
        "h='/truyen/'+m[1];" +
        "var t=(a.querySelector('h3.story-title')||{}).title||a.getAttribute('title')||a.text();" +
        "t=(t||'').replace(/\\s+/g,' ').trim();" +
        "if(!t)t=h;" +
        "var im=a.querySelector('img');" +
        "var c=im?(im.currentSrc||im.src||im.getAttribute('src')||''):'';" +
        "out.push(t+'\\u0001'+h+'\\u0001'+c);" +
        "});" +
        "var d=document.createElement('div');d.id='vbook-search-data';d.style.display='none';" +
        "d.setAttribute('data-items',out.join('\\u0002'));document.body.appendChild(d);" +
        "})()";
}