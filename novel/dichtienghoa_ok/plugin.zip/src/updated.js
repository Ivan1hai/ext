// updated.js - truyện mới cập nhật (dichtienghoa.net)
// /tim-kiem là Nuxt SPA: SSR không render card, danh sách chỉ có sau JS hydration.
// Engine.newBrowser trong app không hydrate đủ -> gọi thẳng API /api/models/story.
// API cần cookie _csrfToken KHỚP giá trị _csrfToken trong query.
var DTH_BASE = "https://dichtienghoa.net";
try {
    if (CONFIG_URL) DTH_BASE = CONFIG_URL;
} catch (e) { }

function dthCover(url) {
    if (!url) return "";
    url = String(url);
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("http") === 0 || url.indexOf("data:") === 0) return url;
    return DTH_BASE + (url.charAt(0) === "/" ? "" : "/") + url;
}

function dthApiViaBrowser(sort, page) {
    var b = null;
    try {
        b = Engine.newBrowser();
        b.launch(DTH_BASE + "/tim-kiem?sort=" + encodeURIComponent(sort), 20000);
        sleep(6000);
        var q = String.fromCharCode(38);
        var js = "(function(){try{" +
            "var t=(document.cookie||'').match(/_csrfToken=([^;]+)/);t=t?decodeURIComponent(t[1]):'';" +
            "var u='/api/models/story?sort=" + sort.replace(/'/g, "%27") + q + "fast=1" + q + "page=" + page + q + "pageSize=48" + q + "_csrfToken='+encodeURIComponent(t);" +
            "var x=new XMLHttpRequest();x.open('GET',u,false);x.send(null);" +
            "var d=document.createElement('div');d.id='vbook-api';d.style.display='none';" +
            "d.setAttribute('data-st',String(x.status));d.setAttribute('data-body',String(x.responseText||'').substring(0,2000000));" +
            "document.body.appendChild(d);}catch(e){var d=document.createElement('div');d.id='vbook-api';d.style.display='none';" +
            "d.setAttribute('data-ex',String(e));document.body.appendChild(d);}})()";
        b.callJs(js, 15000);
        var doc = b.html();
        if (doc) {
            var el = doc.select("#vbook-api");
            if (el) return { st: el.attr("data-st") || "", body: el.attr("data-body") || "", ex: el.attr("data-ex") || "" };
        }
    } catch (e) { return { st: "EX", body: "", ex: String(e) }; }
    finally { try { if (b) b.close(); } catch (e) {} }
    return null;
}

function execute(input, page) {
    page = parseInt(page || "1", 10);
    if (!page || page < 1) page = 1;
    var sort = "updatedAt:desc";
    try {
        var m = String(input || "").match(/sort=([^&]+)/);
        if (m) sort = m[1];
    } catch (e) {}

    // VBook fetch() khong lo Set-Cookie trong response.headers.
    // Lay _csrfToken tu document.cookie cua browser (da xac minh 43 ky tu).
    var csrf = "";
    var browser = null;
    try {
        browser = Engine.newBrowser();
        browser.launch(DTH_BASE + "/tim-kiem?sort=" + encodeURIComponent(sort), 20000);
        sleep(6000);
        browser.callJs("(function(){var d=document.createElement('div');d.id='vbook-csrf';d.style.display='none';" +
            "d.setAttribute('data-token',(document.cookie||'').match(/_csrfToken=([^;]+)/)?decodeURIComponent(RegExp.$1):'');" +
            "document.body.appendChild(d);})()", 3000);
        var cdoc = browser.html();
        if (cdoc) {
            var el = cdoc.select("#vbook-csrf");
            if (el) csrf = el.attr("data-token") || "";
        }
    } catch (e) {
        csrf = "";
    }

// Buoc 2: goi API voi query _csrfToken khop cookie
    try { if (browser) browser.close(); } catch (x) {}
    var apiUrl = DTH_BASE + "/api/models/story?sort=" + encodeURIComponent(sort) +
        "&fast=1&page=" + page + "&pageSize=48&_csrfToken=" + encodeURIComponent(csrf);
    var headers = {
        Accept: "application/json",
        "User-Agent": UserAgent.android(),
        Referer: DTH_BASE + "/tim-kiem",
        Origin: DTH_BASE
    };
    if (csrf) headers.Cookie = "_csrfToken=" + csrf;

    var stories = [];
    var stFetch = "-", stBrowser = "-", exMsg = "";
    try {
        var r = fetch(apiUrl, { headers: headers });
        stFetch = r ? r.status : "null";
        if (r && r.ok) {
            var json = JSON.parse(r.text());
            stories = (json && json.data) || [];
        }
    } catch (e) { exMsg += "fetchEx=" + e + " "; }

    if (!stories.length) {
        var bx = dthApiViaBrowser(sort, page);
        if (bx) {
            stBrowser = bx.st || "null";
            try {
                var bj = JSON.parse(bx.body);
                stories = (bj && bj.data) || [];
            } catch (e2) { exMsg += "browserParse=" + e2 + " body=" + String(bx.body).substring(0, 120) + " "; }
            if (!stories.length) exMsg += "browserEx=" + (bx.ex || "") + " ";
        }
    }
    if (!stories.length) return Response.error("API rong stFetch=" + stFetch + " stBrowser=" + stBrowser + " csrfLen=" + csrf.length + " " + exMsg);

    var list = [];
    for (var i = 0; i < stories.length; i++) {
        var s = stories[i];
        if (!s || !s.id || !s.title) continue;
        list.push({
            name: String(s.title).replace(/\s+/g, " ").trim(),
            link: "/truyen/" + s.id,
            cover: dthCover(s.imgUrl || s.cover || s.image || ""),
            description: String(s.description || "").replace(/\s+/g, " ").trim().substring(0, 200),
            host: DTH_BASE
        });
    }
    if (!list.length) return Response.error("API tra danh sach rong; csrfLen=" + csrf.length);
    return Response.success(list, page < 2 ? String(page + 1) : "");
}