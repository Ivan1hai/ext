// homecontent.js - dich tieng hoa
function execute(input, page) {
    page = page || "1";
    var browser = Engine.newBrowser();
    var url = "https://dichtienghoa.net/" + input;
    var doc;
    try {
        browser.launch(url, 15000);
        sleep(5000);
        browser.callJs(
            "(function(){" +
            "var out=[],seen={};" +
            "document.querySelectorAll('a[href^=\\\"/truyen/\\\"]').forEach(function(a){" +
            "var h=(a.getAttribute('href')||'').split('?')[0];" +
            "if(!/^\\/truyen\\/\\d+$/.test(h)||seen[h])return;" +
            "var p=a,txt='';" +
            "for(var i=0;i<4&&p;i++,p=p.parentElement){txt=(p.innerText||'').replace(/\\s+/g,' ').trim();if(txt.length>3)break;}" +
            "var im=a.querySelector('img'),c=im?(im.currentSrc||im.src||im.getAttribute('src')||''):'';" +
            "seen[h]=1;out.push(h+'\\u0001'+txt+'\\u0001'+c);" +
            "});" +
            "var d=document.createElement('div');d.id='vbook-data';d.style.display='none';d.setAttribute('data-items',out.join('\\u0002'));document.body.appendChild(d);" +
            "})()", 1500
        );
        doc = browser.html();
    } catch (e) {
        try { browser.close(); } catch (x) {}
        return Response.error("Khong the mo trang: " + url);
    }
    var list = [];
    try {
        var data = doc.select("#vbook-data").attr("data-items") || "";
        var rows = data.split("\u0002");
        for (var i = 0; i < rows.length; i++) {
            var parts = rows[i].split("\u0001");
            if (parts.length < 2 || !parts[0] || !parts[1]) continue;
            list.push({ name: parts[1], link: parts[0], cover: parts.length > 2 ? normalizeCover(parts[2]) : "", description: "", host: "https://dichtienghoa.net" });
        }
    } catch (e) {
        try { browser.close(); } catch (x) {}
        return Response.error("Parse danh sach loi");
    }
    try { browser.close(); } catch (x) {}
    return Response.success(list);
}

function normalizeCover(url) {
    if (!url) return "";
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("http") === 0) return url;
    return "https://dichtienghoa.net" + (url.charAt(0) === "/" ? "" : "/") + url;
}