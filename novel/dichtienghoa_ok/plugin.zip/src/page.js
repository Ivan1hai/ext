function execute(url) {
    var m = (url || "").match(/\/truyen\/(\d+)/);
    if (!m) return Response.success([url]);
    var storyId = m[1], browser = Engine.newBrowser();
    try {
        browser.launch("https://dichtienghoa.net/truyen/" + storyId, 15000);
        var html = String(browser.html().html());
        browser.close();
        var totalMatch = html.match(/"numberOfPages"\s*:\s*(\d+)/);
        var total = totalMatch ? parseInt(totalMatch[1], 10) : 0;
        if (!total) {
            var badge = html.match(/action-button__badge[^>]*>\s*(\d+)\s*</);
            total = badge ? parseInt(badge[1], 10) : 0;
        }
        var pages = Math.max(1, Math.ceil(total / 300)), list = [];
        for (var i = 1; i <= pages; i++) list.push("/truyen/" + storyId + "?page=" + i);
        return Response.success(list);
    } catch (e) {
        try { browser.close(); } catch (x) {}
        return Response.success(["/truyen/" + storyId]);
    }
}