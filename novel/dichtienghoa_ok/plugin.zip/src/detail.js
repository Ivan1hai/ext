// detail.js - dichtienghoa.net

function execute(url) {
    var id = extractId(url);
    if (!id) return Response.error("URL truyen khong hop le");

    var browser = Engine.newBrowser();
    var doc;
    try {
        browser.launch("https://dichtienghoa.net/truyen/" + id, 15000);
        sleep(5000);
        browser.callJs(extractDetailScript(), 1500);
        doc = browser.html();
    } catch (e) {
        try { browser.close(); } catch (x) {}
        return Response.error("Khong the mo chi tiet truyen");
    }

    try {
        var data = parseData(doc);
        browser.close();
        if (!data.name) return Response.error("Khong tim thay ten truyen");
        return Response.success({
            name: data.name,
            cover: data.cover,
            author: data.author,
            description: data.description,
            detail: data.detail,
            ongoing: !/hoan thanh|da hoan thanh/i.test(data.detail),
            host: "https://dichtienghoa.net"
        });
    } catch (e) {
        try { browser.close(); } catch (x) {}
        return Response.error("Parse chi tiet loi");
    }
}

function extractId(url) {
    var m = (url || "").match(/\/truyen\/(\d+)/);
    return m ? m[1] : "";
}

function extractDetailScript() {
    return "(function(){" +
        "var q=function(s){var e=document.querySelector(s);return e?(e.innerText||'').replace(/\\s+/g,' ').trim():''};" +
        "var h=document.querySelector('h1.title');" +
        "var im=document.querySelector('.image-box img, .header img');" +
        "var d=document.createElement('div');d.id='vbook-detail';d.style.display='none';" +
        "d.setAttribute('data-name',h?(h.innerText||'').trim():'');" +
        "d.setAttribute('data-cover',im?(im.currentSrc||im.src||''):'');" +
        "d.setAttribute('data-author',q('.author,.meta-author'));" +
        "d.setAttribute('data-description',q('.description,.intro,.book-description'));" +
        "d.setAttribute('data-detail',q('.info,.book-info,.meta,.status'));" +
        "document.body.appendChild(d);})()";
}

function parseData(doc) {
    var d = doc.select("#vbook-detail");
    return {
        name: d.attr("data-name"),
        cover: d.attr("data-cover"),
        author: d.attr("data-author"),
        description: d.attr("data-description"),
        detail: d.attr("data-detail")
    };
}