// chap.js - dichtienghoa.net
function execute(url) {
    var m = (url || "").match(/\/truyen\/(\d+)\/(\d+)/);
    if (!m) return Response.error("URL chapter khong hop le");
    var browser = Engine.newBrowser();
    try {
        browser.launch("https://dichtienghoa.net/truyen/" + m[1] + "/" + m[2], 15000);
        sleep(5000);
        var doc = browser.html();
        var body = doc.select(".chapter-body");
        if (body.size() === 0) {
            browser.close();
            return Response.error("Khong tim thay noi dung chapter");
        }
        var html = body.html();
        browser.close();
        return Response.success(html.replace(/\n{3,}/g, "\n\n").trim());
    } catch (e) {
        try { browser.close(); } catch (x) {}
        return Response.error("Khong the tai chapter");
    }
}