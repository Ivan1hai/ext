load("config.js");

// v7 — ported from another/novel_lct_fix which works in vBook app.
// vBook Rhino Browser engine hangs on CF-che sites, so use bare fetch
// for the story page (regex __NEXT_DATA__) and direct POST for chapter list.
var TOC_ITEMS_PER_PAGE = 200;
var TOC_MAX_PAGE = 80;

function buildEncryptedTocBody(storyId, page, itemsPerPage) {
    var params = {
        id_story: storyId,
        page: page,
        items_per_page: itemsPerPage,
        order: "ASC"
    };
    var encryptedBody = {};
    for (var key in params) {
        if (!Object.prototype.hasOwnProperty.call(params, key)) continue;
        encryptedBody[key] = encrypt(String(params[key]));
    }
    return encryptedBody;
}

function parseEncryptedChapterList(resJson) {
    if (!resJson || !resJson.data) return [];
    var decryptedData = decrypt(resJson.data);
    if (!decryptedData) return [];
    try {
        var list = JSON.parse(decryptedData);
        return Array.isArray(list) ? list : [];
    } catch (e) {
        return [];
    }
}

function mapChapters(chapters) {
    var list = [];
    for (var i = 0; i < chapters.length; i++) {
        var item = chapters[i] || {};
        if (!item.slug) continue;
        list.push({
            name: item.title || ("Chương " + (list.length + 1)),
            url: formatChapterUrl(item.slug),
            host: BASE_URL,
            pay: !!(item.locked || item.is_locked || item.not_free === true || item.not_free === "true")
        });
    }
    return list;
}

function mapFirstChapterFallback(firstChapter) {
    if (!Array.isArray(firstChapter) || !firstChapter.length) return [];
    return firstChapter.map(function (item) {
        var name = item.title || ("Chương " + item.chapter_order);
        return {
            name: name,
            url: formatChapterUrl(item.slug),
            host: BASE_URL,
            pay: !!(item.locked || item.is_locked || item.not_free === true || item.not_free === "true")
        };
    });
}

function fetchTocPage(storyId, page, itemsPerPage, storyUrl) {
    var encryptedBody = buildEncryptedTocBody(storyId, page, itemsPerPage);
    var apiResponse = fetch(BASE_URL + "/api/chapters/list-chapters", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Origin": BASE_URL,
            "Referer": storyUrl || BASE_URL + "/"
        },
        body: JSON.stringify(encryptedBody)
    });

    if (!apiResponse || !apiResponse.ok) {
        return { ok: false, chapters: [] };
    }

    var apiJson = safeJson(apiResponse);
    return { ok: true, chapters: parseEncryptedChapterList(apiJson) };
}

function fetchStoryPageHtml(storyUrl) {
    try {
        var resp = fetch(storyUrl, {
            method: "GET",
            headers: buildHeaders({ "Referer": BASE_URL + "/" })
        });
        if (resp && resp.ok) return resp.html();
    } catch (e) {
    }
    return null;
}

function execute(url) {
    var storyUrl = normalizeStoryUrl(url || "");
    storyUrl = stripQueryAndHash(storyUrl).replace(/\/+$/, "");
    if (!storyUrl) return Response.error("URL truyện không hợp lệ");

    var pageData = null;
    var doc = fetchStoryPageHtml(storyUrl);
    if (doc) pageData = parseNextDataFromHtmlText(doc);
    if (!pageData) pageData = parseNextDataByUrl(storyUrl);

    if (!pageData || !pageData.props || !pageData.props.pageProps || !pageData.props.pageProps.story) {
        return Response.error("Không đọc được thông tin truyện");
    }

    var story = pageData.props.pageProps.story || {};
    var storyId = story.id;
    if (!storyId) return Response.error("Thiếu mã truyện");

    var firstChapter = pageData.props.pageProps.firstChapter || [];

    var allChapters = [];
    for (var page = 1; page <= TOC_MAX_PAGE; page++) {
        var pageResult = fetchTocPage(storyId, page, TOC_ITEMS_PER_PAGE, storyUrl);
        if (!pageResult.ok) {
            if (page === 1 && Array.isArray(firstChapter) && firstChapter.length) {
                return Response.success(mapFirstChapterFallback(firstChapter));
            }
            if (page === 1) return Response.error("Không thể tải mục lục");
            break;
        }

        var chapters = pageResult.chapters;
        if (!chapters.length) break;

        var mapped = mapChapters(chapters);
        for (var i = 0; i < mapped.length; i++) allChapters.push(mapped[i]);

        if (chapters.length < TOC_ITEMS_PER_PAGE) break;
    }

    if (!allChapters.length) return Response.error("Không có chương");
    return Response.success(allChapters);
}
