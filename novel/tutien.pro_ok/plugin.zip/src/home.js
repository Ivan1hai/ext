load('config.js');

function execute() {
    return Response.success([
        { title: 'Mới cập nhật', input: BASE_URL + '/truyen/truyen-moi/', script: 'gen.js' },
        { title: 'Hoàn thành', input: BASE_URL + '/truyen/truyen-hoan-thanh/', script: 'gen.js' },
        { title: 'BXH lượt đọc', input: BASE_URL + '/truyen/xep-hang/view', script: 'gen.js' },
        { title: 'BXH đề cử', input: BASE_URL + '/truyen/xep-hang/user', script: 'gen.js' },
        { title: 'BTV đề cử', input: BASE_URL + '/truyen/xep-hang/admin', script: 'gen.js' },
    ]);
}