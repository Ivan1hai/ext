load('config.js');

function execute(url, page) {
    if (!page) page = '1';

    var full = removeTrailingSlash(url);
    if (page !== '1') {
        full = full + '?page=' + page;
    }

    var doc = fetchDocument(full);
    if (!doc) return Response.success([]);

    var list = [];
    var seen = {};

    // Tutien.pro uses Tailwind grid: div.grid.grid-cols-1.md:grid-cols-2.gap-6
    // Each card: div with flex gap-4, inside: img + div.w-4/5 with <a>
    // Selector: find all <a> linking to /truyen/<slug> inside the grid

    // Primary: direct <a> links inside grid container
    var cards = doc.select('.grid a[href*="/truyen/"]');
    if (cards.size() === 0) {
        // Fallback: any <a> to /truyen/ with text content
        cards = doc.select('a[href*="/truyen/"]').not('a[href*="/chuong-"]');
    }

    cards.forEach(function(a) {
        var href = a.attr('href');
        var link = absoluteUrl(href);
        var name = tidy(decodeHtmlEntities(a.text()));
        if (!name || !link || name.length < 3) return;

        var slug = getNovelSlug(link);
        if (slug && seen[slug]) return;
        if (slug) seen[slug] = true;

        // Go up to find parent card for cover + description
        var card = a;
        for (var i = 0; i < 6; i++) {
            var parent = card.parent();
            if (!parent) break;
            card = parent;
        }

        var cover = '';
        var img = card.select('img').first();
        if (img) {
            cover = img.attr('data-src') || img.attr('data-lazy-src') || img.attr('src') || '';
            if (cover && cover.indexOf('nocover') === -1) cover = absoluteUrl(cover);
        }

        var description = '';
        var descEl = card.select('p.line-clamp-2').first();
        if (!descEl) descEl = card.select('p.text-gray-700, p.text-gray-400').first();
        if (!descEl) descEl = card.select('p').first();
        if (descEl) {
            description = tidy(decodeHtmlEntities(descEl.text()));
        }

        list.push({
            name: name,
            link: link,
            cover: cover,
            description: description,
            host: BASE_URL
        });
    });

    var next = '';
    if (list.length >= 10) {
        next = removeTrailingSlash(full).replace(/[?&]page=\d+/g, '') + '?page=' + (parseInt(page) + 1);
    }

    return Response.success(list, next);
}