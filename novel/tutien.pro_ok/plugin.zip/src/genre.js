load('config.js');

function execute() {
    var doc = fetchDocument(BASE_URL + '/');
    if (!doc) return Response.success([]);

    var genres = [];
    var seen = {};

    // Try genre links from header/menu
    var genreLinks = doc.select('a.genre-link, a[href*="/the-loai/"], a[href*="/genre/"], .menu-genre a');
    if (genreLinks.size() === 0) {
        genreLinks = doc.select('.uk-navbar-nav a[href*="/truyen/"], .navbar a[href*="/truyen/"]');
    }

    genreLinks.forEach(function(el) {
        var name = tidy(decodeHtmlEntities(el.text()));
        var href = absoluteUrl(el.attr('href'));
        if (!name || !href || name.length > 20) return;
        var key = normalizeKeyword(name);
        if (!key || seen[key]) return;
        seen[key] = true;
        genres.push({ title: name, input: href, script: 'gen.js' });
    });

    // Fallback: hardcoded common genres tu tiên sites
    if (genres.length === 0) {
        genres = [
            { title: 'Tiên Hiệp', input: BASE_URL + '/the-loai/tien-hiep/', script: 'gen.js' },
            { title: 'Kiếm Hiệp', input: BASE_URL + '/the-loai/kiem-hiep/', script: 'gen.js' },
            { title: 'Huyền Ảo', input: BASE_URL + '/the-loai/huyen-ao/', script: 'gen.js' },
            { title: 'Đô Thị', input: BASE_URL + '/the-loai/do-thi/', script: 'gen.js' },
            { title: 'Lịch Sử', input: BASE_URL + '/the-loai/lich-su/', script: 'gen.js' },
            { title: 'Khoa Huyễn', input: BASE_URL + '/the-loai/khoa-huyen/', script: 'gen.js' },
            { title: 'Linh Dị', input: BASE_URL + '/the-loai/linh-di/', script: 'gen.js' },
        ];
    }

    return Response.success(genres);
}