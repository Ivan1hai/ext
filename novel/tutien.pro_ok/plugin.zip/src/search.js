load('config.js');

function execute(key, page) {
    var keyword = key ? normalizeKeyword(key) : '';
    var pageNumber = parseIntSafe(page, 1);

    // Try search API if exists (wp-json/initmanga/v1/search)
    if (keyword) {
        var searchApi = BASE_URL + '/wp-json/initmanga/v1/search?keyword=' + encodeURIComponent(key) + '&paged=' + pageNumber;
        var data = fetchJson(searchApi);
        if (data && data.items) {
            var list = [];
            data.items.forEach(function(item) {
                list.push({
                    name: tidy(decodeHtmlEntities(item.name || item.title || '')),
                    link: BASE_URL + '/truyen/' + (item.slug || '') + '/',
                    cover: absoluteUrl(item.cover || item.image || ''),
                    description: tidy(item.author || ''),
                    host: BASE_URL
                });
            });
            var next = data.total_pages && pageNumber < data.total_pages ? String(pageNumber + 1) : '';
            return Response.success(list, next);
        }
    }

    // Fallback: scrape list page with keyword filter
    // tutien.pro likely has /tim-kiem/ or similar search page
    var searchUrl = BASE_URL + '/danh-sach-truyen/';
    if (pageNumber > 1) searchUrl += 'page/' + pageNumber + '/';

    var doc = fetchDocument(searchUrl);
    if (!doc) return Response.success([]);

    var list = [];
    var items = doc.select('div.uk-panel.uk-position-relative');
    if (items.size() === 0) items = doc.select('.uk-panel.uk-margin-small-bottom.uk-position-relative');
    if (items.size() === 0) items = doc.select('.story-item, .book-item, .novel-item');

    items.forEach(function(item) {
        var titleEl = item.select('h3 a.uk-link-heading').first();
        if (!titleEl) titleEl = item.select('h3 a').first();
        if (!titleEl) titleEl = item.select('a[href*="/truyen/"]').first();
        if (!titleEl) return;

        var name = tidy(decodeHtmlEntities(titleEl.text()));
        var link = absoluteUrl(titleEl.attr('href'));
        if (!name || !link) return;

        // Keyword filter
        if (keyword && normalizeKeyword(name).indexOf(keyword) < 0) return;

        var cover = '';
        var img = item.select('img').first();
        if (img) {
            cover = img.attr('data-src') || img.attr('data-lazy-src') || img.attr('src') || '';
            if (cover && cover.indexOf('nocover') === -1) cover = absoluteUrl(cover);
        }

        list.push({ name: name, link: link, cover: cover, description: '', host: BASE_URL });
    });

    // Pagination
    var next = '';
    var pagLinks = doc.select('.uk-pagination li a[href]');
    if (pagLinks.size() > 0) {
        var current = pageNumber;
        pagLinks.forEach(function(el) {
            var m = el.attr('href').match(/page\/(\d+)/);
            if (m && parseInt(m[1]) > current) next = absoluteUrl(el.attr('href'));
        });
    } else if (list.length >= 10) {
        next = String(pageNumber + 1);
    }

    return Response.success(list, next);
}