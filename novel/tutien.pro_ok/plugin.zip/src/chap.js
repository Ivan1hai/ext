load('config.js');

function execute(url) {
    // Extract chapter number and novel slug
    var chMatch = url.match(/chuong-(\d+)/);
    var chapterNum = chMatch ? chMatch[1] : null;
    var slug = getNovelSlug(url);
    if (!slug) return Response.error('Không xác định được truyện.');

    var base = BASE_URL + '/truyen/' + slug;

    // Try API content via manga_id
    var detailUrl = base + '/';
    var detailDoc = fetchDocument(detailUrl);
    var mangaId = null;

    if (detailDoc) {
        var titleEl = detailDoc.select('#manga-title').first();
        if (titleEl) {
            var dataId = titleEl.attr('data-id');
            mangaId = parseIntSafe(dataId, null);
        }
        if (!mangaId) {
            var scripts = detailDoc.select('script');
            scripts.forEach(function(s) {
                var m = s.html().match(/manga_id["\s:=]+(\d+)/);
                if (m) mangaId = parseIntSafe(m[1], null);
            });
        }
    }

    if (mangaId && chapterNum) {
        // Find chapter ID from chapters list
        var apiChapters = BASE_URL + '/wp-json/initmanga/v1/chapters?manga_id=' + mangaId + '&paged=1&per_page=100';
        var data = fetchJson(apiChapters);
        if (data && data.items) {
            var chNumber = parseInt(chapterNum, 10);
            for (var i = 0; i < data.items.length; i++) {
                if (data.items[i].number === chNumber) {
                    var chApi = BASE_URL + '/wp-json/initmanga/v1/chapter/' + data.items[i].id;
                    var chData = fetchJson(chApi);
                    if (chData && chData.content) {
                        return Response.success(sanitizeContent(chData.content));
                    }
                    break;
                }
            }
        }
    }

    // Fallback: scrape HTML
    var doc = fetchDocument(url);
    if (!doc) return Response.error('Không tải được chương.');

    var contentDiv = doc.select('#chapter-content').first();
    if (!contentDiv) contentDiv = doc.select('.chapter-content, .reading-content, .entry-content, .content').first();
    if (!contentDiv) contentDiv = doc.select('article').first();

    if (!contentDiv) return Response.error('Không thấy nội dung.');

    contentDiv.select('script, style, ins, iframe, .adsbygoogle, .contentadv, .bottom-ad, .imc-app-block, .imc-preview-fade, noscript').remove();

    var html = contentDiv.html();
    if (!html || html.trim().length < 10) {
        html = contentDiv.text();
        if (html) html = '<p>' + html.replace(/\n+/g, '</p><p>') + '</p>';
    }
    if (!html || html.trim().length < 10) return Response.error('Trống.');

    return Response.success(sanitizeContent(html));
}

function sanitizeContent(html) {
    if (!html) return '';
    html = html.replace(/&nbsp;/g, ' ');
    html = html.replace(/(<br\s*\/?>\s*){2,}/gi, '<br>');
    // Remove chapter title from content
    html = html.replace(/^(?:Chương\s*\d+[:\s]*.*?)(?:<br>)?/i, '');
    return html;
}