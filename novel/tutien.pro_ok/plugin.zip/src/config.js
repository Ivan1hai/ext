var BASE_URL = "https://tutien.pro";
let SESSION_COOKIE = '';
try { if (CONFIG_COOKIE) SESSION_COOKIE = CONFIG_COOKIE; } catch(e) {}

var HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Referer": BASE_URL + "/",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7"
};
if (SESSION_COOKIE) {
    HEADERS["Cookie"] = SESSION_COOKIE;
}

// Site is Next.js SPA - HTML from fetch() is empty <div id="root">.
// MUST use browser to get rendered content.
function fetchDocument(url) {
    // Try Engine.newBrowser first (with CF cookie in headers)
    try {
        var browser = Engine.newBrowser();
        if (browser) {
            browser.launch(url, 15000);
            sleep(3000);  // wait for React to render
            var doc = browser.html();
            if (doc && doc.select('a[href*="/truyen/"]').size() > 0) {
                return doc;
            }
            if (doc && doc.select('#chapter-content').size() > 0) {
                return doc;
            }
            // If browser got Cloudflare page, return null
            try { browser.close(); } catch(e) {}
        }
    } catch (e) {}

    // Fallback: fetch (won't work for SPA but try anyway)
    try {
        var response = fetch(url, { headers: HEADERS });
        if (response && response.ok) {
            var doc2 = response.html();
            if (doc2) return doc2;
        }
    } catch (e2) {}

    return null;
}

function fetchJson(url) {
    try {
        var response = fetch(url, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36",
                "Accept": "application/json",
                "Cookie": SESSION_COOKIE
            }
        });
        if (response && response.ok) {
            return JSON.parse(response.content());
        }
    } catch (e) {}
    return null;
}

function tidy(s) {
    return (s || '').replace(/\s+/g, ' ').trim();
}

function fullUrl(path) {
    if (!path) return '';
    if (path.indexOf('http') === 0) return path;
    if (path.indexOf('//') === 0) return 'https:' + path;
    return BASE_URL + (path.charAt(0) === '/' ? '' : '/') + path;
}

function getNovelSlug(url) {
    var match = url.match(/\/truyen\/([^\/?#]+)/);
    return match ? match[1] : "";
}

function parseIntSafe(text, fallback) {
    var value = parseInt(text, 10);
    return isNaN(value) ? fallback : value;
}

function decodeHtmlEntities(text) {
    if (!text) return "";
    return text
        .replace(/&#(\d+);/g, function(_, c) { return String.fromCharCode(parseInt(c, 10)); })
        .replace(/&#x([0-9a-fA-F]+);/g, function(_, c) { return String.fromCharCode(parseInt(c, 16)); })
        .replace(/&nbsp;/gi, " ")
        .replace(/&amp;/gi, "&")
        .replace(/&quot;/gi, '"')
        .replace(/&#039;|&apos;/gi, "'")
        .replace(/&lt;/gi, "<")
        .replace(/&gt;/gi, ">")
        .replace(/&hellip;/gi, "...");
}

function normalizeKeyword(text) {
    text = tidy(decodeHtmlEntities(text)).toLowerCase();
    if (!text) return "";
    var map = {
        a: /[àáạảãâầấậẩẫăằắặẳẵ]/g,
        e: /[èéẹẻẽêềếệểễ]/g,
        i: /[ìíịỉĩ]/g,
        o: /[òóọỏõôồốộổỗơờớợởỡ]/g,
        u: /[ùúụủũưừứựửữ]/g,
        y: /[ỳýỵỷỹ]/g,
        d: /đ/g
    };
    for (var k in map) {
        text = text.replace(map[k], k);
    }
    return text.replace(/[^a-z0-9\s-]/g, " ").replace(/\s+/g, " ").trim();
}

var cleanText = tidy;
var absoluteUrl = fullUrl;
var removeTrailingSlash = function(t) { return t ? t.replace(/\/+$/, "") : ""; };