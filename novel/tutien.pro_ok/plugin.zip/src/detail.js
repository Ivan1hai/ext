load('config.js');

function execute(url) {
    var doc = fetchDocument(url);
    if (!doc) return Response.error('Không tải được trang.');

    // Name: h1#manga-title (like truyencv.io) or og:title
    var name = '';
    var h1 = doc.select('h1#manga-title').first();
    if (h1) name = tidy(h1.text());
    if (!name) {
        var titleMeta = doc.select('meta[property="og:title"]').attr('content');
        if (titleMeta) name = tidy(decodeHtmlEntities(titleMeta.replace(/\s*[-–|]\s*Tu Tiên.*$/, '')));
    }
    if (!name) {
        var h1any = doc.select('h1').first();
        if (h1any) name = tidy(h1any.text());
    }

    // Cover
    var cover = '';
    var coverImg = doc.select('.story-cover-wrap img, .story-cover img, .book-img img').first();
    if (coverImg) {
        cover = coverImg.attr('data-src') || coverImg.attr('data-lazy-src') || coverImg.attr('src') || '';
    }
    if (!cover) {
        var ogImg = doc.select('meta[property="og:image"]').attr('content');
        if (ogImg) cover = ogImg;
    }
    cover = absoluteUrl(cover);

    // Author + Status + Genres from .manga-info-details (truyencv.io pattern)
    var author = '';
    var status = '';
    var description = '';
    var genres = [];
    var genreSeen = {};
    var detailParts = [];

    var infoDiv = doc.select('.manga-info-details').first();
    if (!infoDiv) infoDiv = doc.select('.story-detail, .book-info, .novel-info, .detail-info').first();

    if (infoDiv) {
        // Author
        var authorLink = infoDiv.select('a').first();
        if (authorLink) author = tidy(authorLink.text());
        if (!author) {
            var authorMatch = infoDiv.text().match(/Tác giả:\s*([^\n]+)/i);
            if (authorMatch) author = tidy(authorMatch[1]);
        }

        // Status
        var statusMatch = infoDiv.text().match(/Tình trạng:\s*([^\n]+)/i);
        if (statusMatch) {
            var st = tidy(decodeHtmlEntities(statusMatch[1])).toLowerCase();
            if (st.indexOf('hoan thanh') >= 0 || st.indexOf('trọn bộ') >= 0 || st.indexOf('full') >= 0) {
                status = 'Hoàn thành';
            } else if (st.indexOf('tam ngung') >= 0) {
                status = 'Tạm ngưng';
            } else {
                status = 'Đang tiến hành';
            }
        }

        // Genres
        infoDiv.select('a.genre-pill, a[href*="/the-loai/"]').forEach(function(el) {
            var title = tidy(el.text());
            if (title && title.length < 30) {
                var key = normalizeKeyword(title);
                if (!genreSeen[key]) {
                    genreSeen[key] = true;
                    genres.push({ title: title, input: absoluteUrl(el.attr('href')), script: 'gen.js' });
                }
            }
        });

        // Chapter count
        var chMatch = infoDiv.text().match(/(\d+[\d\.,]*)\s*(?:Chương|chương)/i);
        if (chMatch) detailParts.push('Số chương: ' + chMatch[1]);
    }

    // Description: schema ld+json or og:description
    var schemaEl = doc.select('script[type="application/ld+json"]').first();
    if (schemaEl) {
        try {
            var json = JSON.parse(schemaEl.html());
            if (json && json.description) description = tidy(decodeHtmlEntities(json.description));
        } catch (e) {}
    }
    if (!description) {
        var descEl = doc.select('.manga-excerpt, .story-summary, .description, .book-desc, .intro').first();
        if (descEl) {
            descEl.select('script, style, ins, iframe').remove();
            description = descEl.html() || tidy(descEl.text());
        }
    }
    if (!description) {
        var ogDesc = doc.select('meta[property="og:description"]').attr('content');
        if (ogDesc) description = tidy(decodeHtmlEntities(ogDesc));
    }

    if (author) detailParts.push('Tác giả: ' + author);
    if (status) detailParts.push('Tình trạng: ' + status);
    if (!status) {
        // Check for "full" / "hoàn thành" keyword in body
        var bodyText = doc.text();
        if (bodyText.indexOf('Hoàn thành') >= 0 || bodyText.indexOf('Full') >= 0 || bodyText.indexOf('Trọn bộ') >= 0) {
            status = 'Hoàn thành';
        } else {
            status = 'Đang tiến hành';
        }
        detailParts.push('Tình trạng: ' + status);
    }

    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: description,
        detail: detailParts.join('<br>'),
        ongoing: status !== 'Hoàn thành',
        genres: genres.length > 0 ? genres : undefined,
        host: BASE_URL
    });
}