load('config.js');

function execute(url) {
    var doc = fetchDocument(url);
    if (!doc) return Response.success([]);

    var slug = getNovelSlug(url);
    var base = BASE_URL + '/truyen/' + slug;

    // Try API first (same as truyencv.io: initmanga)
    var mangaId = null;
    var titleEl = doc.select('#manga-title').first();
    if (titleEl) {
        var dataId = titleEl.attr('data-id');
        mangaId = parseIntSafe(dataId, null);
    }
    if (!mangaId) {
        var bodyClass = doc.select('body').attr('class');
        var idMatch = bodyClass ? bodyClass.match(/postid-(\d+)/) : null;
        if (idMatch) mangaId = parseIntSafe(idMatch[1], null);
    }
    // Try script var
    if (!mangaId) {
        var scripts = doc.select('script');
        scripts.forEach(function(s) {
            var m = s.html().match(/manga_id["\s:=]+(\d+)/);
            if (m) mangaId = parseIntSafe(m[1], null);
        });
    }

    if (mangaId) {
        // Fetch chapters via API
        var chapters = [];
        var apiBase = removeTrailingSlash(BASE_URL) + '/wp-json/initmanga/v1/chapters';

        var data = fetchJson(apiBase + '?manga_id=' + mangaId + '&paged=1&per_page=50');
        if (!data || !data.items) data = fetchJson(apiBase + '?manga_id=' + mangaId + '&paged=1&per_page=100');
        if (!data || !data.items) data = fetchJson(apiBase + '?manga_id=' + mangaId + '&paged=1&per_page=200');

        if (data && data.items) {
            // All pages
            var totalPages = data.total_pages || 1;
            for (var p = 1; p <= totalPages; p++) {
                var pageData = p === 1 ? data : fetchJson(apiBase + '?manga_id=' + mangaId + '&paged=' + p + '&per_page=50');
                if (!pageData || !pageData.items) continue;
                for (var j = 0; j < pageData.items.length; j++) {
                    var ch = pageData.items[j];
                    var chNum = ch.number || ch.chapter_number || '';
                    var chTitle = ch.title || ch.name || '';
                    var label = 'Chương ' + chNum + (chTitle ? ': ' + tidy(decodeHtmlEntities(chTitle)) : '');
                    chapters.push({
                        name: label,
                        url: base + '/chuong-' + chNum + '/',
                        host: BASE_URL
                    });
                }
            }
            if (chapters.length > 0) {
                chapters.reverse();
                return Response.success(chapters);
            }
        }
    }

    // Fallback: scrape HTML chapter list
    return tocFallback(doc, base);
}

function tocFallback(doc, base) {
    var chapters = [];

    // Pattern from truyencv.io: #chapter-list .chapter-item a.uk-link-toggle
    var links = doc.select('#chapter-list .chapter-item a.uk-link-toggle');
    if (links.size() === 0) {
        links = doc.select('#chapter-list a');
    }
    if (links.size() === 0) {
        links = doc.select('.chapter-list a, .list-chapter a, .table-of-content a');
    }
    if (links.size() === 0) {
        links = doc.select('a[href*="/chuong-"]');
    }

    links.forEach(function(a) {
        var href = absoluteUrl(a.attr('href'));
        if (!href || href.indexOf('/chuong-') < 0) return;
        var titleEl = a.select('h3, .chapter-title, span.name').first();
        if (!titleEl) titleEl = a;
        var title = tidy(decodeHtmlEntities(titleEl.text()));
        if (!title) return;
        chapters.push({ name: title, url: href, host: BASE_URL });
    });

    // Pagination for chapter list
    var pagLinks = doc.select('.uk-pagination li a[href]');
    if (pagLinks.size() > 0) {
        var maxPage = 1;
        pagLinks.forEach(function(el) {
            var m = el.attr('href').match(/page\/(\d+)/);
            if (m) {
                var n = parseInt(m[1], 10);
                if (n > maxPage) maxPage = n;
            }
        });
        var baseUrl = base + '/chuong/page/';
        for (var p = 2; p <= maxPage; p++) {
            var pageDoc = fetchDocument(baseUrl + p + '/');
            if (!pageDoc) continue;
            var pageLinks = pageDoc.select('#chapter-list .chapter-item a.uk-link-toggle');
            if (pageLinks.size() === 0) pageLinks = pageDoc.select('#chapter-list a');
            pageLinks.forEach(function(a) {
                var href = absoluteUrl(a.attr('href'));
                if (!href || href.indexOf('/chuong-') < 0) return;
                var titleEl = a.select('h3, .chapter-title').first();
                if (!titleEl) titleEl = a;
                var title = tidy(decodeHtmlEntities(titleEl.text()));
                if (!title) return;
                chapters.push({ name: title, url: href, host: BASE_URL });
            });
        }
    }

    if (chapters.length === 0) return Response.success([]);
    chapters.reverse();
    return Response.success(chapters);
}