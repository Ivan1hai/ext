load("config.js");
load("crypto.js");
load("auth.js");

function execute(url, credential) {
  const PASSPHRASE = "z4x8vog2a13vz4x8vog2a13v";

  // 1. Phân tích slug và chapter number
  let info = parseChapterInfo(url);
  if (!info) {
    return Response.error("URL chương không hợp lệ: " + url);
  }

  const webUrl = "https://comnguoinovel.com/truyen/" + info.slug + "/chuong/" + info.chapterNumber;
  const apiUrl = "https://api.comnguoinovel.com/api/novels/" + info.slug + "/chap/" + info.chapterNumber + "/read";

  // 2. Tải HTML trang web để lấy ảnh SVG chứa X-Chapter-Token
  let response = fetch(webUrl, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
    }
  });

  if (!response.ok) {
    return Response.error("Lỗi tải trang web: " + response.status);
  }

  let text = response.text();
  let match = text.match(/data:image\/svg\+xml;base64,([^"']+)/);
  if (!match) {
    return Response.error("Không tìm thấy ảnh SVG chứa chìa khóa bảo mật trên trang.");
  }

  // 3. Giải mã Base64 thành SVG XML
  let svgString = "";
  try {
    svgString = CryptoJS.enc.Base64.parse(match[1]).toString(CryptoJS.enc.Utf8);
  } catch (e) {
    return Response.error("Lỗi giải mã Base64 của ảnh SVG.");
  }

  // 4. Trích xuất mã MD5 token từ các pixel màu (hỗ trợ số âm và clamping)
  let chapterToken = extractToken(svgString);
  if (!chapterToken || chapterToken.length < 32) {
    return Response.error("Không trích xuất được X-Chapter-Token. (Độ dài: " + (chapterToken ? chapterToken.length : 0) + ")");
  }

  // 5-6. Lấy access token (tự đăng nhập/cache) rồi gọi API; 401 thì đăng nhập lại 1 lần
  let apiResponse = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    let auth = cnnGetAccessToken(credential, attempt > 0);
    if (auth.error) return Response.error(auth.error);

    apiResponse = fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + auth.token,
        "X-Chapter-Token": chapterToken,
        "Idempotency-Key": generateUUID(),
        "X-Chapter-Read-Contract-Version": "1",
        "Origin": "https://comnguoinovel.com",
        "Referer": webUrl
      },
      body: "{}"
    });
    if (apiResponse.status !== 401) break;
  }

  if (!apiResponse.ok) {
    if (apiResponse.status === 401) {
      return Response.error("Token bị từ chối (401) dù đã đăng nhập lại. Kiểm tra tài khoản.");
    }
    let errJson = null;
    try { errJson = apiResponse.json(); } catch (e) {}
    let msg = (errJson && errJson.message) ? errJson.message : ("Lỗi gọi API: " + apiResponse.status);
    return Response.error(msg);
  }

  let data = apiResponse.json();
  if (!data || !data.content) {
    return Response.error("API không trả về nội dung chương.");
  }

  // 7. Giải mã AES và trình bày văn bản
  try {
    const decodedText = CryptoJS.AES.decrypt(data.content, PASSPHRASE).toString(CryptoJS.enc.Utf8);
    if (!decodedText) {
      return Response.error("Không thể giải mã AES nội dung chương.");
    }
    const lines = decodedText.split("\n");
    lines.reverse();
    return Response.success(lines.join("<br>"));
  } catch (e) {
    return Response.error("Lỗi giải mã văn bản AES: " + e.message);
  }
}

function parseChapterInfo(url) {
  let m = url.match(/\/novels\/([^/?#]+)\/(?:chapter|chap)\/([^/?#]+)/);
  if (m) {
    return { slug: m[1], chapterNumber: m[2] };
  }
  m = url.match(/\/truyen\/([^/?#]+)\/chuong\/([^/?#]+)/);
  if (m) {
    return { slug: m[1], chapterNumber: m[2] };
  }
  return null;
}

// Thuật toán trích xuất LSB chính xác từ SVG (khớp 100% canvas của trình duyệt)
function extractToken(svgString) {
  // Regex bắt cả số nguyên âm lẫn dương trong rgb(r, g, b)
  let rgbRegex = /rgb\(\s*([-\d]+)\s*,\s*([-\d]+)\s*,\s*([-\d]+)\s*\)/g;
  let m;
  let bits = [];

  while ((m = rgbRegex.exec(svgString)) !== null) {
    // Canvas / CSS Color luôn clamp giá trị màu về khoảng [0, 255]
    let r = Math.max(0, Math.min(255, parseInt(m[1], 10)));
    let g = Math.max(0, Math.min(255, parseInt(m[2], 10)));
    let b = Math.max(0, Math.min(255, parseInt(m[3], 10)));
    bits.push(r & 1);
    bits.push(g & 1);
    bits.push(b & 1);
  }

  if (bits.length < 16) return "";

  // 16 bit đầu là độ dài dữ liệu (header)
  let headerBits = bits.slice(0, 16);
  let dataLen = parseInt(headerBits.join(""), 2);
  if (dataLen < 1 || dataLen > 512 || dataLen > bits.length - 16) {
    dataLen = Math.min(256, bits.length - 16);
  }

  // Đọc các byte ký tự ASCII theo đúng độ dài dataLen
  let token = "";
  for (let i = 16; i < 16 + dataLen; i += 8) {
    let charBits = bits.slice(i, i + 8);
    if (charBits.length < 8) break;
    let charCode = parseInt(charBits.join(""), 2);
    if (charCode >= 32 && charCode <= 126) {
      token += String.fromCharCode(charCode);
    } else if (charCode === 0) {
      break;
    }
  }

  return token;
}

function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}
