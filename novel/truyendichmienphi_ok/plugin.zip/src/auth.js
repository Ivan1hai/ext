// Yêu cầu: chap.js phải load("crypto.js") TRƯỚC load("auth.js") (không gọi load lồng ở đây).

// ===== Tự lấy accessToken cho Cơm Nguội Novel =====
// Nguồn credential (ưu tiên từ trên xuống):
//   1. Tham số thứ 2 của execute() (dùng khi test)
//   2. CONFIG_COOKIE  <- ô "cookie" trong cài đặt plugin của vBook (giống lacatruyen_ok)
//   3. Biến cũ: token / accessToken / account
// Định dạng giá trị:
//   - "email|mật khẩu"        -> tự gọi POST /auth/login, cache token, hết hạn tự đăng nhập lại
//   - JWT (bắt đầu "eyJ")     -> dùng trực tiếp (không tự gia hạn)
//   - "accessToken=<JWT>"     -> như JWT (dán kiểu cookie cũng được)
// Chỉ cache access token (không lưu mật khẩu) trong localStorage của vBook.

var CNN_API = "https://api.comnguoinovel.com/api";
var CNN_TOKEN_KEY = "comnguoinovel.accessToken.v1";
var CNN_EXPIRY_MARGIN = 120; // giây

function cnnStore() {
  try { if (typeof localStorage !== "undefined" && localStorage) return localStorage; } catch (e) {}
  return null;
}

function cnnGetRawCredential(arg) {
  var list = [arg];
  try { if (typeof CONFIG_COOKIE !== "undefined") list.push(CONFIG_COOKIE); } catch (e) {}
  try { if (typeof token !== "undefined") list.push(token); } catch (e) {}
  try { if (typeof accessToken !== "undefined") list.push(accessToken); } catch (e) {}
  try { if (typeof account !== "undefined") list.push(account); } catch (e) {}
  for (var i = 0; i < list.length; i++) {
    var v = String(list[i] || "").trim().replace(/^["']|["']$/g, "");
    if (v) return v;
  }
  return "";
}

function cnnParseCredential(raw) {
  raw = String(raw || "").trim().replace(/^Bearer\s+/i, "");
  if (!raw) return { type: "none" };
  var kv = raw.match(/(?:^|;\s*)(?:accessToken|access_token|token)=([^;\s]+)/i);
  if (kv && /^eyJ/.test(kv[1])) raw = kv[1];
  if (/^eyJ[\w-]+\.[\w-]+\.[\w-]+$/.test(raw)) return { type: "jwt", token: raw };
  var idx = raw.indexOf("|");
  if (idx > 0 && raw.substring(0, idx).indexOf("@") > 0) {
    return { type: "login", email: raw.substring(0, idx).trim(), password: raw.substring(idx + 1) };
  }
  return { type: "invalid" };
}

function cnnJwtExp(jwt) {
  try {
    var p = String(jwt).split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
    while (p.length % 4) p += "=";
    var json = CryptoJS.enc.Base64.parse(p).toString(CryptoJS.enc.Utf8);
    return Number(JSON.parse(json).exp) || 0;
  } catch (e) { return 0; }
}

function cnnIsFresh(jwt) {
  var exp = cnnJwtExp(jwt);
  if (!exp) return true; // không đọc được hạn -> cứ dùng, 401 sẽ kích hoạt đăng nhập lại
  return exp - CNN_EXPIRY_MARGIN > Math.floor(Date.now() / 1000);
}

function cnnReadCache(email) {
  var st = cnnStore();
  if (!st) return "";
  try {
    var c = JSON.parse(st.getItem(CNN_TOKEN_KEY) || "null");
    if (c && c.email === email && c.token && cnnIsFresh(c.token)) return c.token;
  } catch (e) {}
  return "";
}

function cnnWriteCache(email, tok) {
  var st = cnnStore();
  if (!st) return;
  try { st.setItem(CNN_TOKEN_KEY, JSON.stringify({ email: email, token: tok })); } catch (e) {}
}

function cnnClearCache() {
  var st = cnnStore();
  if (!st) return;
  try { st.removeItem(CNN_TOKEN_KEY); } catch (e) {}
}

// Trả về { token } hoặc { error }
function cnnLogin(email, password) {
  var res;
  try {
    res = fetch(CNN_API + "/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Origin": "https://comnguoinovel.com",
        "Referer": "https://comnguoinovel.com/auth/login"
      },
      body: JSON.stringify({ email: email, password: password })
    });
  } catch (e) {
    return { error: "Không kết nối được máy chủ đăng nhập." };
  }
  var data = null;
  try { data = res.json(); } catch (e) {}
  if (!res.ok) {
    var m = data && data.message ? data.message : ("HTTP " + res.status);
    if (res.status === 401) return { error: "Sai email hoặc mật khẩu (tài khoản đăng ký bằng Google không có mật khẩu)." };
    return { error: "Đăng nhập thất bại: " + m };
  }
  var tok = data && data.tokens && data.tokens.access && data.tokens.access.token;
  if (!tok) return { error: "Đăng nhập không trả về access token." };
  return { token: tok };
}

// forceRelogin = true khi server trả 401 với token đang dùng.
// Trả về { token } hoặc { error }
function cnnGetAccessToken(arg, forceRelogin) {
  var cred = cnnParseCredential(cnnGetRawCredential(arg));
  if (cred.type === "none") {
    return { error: "Chưa cấu hình tài khoản. Vào cài đặt plugin, điền \"email|mật khẩu\" (hoặc accessToken) vào ô Cookie (CONFIG_COOKIE)." };
  }
  if (cred.type === "invalid") {
    return { error: "Cấu hình sai định dạng. Dùng \"email|mật khẩu\" hoặc accessToken (JWT bắt đầu bằng eyJ)." };
  }
  if (cred.type === "jwt") {
    if (forceRelogin || !cnnIsFresh(cred.token)) return { error: "accessToken đã hết hạn. Lấy token mới hoặc dùng \"email|mật khẩu\" để tự gia hạn." };
    return { token: cred.token };
  }
  if (forceRelogin) cnnClearCache();
  var cached = cnnReadCache(cred.email);
  if (cached) return { token: cached };
  var r = cnnLogin(cred.email, cred.password);
  if (r.token) cnnWriteCache(cred.email, r.token);
  return r;
}
