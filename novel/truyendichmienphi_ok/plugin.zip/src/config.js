let BASE_URL = "https://comnguoinovel.com";
let API_URL = "https://api.comnguoinovel.com";

try {
	if (CONFIG_URL) {
		BASE_URL = CONFIG_URL;
	}
} catch {}
