load("config.js");
load("auth.js");

// input = "key=value&key2=value2" (khong co dau ?)
// route: stories (danh sach) hoac ranking (BXH)
function execute(input, page) {
    if (!page) page = "1";
    var currentPage = parseInt(page, 10) || 1;

    var params = [];
    var rank = "";
    ("" + (input || "")).split("&").forEach(function(pair) {
        if (!pair) return;
        var parts = pair.split("=");
        var key = parts[0];
        var value = parts.slice(1).join("=");
        if (!key) return;
        if (key === "rank") { rank = value; return; }
        params.push(encodeURIComponent(key) + "=" + encodeURIComponent(value));
    });

    var path;
    if (rank) {
        path = "/api/v1/ranking?by=" + encodeURIComponent(rank) + "&page=" + currentPage + "&limit=" + TTC_PAGE_SIZE;
    } else {
        path = "/api/v1/stories?" + params.join("&") + "&page=" + currentPage + "&limit=" + TTC_PAGE_SIZE;
    }

    var res = ttcRequest(path, "GET", null, null, null);
    if (!res.ok || !res.json) return Response.success([]);

    var json = res.json;
    var books = ttcToBooks(json.items || []);

    var totalPages = parseInt(json.totalPages || json.total_pages || 0, 10);
    var next = "";
    if (totalPages > 0 && currentPage < totalPages) next = String(currentPage + 1);

    return Response.success(books, next);
}
