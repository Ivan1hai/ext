load("config.js");
load("auth.js");

// Danh sach the loai.
// Server tra "categories" (slug + name) kem trong response cua GET /api/v1/stories.
var TTC_FALLBACK_CATEGORIES = [
    { slug: "hien-dai", name: "Hien dai" },
    { slug: "co-dai", name: "Co dai" },
    { slug: "tien-hiep", name: "Tien hiep" },
    { slug: "huyen-huyen", name: "Huyen huyen" },
    { slug: "do-thi", name: "Do thi" },
    { slug: "khoa-huyen", name: "Khoa huyen" },
    { slug: "huyen-nghi", name: "Huyen nghi" },
    { slug: "linh-di", name: "Linh di" },
    { slug: "vong-du", name: "Vong du" },
    { slug: "dong-nhan", name: "Dong nhan" },
    { slug: "canh-ky", name: "Canh ky" },
    { slug: "vo-hiep", name: "Vo hiep" },
    { slug: "kiem-hiep", name: "Kiem hiep" },
    { slug: "tay-huyen", name: "Tay huyen" },
    { slug: "light-novel", name: "Light novel" },
    { slug: "tan-the", name: "Tan the" },
    { slug: "da-su", name: "Da su" }
];

function execute() {
    var tabs = [];
    var res = ttcRequest("/api/v1/stories?page=1&limit=1", "GET", null, null, null);

    var categories = [];
    if (res.ok && res.json && res.json.categories && res.json.categories.length) {
        categories = res.json.categories;
    } else {
        categories = TTC_FALLBACK_CATEGORIES;
    }

    categories.forEach(function(c) {
        var name = ttcTrim(c.name || c.title || "");
        var slug = ttcTrim(c.slug || "");
        if (!name || !slug) return;
        tabs.push({ title: name, input: "cat=" + slug, script: "genre-content.js" });
    });

    tabs.push({ title: "Truyen moi", input: "sort=new", script: "genre-content.js" });
    tabs.push({ title: "Moi cap nhat", input: "sort=updated", script: "genre-content.js" });
    tabs.push({ title: "Truyen Full", input: "status=full", script: "genre-content.js" });
    tabs.push({ title: "Truyen Nam", input: "gender=nam", script: "genre-content.js" });
    tabs.push({ title: "Truyen Nu", input: "gender=nu", script: "genre-content.js" });

    return Response.success(tabs);
}
