load("config.js");

// Script "config" của plugin -> vBook hiển thị trong phần Cài đặt extension.
// Mỗi key tương ứng một ô nhập, đọc lại bằng localConfig.getItem(key).
//
// Vì sao không dùng ô Cookie?
//   Ô Cookie của vBook chỉ nhận chuỗi cookie đúng định dạng, không lưu được
//   email/mật khẩu dạng tùy ý. localConfig giữ giá trị riêng cho từng ô nên
//   lưu được lâu dài và không bị app xoá khi đổi phiên.
function execute() {
    var config = {};

    config[TTC_CFG.username] = {
        title: "Tên tài khoản",
        subtitle: "Tài khoản trên Tiệm Truyện Chữ (không phải email). " +
                  "Bắt buộc nếu bạn dùng tài khoản có sẵn.",
        default: "",
        mode: "input",
        format: "text"
    };

    config[TTC_CFG.password] = {
        title: "Mật khẩu",
        subtitle: "Mật khẩu của tài khoản (tối thiểu 8 ký tự, có chữ HOA và chữ số). " +
                  "Tài khoản đăng nhập nhanh bằng Google có thể không dùng được mật khẩu — khi đó dùng ô Ma OTP.",
        default: "",
        mode: "input",
        format: "password"
    };

    config[TTC_CFG.otp] = {
        title: "Ma OTP (6 chữ số)",
        subtitle: "Server bắt buộc xác nhận OTP cho mỗi lần đăng nhập. " +
                  "Bước 1: điền Tên tài khoản + Mật khẩu, mở chương -> plugin tự gửi mã 6 số tới Gmail. " +
                  "Bước 2: dán mã nhận được vào đây rồi mở lại chương. " +
                  "Ô này tự xoá sau khi dùng.",
        default: "",
        mode: "input",
        format: "text"
    };

    config[TTC_CFG.email] = {
        title: "Email Gmail (tự đăng ký tài khoản mới)",
        subtitle: "Chỉ nhận @gmail.com. Khi điền email này và để trống Tên tài khoản, " +
                  "plugin tự tạo tài khoản (tự sinh tên + mật khẩu) rồi đăng nhập — không cần OTP. " +
                  "Chỉ dùng khi bạn KHÔNG có tài khoản sẵn.",
        default: "",
        mode: "input",
        format: "text"
    };

    return Response.success(config);
}
