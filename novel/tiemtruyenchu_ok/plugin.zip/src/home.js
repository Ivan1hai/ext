load("config.js");

// Trang kham pha - dung API /api/v1/stories
function execute() {
    return Response.success([
        { title: "Moi cap nhat", input: "sort=updated", script: "genre-content.js" },
        { title: "Truyen moi", input: "sort=new", script: "genre-content.js" },
        { title: "Truyen Full", input: "status=full", script: "genre-content.js" },
        { title: "Xem nhieu", input: "sort=views", script: "genre-content.js" },
        { title: "Truyen Nam", input: "gender=nam", script: "genre-content.js" },
        { title: "Truyen Nu", input: "gender=nu", script: "genre-content.js" },
        { title: "BXH - Luot xem", input: "rank=views", script: "genre-content.js" },
        { title: "BXH - Qua tang", input: "rank=gifts", script: "genre-content.js" },
        { title: "BXH - De cu", input: "rank=nominations", script: "genre-content.js" },
        { title: "BXH - Theo doi", input: "rank=follows", script: "genre-content.js" },
        { title: "BXH - Binh luan", input: "rank=comments", script: "genre-content.js" }
    ]);
}
