load("config.js");
load("auth.js");

// Doc noi dung chuong.
// Route dung (da xac minh tu APK 1.1.1):
//   POST /api/v1/chapters/content   body: {storyId, chapterNumber}
//   -> { success:true, content:"..." }
//   Token bat buoc (Bearer JWT).
// Route /api/v1/stories/{id}/chapters/{n} bi nginx chan 403 -> khong dung.

function ttcExtractContent(json) {
    if (!json) return "";
    var candidates = [
        json.content,
        json.chapter && json.chapter.content,
        json.data && json.data.content,
        json.text,
        json.body,
        json.html,
        json.data && typeof json.data === "string" ? json.data : ""
    ];
    for (var i = 0; i < candidates.length; i++) {
        var v = candidates[i];
        if (typeof v === "string" && ttcTrim(v)) return v;
    }
    return "";
}

function ttcNormalizeContent(html) {
    var text = "" + (html || "");
    text = text.replace(/<script[\s\S]*?<\/script>/gi, "");
    text = text.replace(/<style[\s\S]*?<\/style>/gi, "");
    text = text.replace(/<noscript[\s\S]*?<\/noscript>/gi, "");
    text = text.replace(/<br\s*\/?>/gi, "\n");
    text = text.replace(/<\/(p|div|h[1-6]|li|tr|blockquote)>/gi, "\n");
    text = text.replace(/<[^>]+>/g, "");
    text = text.replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&")
               .replace(/&lt;/gi, "<").replace(/&gt;/gi, ">")
               .replace(/&quot;/gi, "\"").replace(/&#39;/gi, "'")
               .replace(/&#(\d+);/g, function(m, n) { return String.fromCharCode(parseInt(n, 10)); });

    var lines = text.split(/\r?\n/);
    var out = [];
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i].replace(/^\s+|\s+$/g, "");
        if (!line) continue;
        out.push("<p>" + line + "</p>");
    }
    if (!out.length) return "";
    return out.join("");
}

function execute(url) {
    var raw = "" + (url || "");

    var storyId = 0;
    var chapterNumber = 0;

    var m = raw.match(/storyId=(\d+)/i);
    if (m) storyId = parseInt(m[1], 10);
    if (!storyId) storyId = ttcStoryId(raw);

    m = raw.match(/chapterNumber=(\d+)/i);
    if (m) chapterNumber = parseInt(m[1], 10);
    if (!chapterNumber) {
        m = raw.match(/chapter_number=(\d+)/i);
        if (m) chapterNumber = parseInt(m[1], 10);
    }
    if (!chapterNumber) {
        m = raw.match(/\/chuong\/(\d+)/i);
        if (m) chapterNumber = parseInt(m[1], 10);
    }

    if (!storyId || !chapterNumber) {
        return Response.error("Khong tim thay storyId/chapterNumber trong url chuong.");
    }

    // 1) lay token (tu cache, hoac dang nhap moi / xac nhan OTP)
    var auth = ttcGetToken(false);
    if (!auth.token) {
        return Response.error(auth.error || "Chua co access token.");
    }

    // 2) goi API doc chuong
    var res = ttcRequest(
        "/api/v1/chapters/content",
        "POST",
        { storyId: storyId, chapterNumber: chapterNumber },
        auth.token,
        ttcRetryAuth
    );

    if (!res.ok) {
        var msg = "";
        try { msg = (res.json && res.json.message) ? res.json.message : ""; } catch (e) {}
        if (res.status === 401) {
            return Response.error("Token khong hop le / da het han. Kiem tra tai khoan trong Cai dat extension.");
        }
        if (res.status === 403) {
            return Response.error("Chuong nay bi khoa (403). Thu chuong khac.");
        }
        if (res.status === 429) {
            return Response.error("Server ban tam thoi. Thu lai sau.");
        }
        if (res.status === 404) {
            return Response.error("Khong tim thay chuong (404).");
        }
        return Response.error("Loi doc chuong (HTTP " + res.status + ")" + (msg ? ": " + msg : ""));
    }

    var content = ttcExtractContent(res.json);
    if (!content) {
        var vipToken = "";
        try {
            var ch = res.json.chapter || res.json.data || {};
            vipToken = ch.vipToken || ch.vip_token || ch.token || "";
        } catch (e) {}
        if (vipToken) {
            var res2 = ttcRequest(
                "/api/v1/chapters/content",
                "POST",
                { storyId: storyId, chapterNumber: chapterNumber, vipToken: vipToken },
                auth.token,
                ttcRetryAuth
            );
            if (res2.ok) content = ttcExtractContent(res2.json);
        }
    }

    if (!content) {
        var m2 = "";
        try { m2 = (res.json && res.json.message) ? res.json.message : ""; } catch (e) {}
        return Response.error("Chuong rong hoac bi gioi han." + (m2 ? " " + m2 : ""));
    }

    var html = ttcNormalizeContent(content);
    if (!html) return Response.error("Chuong rong.");
    return Response.success(html);
}
