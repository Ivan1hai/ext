load("config.js");
load("auth.js");

// Muc luc: GET /api/v1/stories/{id} tra kem mang "chapters":
//   [{ chapterNumber, title, chapter_price, created_at, views }]
// Khong dung GET /api/v1/stories/{id}/chapters - nginx chan 403.
function execute(url) {
    var id = ttcStoryId(url);
    if (!id) return Response.success([]);

    var res = ttcRequest("/api/v1/stories/" + id, "GET", null, null, null);
    if (!res.ok || !res.json) return Response.success([]);

    var chapters = res.json.chapters || [];
    var list = [];
    chapters.forEach(function(c) {
        if (!c) return;
        var num = parseInt(c.chapterNumber || c.chapter_number || c.number || 0, 10);
        var title = ttcTrim(c.title || ("Chuong " + num));
        if (!num && !title) return;
        var entry = {
            name: title,
            url: TTC_API + "/api/v1/chapters/content?storyId=" + id + "&chapterNumber=" + num,
            host: TTC_API
        };
        if (parseInt(c.chapter_price || 0, 10) > 0) entry.name = "[VIP] " + entry.name;
        list.push(entry);
    });

    return Response.success(list);
}
