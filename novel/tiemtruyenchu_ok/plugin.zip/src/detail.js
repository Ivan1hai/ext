load("config.js");
load("auth.js");

// Chi tiet truyen: GET /api/v1/stories/{id}
function execute(url) {
    var id = ttcStoryId(url);
    if (!id) return Response.error("Khong tim thay ID truyen.");

    var res = ttcRequest("/api/v1/stories/" + id, "GET", null, null, null);
    if (!res.ok || !res.json) {
        return Response.error("Khong tai duoc chi tiet truyen (HTTP " + (res ? res.status : 0) + ").");
    }

    var story = res.json.story || res.json;
    var name = ttcTrim(story.title || "");
    if (!name) return Response.error("Khong tai duoc chi tiet truyen.");

    var author = ttcTrim(story.author || "");
    var cover = ttcCover(story.cover_url || story.poster || "");

    var status = ttcTrim(story.status || "");
    var isFull = ttcFold(status).indexOf("full") > -1 || ttcFold(status).indexOf("hoan") > -1;
    var statusText = isFull ? "Hoan thanh" : "Dang ra";

    var genres = [];
    var genreNames = [];

    var category = ttcTrim(story.category || "");
    if (category) {
        genreNames.push(category);
        genres.push({ title: category, input: "cat=" + ttcSlug(category), script: "genre-content.js" });
    }

    if (story.sub_categories && story.sub_categories.length) {
        story.sub_categories.forEach(function(sub) {
            var title = ttcTrim(sub || "");
            if (!title) return;
            genreNames.push(title);
            genres.push({ title: title, input: "keyword=" + encodeURIComponent(title), script: "genre-content.js" });
        });
    }

    var detail = "";
    if (author) detail += "Tac gia: " + author + "<br>";
    if (genreNames.length) detail += "The loai: " + genreNames.join(", ") + "<br>";
    detail += "Trang thai: " + statusText + "<br>";
    if (story.total_chapters) detail += "So chuong: " + story.total_chapters + "<br>";
    if (story.views !== null && typeof story.views !== "undefined") detail += "Luot xem: " + story.views + "<br>";
    if (story.follows !== null && typeof story.follows !== "undefined") detail += "Theo doi: " + story.follows + "<br>";
    if (story.gifts_month) detail += "Qua tang thang: " + story.gifts_month + "<br>";
    if (story.nominations) detail += "De cu: " + story.nominations + "<br>";
    if (story.avg_rating) detail += "Danh gia: " + story.avg_rating + "/5 (" + (story.rating_count || 0) + ")";

    var description = ttcTrim(story.description || "");
    description = description.replace(/\r\n/g, "<br>").replace(/\n/g, "<br>");

    return Response.success({
        name: name,
        cover: cover,
        host: TTC_API,
        author: author,
        description: description,
        detail: detail,
        ongoing: !isFull,
        genres: genres
    });
}
