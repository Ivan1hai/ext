load("config.js");
load("auth.js");

// Tim kiem: GET /api/v1/stories?keyword=<tu khoa>
// KHONG co route /api/v1/search (404).
//
// Server so khop full-text theo TOKEN va BAT BUOC co dau tieng Viet:
//   "Yên" -> 2931 ket qua, "yen" -> 0 ket qua.
// -> thu nguyen ban dau, neu rong thi thu tung token rieng roi bo dau.

function ttcSearchPage(keyword, currentPage) {
    var path = "/api/v1/stories?keyword=" + encodeURIComponent(keyword) +
               "&page=" + currentPage + "&limit=" + TTC_PAGE_SIZE;
    var res = ttcRequest(path, "GET", null, null, null);
    if (!res.ok || !res.json) return null;
    return res.json;
}

function ttcPushUnique(seen, books, items) {
    if (!items || !items.length) return;
    items.forEach(function(item) {
        var key = String(item.id);
        if (seen[key]) return;
        seen[key] = true;
        var b = ttcToBooks([item]);
        if (b.length) books.push(b[0]);
    });
}

function execute(key, page) {
    if (!page) page = "1";
    var currentPage = parseInt(page, 10) || 1;
    var keyword = ttcTrim(key || "");
    if (!keyword) return Response.success([]);

    var seen = {};
    var books = [];
    var totalPages = 0;

    // 1) chuoi goc
    var json = ttcSearchPage(keyword, currentPage);
    if (json) {
        totalPages = Math.max(totalPages, parseInt(json.totalPages || json.total_pages || 0, 10));
        ttcPushUnique(seen, books, json.items || []);
    }

    // 2) neu rong -> thu tung token rieng (OR) va bien the bo dau
    if (!books.length) {
        var tokens = keyword.split(/\s+/);
        for (var i = 0; i < tokens.length; i++) {
            var token = ttcTrim(tokens[i]);
            if (!token) continue;
            var variants = [token];
            var folded = ttcFold(token);
            if (folded && folded !== token) variants.push(folded);

            for (var v = 0; v < variants.length; v++) {
                var j = ttcSearchPage(variants[v], currentPage);
                if (!j) continue;
                totalPages = Math.max(totalPages, parseInt(j.totalPages || j.total_pages || 0, 10));
                ttcPushUnique(seen, books, j.items || []);
                if (books.length) break;
            }
            if (books.length) break;
        }
    }

    // 3) van rong -> thu bo dau toan bo chuoi
    if (!books.length) {
        var noDia = ttcFold(keyword);
        if (noDia && noDia !== keyword.toLowerCase()) {
            var j2 = ttcSearchPage(noDia, currentPage);
            if (j2) {
                totalPages = Math.max(totalPages, parseInt(j2.totalPages || j2.total_pages || 0, 10));
                ttcPushUnique(seen, books, j2.items || []);
            }
        }
    }

    var next = "";
    if (totalPages > 0 && currentPage < totalPages) next = String(currentPage + 1);

    return Response.success(books, next);
}
