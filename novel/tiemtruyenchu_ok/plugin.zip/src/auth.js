// Tu dang nhap / lay access token cho Tiem Truyen Chu
//
// --- API that (da kiem chung live, app v1.1.1) ---
//
//   POST /api/auth/login            {username, password}
//        -> tai khoan CO mat khau : {success:true, token, refreshToken, ...}
//        -> tai khoan GOOGLE (khong co mat khau):
//           {success:true, step:"otp_required", maskedEmail:"h***@gmail.com"}
//           (KHONG tra token -> day la ly do bao "Dang nhap khong tra ve token")
//
//   POST /api/auth/send-login-otp    {username, password}
//        -> gui ma 6 so toi Gmail. Loi cooldown tra kem {cooldownSeconds: N}.
//
//   POST /api/auth/verify-login-otp  {otp, username, password}
//        -> {success:true, token, refreshToken, ...}
//        Da kiem chung: field dung la "otp", BAT BUOC co "username".
//          {otp,username} -> "Ma OTP da het han" (da nhan dung field)
//          {otp}           -> "Thieu thong tin!"   (thieu username)
//          {code,...}     -> "Thieu thong tin!"   (code khong phai ten field)
//
//   POST /api/auth/register          {email(@gmail.com), username, password}
//   POST /api/auth/refresh           {username, refreshToken}   -> token moi
//   POST /api/auth/logout
//   Auth header cho API: Authorization: Bearer <jwt>
//
// --- Nguon credential ---
//   1. localConfig (Cai dat extension cua plugin) - uu tien
//   2. CONFIG_COOKIE (o Cookie) - du phong (chi dung cho token JWT)
//   3. localCookie.getCookie() / bien token
//
// Chi cache access token (KHONG luu mat khau) trong localStorage cua vBook.

if (typeof TTC_API === "undefined") {
    try { load("config.js"); } catch (e) {}
}

var TTC_TOKEN_KEY = "tiemtruyenchu.token.v2";
var TTC_EXPIRY_MARGIN = 120;

function ttcStore() {
    try { if (typeof localStorage !== "undefined" && localStorage) return localStorage; } catch (e) {}
    return null;
}

function ttcCfgGet(key) {
    try {
        if (typeof localConfig !== "undefined" && localConfig && typeof localConfig.getItem === "function") {
            var v = localConfig.getItem(key);
            if (v !== null && typeof v !== "undefined" && String(v).trim()) return String(v).trim();
        }
    } catch (e) {}
    return "";
}

function ttcCfgSet(key, value) {
    try {
        if (typeof localConfig !== "undefined" && localConfig && typeof localConfig.setItem === "function") {
            localConfig.setItem(key, value === null || typeof value === "undefined" ? "" : String(value));
            return true;
        }
    } catch (e) {}
    return false;
}

function ttcCfgRemove(key) {
    try {
        if (typeof localConfig !== "undefined" && localConfig && typeof localConfig.removeItem === "function") {
            localConfig.removeItem(key);
            return true;
        }
    } catch (e) {}
    return false;
}

function ttcJwtExp(jwt) {
    try {
        var parts = String(jwt).split(".");
        if (parts.length < 2) return 0;
        var p = parts[1].replace(/-/g, "+").replace(/_/g, "/");
        while (p.length % 4) p += "=";
        var json = null;
        if (typeof atob === "function") {
            var bin = atob(p);
            var out = "";
            for (var i = 0; i < bin.length; i++) out += "%" + ("00" + bin.charCodeAt(i).toString(16)).slice(-2);
            json = JSON.parse(decodeURIComponent(out));
        } else if (typeof CryptoJS !== "undefined") {
            json = JSON.parse(CryptoJS.enc.Base64.parse(p).toString(CryptoJS.enc.Utf8));
        }
        return Number(json && json.exp) || 0;
    } catch (e) { return 0; }
}

function ttcTokenFresh(jwt) {
    var exp = ttcJwtExp(jwt);
    if (!exp) return true;
    return exp - TTC_EXPIRY_MARGIN > Math.floor(Date.now() / 1000);
}

function ttcReadCache(username) {
    var st = ttcStore();
    if (!st) return null;
    try {
        var c = JSON.parse(st.getItem(TTC_TOKEN_KEY) || "null");
        if (c && c.username === username && c.token && ttcTokenFresh(c.token)) return c;
    } catch (e) {}
    return null;
}

function ttcWriteCache(username, token, refreshToken) {
    var st = ttcStore();
    if (!st) return;
    try {
        st.setItem(TTC_TOKEN_KEY, JSON.stringify({
            username: username, token: token, refreshToken: refreshToken || ""
        }));
    } catch (e) {}
}

function ttcClearCache() {
    var st = ttcStore();
    if (!st) return;
    try { st.removeItem(TTC_TOKEN_KEY); } catch (e) {}
}

function ttcPostJson(path, body, extraHeaders) {
    var headers = {
        "User-Agent": TTC_UA,
        "Accept": "application/json, text/plain, */*",
        "Content-Type": "application/json",
        "Referer": TTC_API + "/",
        "Origin": TTC_API
    };
    if (extraHeaders) {
        Object.keys(extraHeaders).forEach(function(k) { headers[k] = extraHeaders[k]; });
    }
    var response = null;
    try {
        response = fetch(TTC_API + path, {
            method: "POST", headers: headers, body: JSON.stringify(body)
        });
    } catch (e) {
        return { ok: false, status: 0, json: null, text: "", headers: null };
    }
    var json = null;
    var text = "";
    try { text = response.text(); } catch (e) {}
    if (text) {
        try { json = JSON.parse(text); } catch (e) { json = null; }
    }
    if (!json) {
        try { json = response.json(); } catch (e) {}
    }
    var respHeaders = null;
    try {
        var h = response.headers;
        if (h) {
            respHeaders = {};
            if (typeof h.forEach === "function") {
                h.forEach(function(v, k) { respHeaders[String(k).toLowerCase()] = String(v); });
            } else {
                for (var k2 in h) {
                    if (h.hasOwnProperty(k2)) respHeaders[String(k2).toLowerCase()] = String(h[k2]);
                }
            }
        }
    } catch (e) {}
    return { ok: response.ok, status: response.status, json: json, text: text, headers: respHeaders };
}

var TTC_JWT_RE = /^eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]*$/;

function ttcLooksJwt(value) {
    return typeof value === "string" && value.length > 40 && TTC_JWT_RE.test(value);
}

function ttcCollectJwts(node, path, out, depth) {
    if (depth > 6 || node === null || typeof node === "undefined") return;
    if (typeof node === "string") {
        if (ttcLooksJwt(node)) out.push({ path: path, value: node });
        return;
    }
    if (Array.isArray(node)) {
        for (var i = 0; i < node.length; i++) ttcCollectJwts(node[i], path + "[" + i + "]", out, depth + 1);
        return;
    }
    if (typeof node === "object") {
        for (var k in node) {
            if (node.hasOwnProperty(k)) ttcCollectJwts(node[k], path ? path + "." + k : k, out, depth + 1);
        }
    }
}

function ttcPickToken(json, resHeaders, rawText) {
    var token = "";
    var refresh = "";

    try {
        token = json.token || json.accessToken || json.access_token || "";
        if (!token && json.data) token = json.data.token || json.data.accessToken || json.data.access_token || "";
        if (!token && json.tokens) token = json.tokens.accessToken || json.tokens.access || json.tokens.access_token || "";
        if (!token && json.user) token = json.user.token || json.user.accessToken || json.user.access_token || "";
        refresh = json.refreshToken || json.refresh_token || "";
        if (!refresh && json.data) refresh = json.data.refreshToken || json.data.refresh_token || "";
        if (!refresh && json.tokens) refresh = json.tokens.refresh || json.tokens.refreshToken || "";
    } catch (e) {}

    var found = [];
    try { ttcCollectJwts(json, "", found, 0); } catch (e) {}
    if (!token) {
        for (var i = 0; i < found.length; i++) {
            if (found[i].path.toLowerCase().indexOf("refresh") === -1) { token = found[i].value; break; }
        }
    }
    if (!refresh) {
        for (var j = 0; j < found.length; j++) {
            if (found[j].path.toLowerCase().indexOf("refresh") > -1) { refresh = found[j].value; break; }
        }
    }

    if (!token && resHeaders) {
        try {
            var names = ["authorization", "x-access-token", "x-auth-token", "x-token", "token"];
            for (var n = 0; n < names.length; n++) {
                var hv = resHeaders[names[n]];
                if (!hv) continue;
                var cleaned = String(hv).replace(/^Bearer\s+/i, "").trim();
                if (cleaned && cleaned !== "null" && cleaned !== "undefined") { token = cleaned; break; }
            }
        } catch (e) {}
    }

    if (!token) {
        try {
            var m = ("" + (rawText || "")).match(/eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]*/);
            if (m) token = m[0];
        } catch (e) {}
    }

    return { token: token, refreshToken: refresh };
}

var TTC_BANNED = ["admin", "mod", "moderator", "support", "system", "staff", "superadmin",
    "super_admin", "operator", "root", "owner", "manager", "quantri", "quantrivien", "bqt",
    "vietcombank", "vietinbank", "bidv", "agribank", "techcombank", "mbbank", "vpbank",
    "acb", "sacombank", "hdbank", "ocb", "tpbank", "msb", "seabank", "scb", "pvcombank",
    "namabank", "ncb", "abbank", "vib", "lienvietpostbank", "lpb", "baovietbank", "vietbank",
    "kienlongbank", "pgbank", "cbbank", "vietabank", "gpbank", "dongabank", "dab", "shb",
    "eximbank", "bacabank", "vccb", "wooribank", "shinhan", "hsbc", "citibank", "standardchartered",
    "uob", "publicbank", "cimb", "momo", "zalopay", "vnpay", "vnpt", "viettel", "viettelmoney", "moca"];

function ttcRandomString(len) {
    var chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    var out = "";
    for (var i = 0; i < len; i++) out += chars.charAt(Math.floor(Math.random() * chars.length));
    return out;
}

function ttcValidUsername(name) {
    if (!name || name.length < 6 || name.length > 30) return false;
    if (!/^[a-zA-Z0-9._]+$/.test(name)) return false;
    if (/^[._]|[._]$/.test(name)) return false;
    var flat = name.toLowerCase().replace(/[._]/g, "");
    for (var i = 0; i < TTC_BANNED.length; i++) {
        if (flat.indexOf(TTC_BANNED[i]) > -1) return false;
    }
    return true;
}

function ttcMakeUsername(email) {
    var base = String(email || "").split("@")[0].toLowerCase().replace(/[^a-z0-9]/g, "");
    if (base.length < 6) base = "ttc" + base;
    if (base.length > 20) base = base.substring(0, 20);
    for (var attempt = 0; attempt < 8; attempt++) {
        var candidate = base + ttcRandomString(6);
        if (ttcValidUsername(candidate)) return candidate;
    }
    return "ttc" + ttcRandomString(14);
}

function ttcMakePassword() {
    var upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
    var digit = "23456789";
    var out = ttcRandomString(2) + upper.charAt(Math.floor(Math.random() * upper.length)) +
              digit.charAt(Math.floor(Math.random() * digit.length)) + ttcRandomString(5);
    for (var i = out.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var tmp = out.charAt(i); out = out.substring(0, i) + out.charAt(j) + out.substring(j + 1);
    }
    return out;
}

function ttcCfgCredential() {
    var email = ttcCfgGet(TTC_CFG.email);
    var username = ttcCfgGet(TTC_CFG.username);
    var password = ttcCfgGet(TTC_CFG.password);
    var otp = ttcCfgGet(TTC_CFG.otp);

    if (username && otp) return { type: "otp", username: username, password: password, otp: otp };
    if (username && password) return { type: "login", username: username, password: password };
    if (username) return { type: "login", username: username, password: "" };
    if (email) return { type: "autoregister", email: email };
    return { type: "none" };
}

function ttcRawToken() {
    var list = [];
    try { if (typeof CONFIG_COOKIE !== "undefined") list.push(CONFIG_COOKIE); } catch (e) {}
    try {
        if (typeof localCookie !== "undefined" && localCookie && typeof localCookie.getCookie === "function") {
            list.push(localCookie.getCookie());
            list.push(localCookie.getCookie("https://tiemtruyenchu.cloud/"));
        }
    } catch (e) {}
    try { if (typeof token !== "undefined") list.push(token); } catch (e) {}
    try { if (typeof accessToken !== "undefined") list.push(accessToken); } catch (e) {}

    for (var i = 0; i < list.length; i++) {
        var v = String(list[i] || "").trim().replace(/^["']|["']$/g, "");
        if (!v) continue;
        var stripped = v.replace(/^Bearer\s+/i, "");
        if (/^eyJ[\w-]+\.[\w-]+\.[\w-]*$/.test(stripped)) return { type: "jwt", token: stripped };
        var kv = v.match(/(?:^|;\s*)(?:ttc_access_token|access_token|accessToken|token)=([^;\s]+)/i);
        if (kv && /^eyJ/.test(kv[1])) return { type: "jwt", token: kv[1] };
    }
    return { type: "none" };
}

// Buoc 1: POST /api/auth/login
// -> {token, refreshToken} | {otpRequired:true, maskedEmail} | {error}
function ttcLoginStep1(username, password) {
    var res = ttcPostJson("/api/auth/login", { username: username, password: password });
    if (!res.ok) {
        var msg = (res.json && res.json.message) ? res.json.message : ("HTTP " + res.status);
        if (res.status === 401) return { error: "Sai tai khoan hoac mat khau." };
        if (res.status === 429) return { error: "Qua nhieu lan thu dang nhap. Thu lai sau 15 phut." };
        return { error: "Dang nhap that bai: " + msg };
    }
    var json = res.json || {};
    if (json.step === "otp_required" || json.otp_required === true || json.needOtp === true) {
        return { otpRequired: true, maskedEmail: json.maskedEmail || "" };
    }
    var t = ttcPickToken(json, res.headers, res.text);
    if (!t.token) {
        return { error: "Dang nhap khong tra ve token. Server tra: " + JSON.stringify(json).slice(0, 160) };
    }
    return { token: t.token, refreshToken: t.refreshToken };
}

// Buoc 1.5: POST /api/auth/send-login-otp -> gui ma 6 so
function ttcSendLoginOtp(username, password) {
    var body = { username: username };
    if (password) body.password = password;
    var res = ttcPostJson("/api/auth/send-login-otp", body);
    if (res.ok && res.json && res.json.success) return { ok: true };
    var json = res.json || {};
    var msg = json.message ? json.message : ("HTTP " + res.status);
    var cd = parseInt(json.cooldownSeconds || 0, 10);
    if (cd > 0) return { error: "Vui long cho " + cd + " giay truoc khi gui lai ma OTP." };
    return { error: "Gui OTP that bai: " + msg };
}

// Buoc 2: POST /api/auth/verify-login-otp -> tra token
// Contract da kiem chung live: field "otp", BAT BUOC co "username".
function ttcVerifyLoginOtp(username, password, otp) {
    var body = { otp: otp, username: username };
    if (password) body.password = password;
    var res = ttcPostJson("/api/auth/verify-login-otp", body);
    if (!res.ok) {
        var msg = (res.json && res.json.message) ? res.json.message : ("HTTP " + res.status);
        if (res.status === 429) return { error: "Qua nhieu yeu cau OTP. Thu lai sau." };
        if (res.status === 400) {
            if (/het han|hết hạn|expired/i.test(msg)) {
                return { error: "Ma OTP da het han. Mo lai chuong de plugin gui ma moi, roi dan ma moi vao o 'Ma OTP'." };
            }
            return { error: "OTP khong dung: " + msg };
        }
        return { error: "Xac nhan OTP that bai: " + msg };
    }
    var t = ttcPickToken(res.json, res.headers, res.text);
    if (!t.token) {
        return { error: "Xac nhan OTP xong nhung khong tra ve token. Server tra: " +
                       JSON.stringify(res.json).slice(0, 160) };
    }
    return { token: t.token, refreshToken: t.refreshToken };
}

function ttcRegister(email, username, password) {
    var res = ttcPostJson("/api/auth/register", { email: email, username: username, password: password });
    if (res.ok) {
        var t = ttcPickToken(res.json, res.headers, res.text);
        if (t.token) return { token: t.token, refreshToken: t.refreshToken };
        var lg = ttcLoginStep1(username, password);
        if (lg.token) return lg;
        return { error: "Dang ky thanh cong nhung khong lay duoc token." };
    }
    var msg = (res.json && res.json.message) ? res.json.message : ("HTTP " + res.status);
    if (res.status === 429) return { error: "Qua nhieu lan dang ky. Thu lai sau 1 gio." };
    return { error: "Dang ky that bai: " + msg };
}

function ttcRefresh(username, refreshToken) {
    if (!username || !refreshToken) return { error: "Khong co refresh token." };
    var res = ttcPostJson("/api/auth/refresh", { username: username, refreshToken: refreshToken });
    if (!res.ok) return { error: "Gia han token that bai." };
    var t = ttcPickToken(res.json, res.headers, res.text);
    if (!t.token) return { error: "Gia han token khong tra ve token moi." };
    return { token: t.token };
}

function ttcGetToken(forceRelogin) {
    var cred = ttcCfgCredential();
    if (cred.type === "none") {
        var raw = ttcRawToken();
        if (raw.type === "jwt") cred = raw;
    }

    if (cred.type === "none") {
        return {
            error: "Chua cau hinh tai khoan. Mo 'Cai dat extension' cua plugin nay va dien:" +
                   "Tien tai khoan + Mat khau (tai khoan co san) - hoac chi Email Gmail " +
                   "(plugin tu dang ky tai khoan moi)."
        };
    }
    if (cred.type === "jwt") {
        if (forceRelogin) return { error: "accessToken da het han. Hay dung tai khoan + mat khau de tu gia han." };
        return { token: cred.token };
    }

    if (cred.type === "autoregister") {
        if (!/@gmail\.com$/i.test(cred.email)) {
            return { error: "Chi chap nhan email Gmail (@gmail.com) de tu dang ky. Server tu choi email khac." };
        }
        var savedUser = ttcCfgGet(TTC_CFG.username);
        var savedPass = ttcCfgGet(TTC_CFG.password);
        var wasAuto = ttcCfgGet(TTC_CFG.auto) === "1";
        if (wasAuto && savedUser && savedPass) {
            var reuse = ttcLoginStep1(savedUser, savedPass);
            if (reuse.token) {
                ttcWriteCache(savedUser, reuse.token, reuse.refreshToken);
                return { token: reuse.token };
            }
        }
        var autoUser = ttcMakeUsername(cred.email);
        var autoPass = ttcMakePassword();
        var autoReg = ttcRegister(cred.email, autoUser, autoPass);
        if (autoReg.token) {
            ttcWriteCache(autoUser, autoReg.token, autoReg.refreshToken);
            ttcCfgSet(TTC_CFG.username, autoUser);
            ttcCfgSet(TTC_CFG.password, autoPass);
            ttcCfgSet(TTC_CFG.auto, "1");
            return { token: autoReg.token };
        }
        return autoReg;
    }

    var username = cred.username;
    var password = cred.password || "";

    if (cred.otp) {
        var vr = ttcVerifyLoginOtp(username, password, cred.otp);
        ttcCfgRemove(TTC_CFG.otp);
        if (vr.token) {
            ttcWriteCache(username, vr.token, vr.refreshToken);
            return { token: vr.token };
        }
        return { error: vr.error || "Xac nhan OTP that bai." };
    }

    var cached = null;
    try {
        var st = ttcStore();
        cached = st ? JSON.parse(st.getItem(TTC_TOKEN_KEY) || "null") : null;
    } catch (e) {}
    if (!cached || cached.username !== username) cached = null;

    if (!forceRelogin && cached && cached.token && ttcTokenFresh(cached.token)) {
        return { token: cached.token };
    }
    if (cached && cached.refreshToken) {
        var r = ttcRefresh(username, cached.refreshToken);
        if (r.token) {
            ttcWriteCache(username, r.token, cached.refreshToken);
            return { token: r.token };
        }
    }

    var lg = ttcLoginStep1(username, password);
    if (lg.token) {
        ttcWriteCache(username, lg.token, lg.refreshToken);
        return { token: lg.token };
    }
    if (lg.otpRequired) {
        var sent = ttcSendLoginOtp(username, password);
        if (sent.ok) {
            return {
                error: "Server yeu cau ma OTP (gui toi " + (lg.maskedEmail || "email cua tai khoan") + "). " +
                       "Da gui ma 6 so. Lay ma trong Gmail roi dan vao o 'Ma OTP' cua plugin nay, roi mo lai chuong."
            };
        }
        return { error: "Tai khoan can xac nhan OTP. " + (sent.error || "") };
    }
    if (forceRelogin) ttcClearCache();
    return lg;
}

function ttcRetryAuth() {
    var r = ttcGetToken(true);
    return r.token || null;
}
