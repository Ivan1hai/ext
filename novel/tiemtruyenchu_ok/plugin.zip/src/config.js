// Tiệm Truyện Chữ - cấu hình chung
// API thật: https://tiemtruyenchu.cloud  (React Native / Expo, app v1.1.1)
//
// Ghi chú từ phân tích APK (com.tiemtruyenchu.app 1.1.1):
//   - Base URL        : https://tiemtruyenchu.cloud
//   - Auth            : Bearer JWT, lấy từ POST /api/auth/login + verify-login-otp
//   - Danh sách       : GET /api/v1/stories?page=&limit=&cat=&type=&status=&gender=&sort=
//   - Tìm kiếm       : GET /api/v1/stories?keyword=  (KHÔNG có route /api/v1/search)
//                       -> server khớp full-text, PHẢI giữ dấu tiếng Việt
//   - Chi tiết + TOC  : GET /api/v1/stories/{id}  -> trả kèm mảng "chapters" đầy đủ
//   - Nội dung chương : POST /api/v1/chapters/content  {storyId, chapterNumber}

var TTC_API = "https://tiemtruyenchu.cloud";
var TTC_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36";
var TTC_PAGE_SIZE = 30;

// Key cấu hình trong localConfig của vBook
var TTC_CFG = {
    email: "ttc_email",
    username: "ttc_username",
    password: "ttc_password",
    otp: "ttc_otp",
    auto: "ttc_auto_account"
};

function ttcStoryLink(id, slug) {
    if (slug) return TTC_API + "/truyen/" + id + "/" + slug;
    return TTC_API + "/truyen/" + id;
}

function ttcTrim(text) {
    if (text === null || typeof text === "undefined") return "";
    return ("" + text).replace(/^\s+|\s+$/g, "");
}

function ttcFold(text) {
    var value = ttcTrim(text).toLowerCase();
    try {
        if (typeof value.normalize === "function") {
            value = value.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
        }
    } catch (e) {}
    return value.replace(/đ/g, "d");
}

function ttcSlug(text) {
    return ttcFold(text).replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function ttcCover(path) {
    var raw = ttcTrim(path);
    if (!raw) return "";
    if (raw.indexOf("http://") === 0) return raw.replace(/^http:\/\//i, "https://");
    if (raw.indexOf("https://") === 0) return raw;
    if (raw.indexOf("//") === 0) return "https:" + raw;
    return TTC_API + (raw.charAt(0) === "/" ? "" : "/") + raw;
}

function ttcStoryId(url) {
    var m = ("" + (url || "")).match(/\/truyen\/(\d+)/i);
    if (m) return parseInt(m[1], 10);
    m = ("" + (url || "")).match(/\bstoryId=(\d+)/i);
    if (m) return parseInt(m[1], 10);
    m = ("" + (url || "")).match(/\/stories\/(\d+)/i);
    if (m) return parseInt(m[1], 10);
    return 0;
}

function ttcToBooks(items) {
    var out = [];
    if (!items || !items.length) return out;
    items.forEach(function(item) {
        if (!item) return;
        var name = ttcTrim(item.title || item.name || "");
        if (!name) return;
        var link = ttcStoryLink(item.id, item.slug);
        var desc = "";
        if (item.author) desc += item.author;
        if (item.category) desc += (desc ? " | " : "") + item.category;
        if (item.status) desc += (desc ? " | " : "") + (item.status === "full" ? "Hoan thanh" : "Dang ra");
        if (item.total_chapters) desc += (desc ? " | " : "") + item.total_chapters + " chuong";
        if (item.latest_chapter_title) desc += (desc ? " | " : "") + item.latest_chapter_title;
        out.push({
            name: name, link: link, host: TTC_API,
            cover: ttcCover(item.cover_url || item.poster || ""),
            description: desc
        });
    });
    return out;
}

function ttcRequest(path, method, body, token, onAuthRetry) {
    var headers = {
        "User-Agent": TTC_UA,
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "vi,en;q=0.8",
        "Referer": TTC_API + "/",
        "Origin": TTC_API
    };
    if (token) headers.Authorization = "Bearer " + token;
    var options = { method: method || "GET", headers: headers };
    if (body !== null && typeof body !== "undefined") {
        options.body = JSON.stringify(body);
        headers["Content-Type"] = "application/json";
    }
    var response = null;
    try {
        response = fetch(TTC_API + path, options);
    } catch (e) {
        return { ok: false, status: 0, json: null, error: "Khong ket noi duoc may chu." };
    }
    var json = null;
    try { json = response.json(); } catch (e) {}
    if (response.status === 401 && token && typeof onAuthRetry === "function") {
        var fresh = onAuthRetry();
        if (fresh) return ttcRequest(path, method, body, fresh, null);
    }
    return { ok: response.ok, status: response.status, json: json };
}
