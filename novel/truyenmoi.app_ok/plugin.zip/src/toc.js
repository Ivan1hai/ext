load("config.js");

function execute(url) {
    var apiUrl = url;
    var slug = "";

    if (url.indexOf("/list-chapters") !== -1) {
        var m = url.match(/\/truyen\/([^/]+)\/list-chapters/);
        if (m) slug = m[1];
    } else if (url.indexOf("/truyen/") !== -1) {
        slug = url.replace(/\/$/, "").split("/truyen/")[1].split("/")[0].split("?")[0];
        apiUrl = BASE_URL + "/truyen/" + slug + "/list-chapters?page=1&per_page=1000";
    } else {
        slug = url.replace(/\/$/, "").split("/").pop();
        apiUrl = BASE_URL + "/truyen/" + slug + "/list-chapters?page=1&per_page=1000";
    }

    var res = fetch(apiUrl, {
        headers: {
            "Accept": "application/json"
        }
    });
    if (!res.ok) return Response.error("Không thể tải mục lục chương");

    var json = res.json();
    var list = [];
    if (json && json.data && json.data.length > 0) {
        for (var i = 0; i < json.data.length; i++) {
            var item = json.data[i];
            var chapNum = item.chapter_number || (i + 1);
            list.push({
                name: item.title,
                url: "/truyen/" + slug + "/chuong-" + chapNum,
                host: BASE_URL
            });
        }
    }

    return Response.success(list);
}
