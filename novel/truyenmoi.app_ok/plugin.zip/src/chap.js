load("config.js");

function execute(url) {
    if (url.indexOf("http") !== 0) {
        url = BASE_URL + (url.indexOf("/") === 0 ? "" : "/") + url;
    }

    var res = fetch(url);
    if (!res.ok) return Response.error("Không thể tải nội dung chương");

    var doc = res.html();
    var contentEl = doc.select("#chapter-content");
    if (!contentEl || contentEl.size() === 0) {
        return Response.error("Không tìm thấy nội dung chương");
    }

    contentEl.select("script, style, noscript").remove();
    var content = contentEl.html();

    return Response.success(content);
}
