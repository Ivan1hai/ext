function execute() {
    return Response.success([
        { title: "Mới cập nhật", input: "https://truyenmoi.app/truyen/moi-cap-nhat", script: "gen.js" },
        { title: "Xem nhiều", input: "https://truyenmoi.app/truyen?sort=views&direction=desc", script: "gen.js" }
    ]);
}
