var BASE_URL = "https://truyenmoi.app";
try {
    if (CONFIG_URL) BASE_URL = CONFIG_URL;
} catch (e) {}
