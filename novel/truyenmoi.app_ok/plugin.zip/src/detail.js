load("config.js");

function execute(url) {
    url = url.replace(/\/$/, "");
    var res = fetch(url);
    if (!res.ok) return Response.error("Không thể tải thông tin truyện");

    var doc = res.html();

    var name = "";
    var h1 = doc.select("h1").first();
    if (h1) name = h1.text().trim();
    if (!name) {
        name = doc.select("meta[property='og:title']").attr("content") || "";
    }

    var cover = doc.select("meta[property='og:image']").attr("content") || "";
    var author = doc.select("meta[name='author']").attr("content") || "";
    var description = doc.select("meta[name='description']").attr("content") || "";

    var ongoing = doc.html().indexOf("Đang ra") !== -1;

    var genres = [];
    doc.select("a[href*='/truyen/the-loai/']").forEach(function(el) {
        var t = el.text().trim();
        var h = el.attr("href");
        if (t && h) {
            genres.push({
                title: t,
                input: h,
                script: "gen.js"
            });
        }
    });

    var detail = "";
    if (author) detail += "Tác giả: " + author;

    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: description,
        detail: detail,
        ongoing: ongoing,
        host: BASE_URL,
        genres: genres
    });
}
