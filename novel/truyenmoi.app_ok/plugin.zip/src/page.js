load("config.js");

function execute(url) {
    url = url.replace(/\/$/, "");
    var slug = "";
    if (url.indexOf("/truyen/") !== -1) {
        slug = url.split("/truyen/")[1].split("/")[0].split("?")[0];
    } else {
        slug = url.split("/").pop();
    }

    var apiUrl = BASE_URL + "/truyen/" + slug + "/list-chapters?page=1&per_page=1000";
    var res = fetch(apiUrl, {
        headers: {
            "Accept": "application/json"
        }
    });
    if (!res.ok) return Response.error("Không thể tải danh sách trang mục lục");

    var json = res.json();
    var lastPage = 1;
    if (json && json.meta && json.meta.last_page) {
        lastPage = json.meta.last_page;
    }

    var pages = [];
    for (var p = 1; p <= lastPage; p++) {
        pages.push(BASE_URL + "/truyen/" + slug + "/list-chapters?page=" + p + "&per_page=1000");
    }

    return Response.success(pages);
}
