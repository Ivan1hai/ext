load("config.js");

function execute(key, page) {
    var pageNum = 1;
    if (page) {
        pageNum = parseInt(page);
    }

    var url = BASE_URL + "/truyen?search=" + encodeURIComponent(key);
    if (pageNum > 1) {
        url += "&page=" + pageNum;
    }

    var res = fetch(url);
    if (!res.ok) return Response.error("Không thể tìm kiếm truyện");

    var doc = res.html();
    var list = [];

    var articles = doc.select("article");
    if (articles.size() > 0) {
        articles.forEach(function(el) {
            var a = el.select("a[itemprop='url']").first();
            if (!a) a = el.select("a[href*='/truyen/']").first();
            if (!a) return;

            var href = a.attr("href");
            if (!href || href.indexOf("/the-loai") !== -1 || href.indexOf("/moi-cap-nhat") !== -1) return;

            var titleEl = el.select(".story-title-text").first();
            var name = titleEl ? titleEl.text().trim() : (a.attr("title") || "").trim();
            if (!name) name = a.text().trim();

            var img = el.select("img").first();
            var cover = img ? (img.attr("data-src") || img.attr("src") || "") : "";

            var authorEl = el.select("[itemprop='author']").first();
            var desc = authorEl ? authorEl.text().trim() : "";

            list.push({
                name: name,
                link: href,
                cover: cover,
                description: desc,
                host: BASE_URL
            });
        });
    }

    var hasNext = doc.select("link[rel='next']").size() > 0;
    var next = (hasNext && list.length > 0) ? (pageNum + 1) + "" : null;

    return Response.success(list, next);
}
