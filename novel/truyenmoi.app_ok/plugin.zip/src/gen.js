load("config.js");

function execute(url, page) {
    var pageNum = 1;
    if (page) {
        pageNum = parseInt(page);
    }

    if (pageNum > 1) {
        var sep = url.indexOf("?") >= 0 ? "&" : "?";
        url = url + sep + "page=" + pageNum;
    }

    var res = fetch(url);
    if (!res.ok) return Response.error("Không thể tải danh sách");

    var doc = res.html();
    var list = [];

    // Case 1: Grid items (article)
    var articles = doc.select("article");
    if (articles.size() > 0) {
        articles.forEach(function(el) {
            var a = el.select("a[itemprop='url']").first();
            if (!a) a = el.select("a[href*='/truyen/']").first();
            if (!a) return;

            var href = a.attr("href");
            if (!href || href.indexOf("/the-loai") !== -1 || href.indexOf("/moi-cap-nhat") !== -1) return;

            var titleEl = el.select(".story-title-text").first();
            var name = titleEl ? titleEl.text().trim() : (a.attr("title") || "").trim();
            if (!name) name = a.text().trim();

            var img = el.select("img").first();
            var cover = img ? (img.attr("data-src") || img.attr("src") || "") : "";

            var authorEl = el.select("[itemprop='author']").first();
            var desc = authorEl ? authorEl.text().trim() : "";

            list.push({
                name: name,
                link: href,
                cover: cover,
                description: desc,
                host: BASE_URL
            });
        });
    } else if (doc.select("tr").size() > 0) {
        // Case 2: Desktop table (tr)
        var rows = doc.select("tr");
        rows.forEach(function(row) {
            var a = row.select("a[href*='/truyen/']").first();
            if (!a) return;

            var href = a.attr("href");
            if (!href || href.indexOf("/the-loai") !== -1 || href.indexOf("/chuong-") !== -1) return;

            var name = a.attr("title") || a.text().trim();
            if (!name) return;

            var chap = row.select("a[href*='/chuong-']").first();
            var time = row.select("td.text-xs").first();
            var desc = "";
            if (chap) desc += chap.text().trim();
            if (time) desc += (desc ? " - " : "") + time.text().trim();

            var cleanHref = href.replace(/\/$/, "");
            var slug = cleanHref.split("/").pop();
            var cover = "https://cdn.truyenmoi.app/webp/" + slug + ".webp";

            list.push({
                name: name,
                link: href,
                cover: cover,
                description: desc,
                host: BASE_URL
            });
        });
    } else {
        // Case 3: Mobile card layout (div.border-b on /truyen/moi-cap-nhat)
        var cards = doc.select("div.border-b.border-gray-200");
        cards.forEach(function(card) {
            var a = card.select("a[href*='/truyen/']").first();
            if (!a) return;

            var href = a.attr("href");
            if (!href || href.indexOf("/the-loai") !== -1 || href.indexOf("/chuong-") !== -1) return;

            var name = (a.attr("title") || a.text() || "").trim();
            if (!name) return;

            var chap = card.select("a[href*='/chuong-']").first();
            var time = card.select("span").last();
            var desc = "";
            if (chap) desc += chap.text().trim();
            if (time) desc += (desc ? " - " : "") + time.text().trim();

            var cleanHref = href.replace(/\/$/, "");
            var slug = cleanHref.split("/").pop();
            var cover = "https://cdn.truyenmoi.app/webp/" + slug + ".webp";

            list.push({
                name: name,
                link: href,
                cover: cover,
                description: desc,
                host: BASE_URL
            });
        });
    }

    var hasNext = doc.select("link[rel='next']").size() > 0;
    var next = (hasNext && list.length > 0) ? (pageNum + 1) + "" : null;

    return Response.success(list, next);
}
