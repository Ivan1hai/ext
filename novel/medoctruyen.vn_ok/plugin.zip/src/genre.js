load("config.js");

function execute() {
    var response = fetch(API_URL + "/genres");
    if (!response.ok) return null;

    var json = response.json();
    if (!json || !json.data) return null;

    var genres = [];
    json.data.forEach(function (item) {
        if (item.type === "genre") {
            genres.push({
                title: item.name,
                input: item.slug,
                script: "gen.js"
            });
        }
    });

    return Response.success(genres);
}
