load("config.js");

function execute(url) {
    var match = String(url || "").match(/___toc_page___([^?#]+)\?page=(\d+)/);
    if (match) {
        var storyId = match[1];
        var page = match[2];

        var response = fetch(API_URL + "/stories/" + storyId + "/chapters?page=" + page);
        if (!response.ok) return null;

        var json = response.json();
        if (!json || !json.data) return null;

        var chapters = [];
        json.data.forEach(function (item) {
            chapters.push({
                name: cleanText("Chương " + item.chapter_number + (item.title ? ": " + item.title : "")),
                url: BASE_URL + "/___chap___" + storyId + "___" + item.id,
                host: BASE_URL
            });
        });

        return Response.success(chapters);
    }

    var chapMatch = String(url || "").match(/___chap___([^_]+)___(\d+)/);
    if (chapMatch) {
        var chapStoryId = chapMatch[1];
        var chapId = chapMatch[2];

        var chapResp = fetch(API_URL + "/stories/" + chapStoryId + "/chapters/" + chapId);
        if (!chapResp.ok) return null;

        var chapJson = chapResp.json();
        if (!chapJson || !chapJson.data || !chapJson.data.content) return null;

        var content = chapJson.data.content;
        content = cleanContent(content);

        return Response.success(content);
    }

    return null;
}

function cleanContent(text) {
    return (text || "")
        .replace(/&nbsp;/gi, " ")
        .replace(/(<br\s*\/?>\s*){3,}/gi, "<br><br>")
        .replace(/\n{3,}/g, "\n\n")
        .trim();
}
