load("config.js");

function execute(url) {
    var match = String(url || "").match(/___story_(\w+)\/chuong-(\d+)/);
    if (!match) return null;

    var storyId = match[1];
    var chapId = match[2];
    var apiUrl = API_URL + "/stories/" + storyId + "/chapters/" + chapId;

    var json = fetchChapter(apiUrl);
    if (!json) return null;

    var content = json.data.content || "";
    content = cleanContent(content);
    return Response.success(content);
}

function fetchChapter(url) {
    for (var retry = 0; retry < 3; retry++) {
        if (retry > 0) sleep(2000);

        var response = fetch(url);
        if (!response.ok) continue;

        var json = response.json();
        if (!json) continue;
        if (json.error) {
            sleep(3000);
            continue;
        }
        if (!json.data) continue;

        return json;
    }
    return null;
}

function cleanContent(text) {
    if (!text) return "";
    text = text
        .replace(/&nbsp;/gi, " ")
        .replace(/\r\n/g, "\n")
        .replace(/\n{3,}/g, "\n\n")
        .replace(/\n/g, "<br>")
        .trim();
    return text;
}