var BASE_URL = "https://medoctruyen.vn";
var API_URL = "https://medoctruyen.vn/api";

function absoluteUrl(url) {
    if (!url) return "";
    if (/^https?:\/\//i.test(url)) return url;
    if (url.indexOf("//") === 0) return BASE_URL.split(":")[0] + ":" + url;
    if (url.charAt(0) === "/") return BASE_URL + url;
    return BASE_URL + "/" + url.replace(/^\/+/, "");
}

function resourceUrl(url) {
    if (!url) return "";
    if (/^https?:\/\//i.test(url)) return url;
    if (url.indexOf("//") === 0) return BASE_URL.split(":")[0] + ":" + url;
    if (url.charAt(0) === "/") return BASE_URL + url;
    return BASE_URL + "/" + url.replace(/^\/+/, "");
}

function extractSlug(url) {
    if (!url) return "";
    var match = String(url).match(/medoctruyen\.vn\/([^/?#]+)/i);
    return match ? match[1] : "";
}

function extractChapterNumber(url) {
    if (!url) return "";
    var match = String(url).match(/chuong-(\d+)/i);
    return match ? match[1] : "";
}

function apiFetch(path) {
    var response = fetch(API_URL + path);
    if (!response.ok) return null;
    return response.json();
}

function cleanText(text) {
    return (text || "")
        .replace(/\u00a0/g, " ")
        .replace(/\s+/g, " ")
        .trim();
}
