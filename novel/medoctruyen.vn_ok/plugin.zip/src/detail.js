load("config.js");

function execute(url) {
    var slug = extractSlug(url);
    if (!slug) return null;

    var response = fetch(API_URL + "/stories?slug=" + encodeURIComponent(slug));
    if (!response.ok) return null;

    var json = response.json();
    if (!json || !json.data || json.data.length === 0) return null;

    var item = json.data[0];
    var genres = [];
    if (item.genres) {
        item.genres.forEach(function (g) {
            genres.push({
                title: g.name,
                input: g.slug,
                script: "gen.js"
            });
        });
    }

    var detailLines = [];
    if (item.author_translated) {
        detailLines.push("Tác giả: " + item.author_translated);
    }
    if (item.status) {
        var statusMap = {
            "ongoing": "Đang ra",
            "completed": "Hoàn thành",
            "dropped": "Ngưng"
        };
        detailLines.push("Trạng thái: " + (statusMap[item.status] || item.status));
    }
    if (item.story_type) {
        var typeMap = {
            "translate": "Dịch",
            "convert": "Convert",
            "original": "Sáng tác"
        };
        detailLines.push("Loại: " + (typeMap[item.story_type] || item.story_type));
    }

    return Response.success({
        name: cleanText(item.title_translated),
        cover: resourceUrl(item.cover_url),
        author: item.author_translated || "",
        description: item.description || "",
        detail: detailLines.join("<br>"),
        host: BASE_URL,
        ongoing: item.status === "ongoing",
        genres: genres
    });
}
