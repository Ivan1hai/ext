load("config.js");

function execute(url) {
    var tocMatch = String(url || "").match(/___toc___(\w+?)___(\d+)/);
    if (!tocMatch) return null;

    var storyId = tocMatch[1];
    var page = tocMatch[2];

    var response = fetch(API_URL + "/stories/" + storyId + "/chapters?page=" + page);
    if (!response.ok) return null;

    var json = response.json();
    if (!json || !json.data) return null;

    var chapters = [];
    json.data.forEach(function (item) {
        chapters.push({
            name: cleanText("Chương " + item.chapter_number + (item.title ? ": " + item.title : "")),
            url: BASE_URL + "/___story_" + storyId + "/chuong-" + item.id,
            host: BASE_URL
        });
    });

    return Response.success(chapters);
}