load("config.js");

function execute(url) {
    var slug = extractSlug(url);
    if (!slug) return null;

    var storyResp = fetch(API_URL + "/stories?slug=" + encodeURIComponent(slug));
    if (!storyResp.ok) return null;

    var storyJson = storyResp.json();
    if (!storyJson || !storyJson.data || storyJson.data.length === 0) return null;

    var storyId = storyJson.data[0].id;

    var chaptersResp = fetch(API_URL + "/stories/" + storyId + "/chapters?page=1");
    if (!chaptersResp.ok) return null;

    var chaptersJson = chaptersResp.json();
    if (!chaptersJson || !chaptersJson.data) return null;

    var totalPages = chaptersJson.pagination ? chaptersJson.pagination.total_pages : 1;
    var pages = [];

    for (var i = 1; i <= totalPages; i++) {
        pages.push(BASE_URL + "/___toc_page___" + storyId + "?page=" + i);
    }

    return Response.success(pages);
}
