load("config.js");

function execute() {
    return Response.success([
        { title: "Mới cập nhật", input: "updated", script: "gen.js" },
        { title: "Truyện mới", input: "new", script: "gen.js" },
        { title: "Xem nhiều", input: "popular", script: "gen.js" }
    ]);
}