load("config.js");

function execute(url) {
    var response = fetch(API_URL + "/stories?sort=updated&page=1");
    if (!response.ok) return null;

    var json = response.json();
    if (!json || !json.data) return null;

    var data = [];
    json.data.forEach(function (item) {
        data.push({
            name: cleanText(item.title_translated),
            link: absoluteUrl("/" + item.slug),
            cover: resourceUrl(item.cover_url),
            description: cleanText(item.author_translated + " - " + item.latest_chapter_title),
            host: BASE_URL
        });
    });

    return Response.success(data);
}