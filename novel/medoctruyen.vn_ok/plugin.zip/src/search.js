load("config.js");

function execute(key, page) {
    if (!key) return null;

    var pageNum = page ? parseInt(page) : 1;
    var apiUrl = API_URL + "/stories?q=" + encodeURIComponent(key) + "&page=" + pageNum;

    var response = fetch(apiUrl);
    if (!response.ok) return null;

    var json = response.json();
    if (!json || !json.data) return null;

    var data = [];
    json.data.forEach(function (item) {
        data.push({
            name: cleanText(item.title_translated),
            link: absoluteUrl("/" + item.slug),
            cover: resourceUrl(item.cover_url),
            description: cleanText(item.author_translated),
            host: BASE_URL
        });
    });

    var nextPage = null;
    if (json.pagination && json.pagination.page < json.pagination.total_pages) {
        nextPage = (json.pagination.page + 1).toString();
    }

    return Response.success(data, nextPage);
}