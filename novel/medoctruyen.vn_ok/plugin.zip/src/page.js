load("config.js");

function execute(url) {
    var slug = extractSlug(url);
    if (!slug) return null;

    var response = fetch(API_URL + "/stories?slug=" + encodeURIComponent(slug));
    if (!response.ok) return null;

    var json = response.json();
    if (!json || !json.data || json.data.length === 0) return null;

    var storyId = null;
    for (var i = 0; i < json.data.length; i++) {
        if (json.data[i].slug === slug) {
            storyId = json.data[i].id;
            break;
        }
    }
    if (!storyId) storyId = json.data[0].id;

    var chaptersResp = fetch(API_URL + "/stories/" + storyId + "/chapters?page=1");
    if (!chaptersResp.ok) return null;

    var chaptersJson = chaptersResp.json();
    if (!chaptersJson || !chaptersJson.data) return null;

    var totalPages = chaptersJson.pagination ? chaptersJson.pagination.total_pages : 1;
    var pages = [];

    for (var i = 1; i <= totalPages; i++) {
        pages.push("___toc___" + storyId + "___" + i);
    }

    return Response.success(pages);
}