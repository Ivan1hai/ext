// Pure JS MD5 - RFC 1321 implementation. No dependencies.
var MD5 = (function () {
    var HEX = "0123456789abcdef";

    function md5(text) {
        var s = String(text || "");
        var len = s.length;
        var w = new Array((((len + 8) >> 6) + 1) * 16);

        for (var i = 0; i < w.length; i++) w[i] = 0;

        for (i = 0; i < len; i++) {
            w[i >> 2] |= s.charCodeAt(i) << ((i & 3) << 3);
        }
        w[i >> 2] |= 0x80 << ((i & 3) << 3);
        w[w.length - 2] = len << 3;

        var a = 1732584193;
        var b = -271733879;
        var c = -1732584194;
        var d = 271733878;

        for (var j = 0; j < w.length; j += 16) {
            var oa = a, ob = b, oc = c, od = d;

            a = rot(a + ((b & c) | (~b & d)) + w[j]      + 0xd76aa478,  7) + b;
            d = rot(d + ((a & b) | (~a & c)) + w[j +  1] + 0xe8c7b756, 12) + a;
            c = rot(c + ((d & a) | (~d & b)) + w[j +  2] + 0x242070db, 17) + d;
            b = rot(b + ((c & d) | (~c & a)) + w[j +  3] + 0xc1bdceee, 22) + c;
            a = rot(a + ((b & c) | (~b & d)) + w[j +  4] + 0xf57c0faf,  7) + b;
            d = rot(d + ((a & b) | (~a & c)) + w[j +  5] + 0x4787c62a, 12) + a;
            c = rot(c + ((d & a) | (~d & b)) + w[j +  6] + 0xa8304613, 17) + d;
            b = rot(b + ((c & d) | (~c & a)) + w[j +  7] + 0xfd469501, 22) + c;
            a = rot(a + ((b & c) | (~b & d)) + w[j +  8] + 0x698098d8,  7) + b;
            d = rot(d + ((a & b) | (~a & c)) + w[j +  9] + 0x8b44f7af, 12) + a;
            c = rot(c + ((d & a) | (~d & b)) + w[j + 10] + 0xffff5bb1, 17) + d;
            b = rot(b + ((c & d) | (~c & a)) + w[j + 11] + 0x895cd7be, 22) + c;
            a = rot(a + ((b & c) | (~b & d)) + w[j + 12] + 0x6b901122,  7) + b;
            d = rot(d + ((a & b) | (~a & c)) + w[j + 13] + 0xfd987193, 12) + a;
            c = rot(c + ((d & a) | (~d & b)) + w[j + 14] + 0xa679438e, 17) + d;
            b = rot(b + ((c & d) | (~c & a)) + w[j + 15] + 0x49b40821, 22) + c;

            a = rot(a + ((b & d) | (c & ~d)) + w[j +  1] + 0xf61e2562,  5) + b;
            d = rot(d + ((a & c) | (b & ~c)) + w[j +  6] + 0xc040b340,  9) + a;
            c = rot(c + ((d & b) | (a & ~b)) + w[j + 11] + 0x265e5a51, 14) + d;
            b = rot(b + ((c & a) | (d & ~a)) + w[j     ] + 0xe9b6c7aa, 20) + c;
            a = rot(a + ((b & d) | (c & ~d)) + w[j +  5] + 0xd62f105d,  5) + b;
            d = rot(d + ((a & c) | (b & ~c)) + w[j + 10] + 0x02441453,  9) + a;
            c = rot(c + ((d & b) | (a & ~b)) + w[j + 15] + 0xd8a1e681, 14) + d;
            b = rot(b + ((c & a) | (d & ~a)) + w[j +  4] + 0xe7d3fbc8, 20) + c;
            a = rot(a + ((b & d) | (c & ~d)) + w[j +  9] + 0x21e1cde6,  5) + b;
            d = rot(d + ((a & c) | (b & ~c)) + w[j + 14] + 0xc33707d6,  9) + a;
            c = rot(c + ((d & b) | (a & ~b)) + w[j +  3] + 0xf4d50d87, 14) + d;
            b = rot(b + ((c & a) | (d & ~a)) + w[j +  8] + 0x455a14ed, 20) + c;
            a = rot(a + ((b & d) | (c & ~d)) + w[j + 13] + 0xa9e3e905,  5) + b;
            d = rot(d + ((a & c) | (b & ~c)) + w[j +  2] + 0xfcefa3f8,  9) + a;
            c = rot(c + ((d & b) | (a & ~b)) + w[j +  7] + 0x676f02d9, 14) + d;
            b = rot(b + ((c & a) | (d & ~a)) + w[j + 12] + 0x8d2a4c8a, 20) + c;

            a = rot(a + (b ^ c ^ d)        + w[j +  5] + 0xfffa3942,  4) + b;
            d = rot(d + (a ^ b ^ c)        + w[j +  8] + 0x8771f681, 11) + a;
            c = rot(c + (d ^ a ^ b)        + w[j + 11] + 0x6d9d6122, 16) + d;
            b = rot(b + (c ^ d ^ a)        + w[j + 14] + 0xfde5380c, 23) + c;
            a = rot(a + (b ^ c ^ d)        + w[j +  1] + 0xa4beea44,  4) + b;
            d = rot(d + (a ^ b ^ c)        + w[j +  4] + 0x4bdecfa9, 11) + a;
            c = rot(c + (d ^ a ^ b)        + w[j +  7] + 0xf6bb4b60, 16) + d;
            b = rot(b + (c ^ d ^ a)        + w[j + 10] + 0xbebfbc70, 23) + c;
            a = rot(a + (b ^ c ^ d)        + w[j + 13] + 0x289b7ec6,  4) + b;
            d = rot(d + (a ^ b ^ c)        + w[j     ] + 0xeaa127fa, 11) + a;
            c = rot(c + (d ^ a ^ b)        + w[j +  3] + 0xd4ef3085, 16) + d;
            b = rot(b + (c ^ d ^ a)        + w[j +  6] + 0x04881d05, 23) + c;
            a = rot(a + (b ^ c ^ d)        + w[j +  9] + 0xd9d4d039,  4) + b;
            d = rot(d + (a ^ b ^ c)        + w[j + 12] + 0xe6db99e5, 11) + a;
            c = rot(c + (d ^ a ^ b)        + w[j + 15] + 0x1fa27cf8, 16) + d;
            b = rot(b + (c ^ d ^ a)        + w[j +  2] + 0xc4ac5665, 23) + c;

            a = rot(a + (c ^ (b | ~d))      + w[j     ] + 0xf4292244,  6) + b;
            d = rot(d + (b ^ (a | ~c))      + w[j +  7] + 0x432aff97, 10) + a;
            c = rot(c + (a ^ (d | ~b))      + w[j + 14] + 0xab9423a7, 15) + d;
            b = rot(b + (d ^ (c | ~a))      + w[j +  5] + 0xfc93a039, 21) + c;
            a = rot(a + (c ^ (b | ~d))      + w[j + 12] + 0x655b59c3,  6) + b;
            d = rot(d + (b ^ (a | ~c))      + w[j +  3] + 0x8f0ccc92, 10) + a;
            c = rot(c + (a ^ (d | ~b))      + w[j + 10] + 0xffeff47d, 15) + d;
            b = rot(b + (d ^ (c | ~a))      + w[j +  1] + 0x85845dd1, 21) + c;
            a = rot(a + (c ^ (b | ~d))      + w[j +  8] + 0x6fa87e4f,  6) + b;
            d = rot(d + (b ^ (a | ~c))      + w[j + 15] + 0xfe2ce6e0, 10) + a;
            c = rot(c + (a ^ (d | ~b))      + w[j +  6] + 0xa3014314, 15) + d;
            b = rot(b + (d ^ (c | ~a))      + w[j + 13] + 0x4e0811a1, 21) + c;
            a = rot(a + (c ^ (b | ~d))      + w[j +  4] + 0xf7537e82,  6) + b;
            d = rot(d + (b ^ (a | ~c))      + w[j + 11] + 0xbd3af235, 10) + a;
            c = rot(c + (a ^ (d | ~b))      + w[j +  2] + 0x2ad7d2bb, 15) + d;
            b = rot(b + (d ^ (c | ~a))      + w[j +  9] + 0xeb86d391, 21) + c;

            a = (a + oa) & 0xffffffff;
            b = (b + ob) & 0xffffffff;
            c = (c + oc) & 0xffffffff;
            d = (d + od) & 0xffffffff;
        }

        var out = "";
        for (var k = 0; k < 4; k++) {
            var v = [a, b, c, d][k];
            for (var t = 0; t < 4; t++) {
                var byte = (v >>> (t * 8)) & 0xff;
                out += HEX.charAt((byte >> 4) & 15) + HEX.charAt(byte & 15);
            }
        }
        return out;
    }

    function rot(n, s) {
        return (n << s) | (n >>> (32 - s));
    }

    return { md5: md5, hex_md5: md5 };
})();