load("config.js");

function execute() {
    return Response.success([
        { title: "Mới Cập Nhật",  input: apiInput({find: "", minc: "0", sort: "update", tag: ""}), script: "search.js" },
        { title: "Mới Nhập Kho",  input: apiInput({find: "", minc: "0", sort: "new", tag: ""}), script: "search.js" },
        { title: "Lượt Đọc Tổng", input: apiInput({find: "", minc: "0", sort: "view", tag: ""}), script: "search.js" },
        { title: "Lượt Đọc Tuần", input: apiInput({find: "", minc: "0", sort: "viewweek", tag: ""}), script: "search.js" },
        { title: "Lượt Đọc Ngày", input: apiInput({find: "", minc: "0", sort: "viewday", tag: ""}), script: "search.js" },
        { title: "Lượt Thích",    input: apiInput({find: "", minc: "0", sort: "like", tag: ""}), script: "search.js" },
        { title: "Lượt Theo Dõi", input: apiInput({find: "", minc: "0", sort: "following", tag: ""}), script: "search.js" },
        { title: "Lượt Đánh Dấu", input: apiInput({find: "", minc: "0", sort: "bookmarked", tag: ""}), script: "search.js" },
        { title: "Theo Dõi",     input: "/io/bookfollow/getFollowedBooks?format=html&user=0&filter=", script: "followcontent.js" }
    ]);
}