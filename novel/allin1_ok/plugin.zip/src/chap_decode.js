// chap_decode.js - Content decoding helpers for STV reader
// No dependencies outside config.js and crypto.js

/**
 * Decode STV webfont obfuscated glyphs → normal characters.
 * STV maps PUA unicode codepoints (0xE000-0xFFFF) to Latin glyphs.
 */
function stvDecodeWebfont(raw) {
    var text = (raw === null || typeof raw === "undefined") ? "" : String(raw);
    if (!text) return "";

    var MAP = [
        [0xE05F,"3"],[0xE063,"z"],[0xE06B,"K"],[0xE089,"l"],[0xE0D5,"S"],[0xE0D6,"T"],
        [0xE101,"P"],[0xE184,"O"],[0xE1AD,"e"],[0xE1B4,"k"],[0xE1B8,"f"],[0xE1BF,"n"],
        [0xE1C0,"Y"],[0xE1C1,"1"],[0xE1E4,"M"],[0xE215,"C"],[0xE218,"A"],[0xE248,"v"],
        [0xE257,"G"],[0xE2C5,"s"],[0xE2C7,"t"],[0xE30F,"V"],[0xE311,"u"],[0xE37C,"R"],
        [0xE39B,"X"],[0xE3B0,"l"],[0xE3B7,"B"],[0xE41B,"o"],[0xE41C,"H"],[0xE427,"J"],
        [0xE46A,"b"],[0xE477,"y"],[0xE4AE,"2"],[0xE4D3,"5"],[0xE4DB,"L"],[0xE4DF,"N"],
        [0xE550,"E"],[0xE557,"h"],[0xE571,"F"],[0xE5C9,"8"],[0xE5D1,"x"],[0xE5DC,"m"],
        [0xE5E1,"9"],[0xE5FF,"a"],[0xE603,"U"],[0xE62A,"w"],[0xE63E,"D"],[0xE648,"6"],
        [0xE6A4,"q"],[0xE6A5,"c"],[0xE6D7,"W"],[0xE6F5,"g"],[0xE735,"Z"],[0xE762,"r"],
        [0xE77A,"d"],[0xE77E,"4"],[0xE7C7,"Q"],[0xE7E5,"0"],[0xE7F6,"7"],[0xE95D,"9"],
        [0xE9A8,"y"],[0xE9CC,"P"],[0xE9D5,"o"],[0xE9F8,"O"],[0xEA15,"e"],[0xEA24,"N"],
        [0xEA2E,"R"],[0xEA2F,"C"],[0xEA43,"4"],[0xEA47,"l"],[0xEA75,"M"],[0xEA76,"H"],
        [0xEA77,"u"],[0xEAA1,"k"],[0xEAA4,"a"],[0xEAA5,"x"],[0xEAA6,"z"],[0xEAB4,"t"],
        [0xEAC5,"w"],[0xEAE3,"A"],[0xEB06,"s"],[0xEB0E,"f"],[0xEB75,"h"],[0xEB85,"X"],
        [0xEC6D,"g"],[0xEC75,"d"],[0xEC85,"n"],[0xECB4,"S"],[0xECD4,"L"],[0xECE6,"E"],
        [0xED07,"V"],[0xED35,"l"],[0xED37,"J"],[0xED48,"W"],[0xED64,"5"],[0xED71,"2"],
        [0xED72,"v"],[0xEDEB,"Y"],[0xEDED,"m"],[0xEE09,"Q"],[0xEE69,"b"],[0xEE8D,"0"],
        [0xEEBB,"F"],[0xEECC,"B"],[0xEECF,"c"],[0xEEDA,"1"],[0xEEDB,"D"],[0xEF26,"K"],
        [0xEF37,"6"],[0xEF5A,"U"],[0xEF61,"G"],[0xEF91,"8"],[0xEF94,"T"],[0xEFD7,"Z"],
        [0xEFEE,"3"],[0xF00A,"q"],[0xF073,"7"],[0xF0BA,"r"],[0xF8FF,""]
    ];

    var dict = {};
    for (var i = 0; i < MAP.length; i++) {
        dict[String.fromCharCode(MAP[i][0])] = MAP[i][1];
    }

    var out = "";
    for (var j = 0; j < text.length; j++) {
        var ch = text.charAt(j);
        out += (ch in dict) ? dict[ch] : ch;
    }
    return out;
}

/**
 * Normalize chapter HTML content based on host type.
 * - sangtac/dich: decode webfont obfuscation + handle interlinear
 * - fanqie/ciweimao: handle interlinear <i t=...> format
 * - others: plain text → <br> conversion
 */
function stvCleanChapter(host, raw) {
    var text = String(raw || "");
    var hostKey = String(host || "").toLowerCase();
    if (!text) return "";

    // Decode webfont obfuscation for original content
    text = stvDecodeWebfont(text);

    // Interlinear format: <i t="..." v="...">segment</i>
    if (/<i\b[^>]*\b(?:t|v|p)\s*=\s*['\"][^'\"]*['\"][^>]*>/i.test(text)) {
        text = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
        text = text.replace(/<br\s*\/?\s*>/gi, "\n");
        // Remove line break before punctuation after </i>
        text = text.replace(/<\/i>\s*\n+\s*(?=[,.;:!?%)\]}»\u3002\uff0c\u3001\uff01\uff1f\uff1b\uff1a\u201d\u2019])/gi, "</i>");
        // Extract <i> content, join with space
        text = text.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi, "$1 ");
        // Keep block boundaries
        text = text.replace(/<\/?(p|div|article|section|li|tr|h[1-6]|blockquote)[^>]*>/gi, "\n");
        text = text.replace(/<[^>]+>/g, "");
        // HTML entities
        text = text.replace(/&nbsp;/gi, " ").replace(/&quot;/gi, "\"").replace(/&#39;/gi, "'");
        text = text.replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&amp;/gi, "&");
        // Collapse whitespace
        text = text.replace(/[ \t\f\v]+/g, " ").replace(/ *\n */g, "\n").replace(/\n{3,}/g, "\n\n").trim();
        if (!text) return "";
        return text.replace(/\n/g, "<br>");
    }

    // Already HTML: return as-is
    if (/<\w+[^>]*>/.test(text)) return text;

    // Plain text: escape HTML entities then newline → <br>
    text = text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
    text = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    return text.replace(/\n/g, "<br>");
}