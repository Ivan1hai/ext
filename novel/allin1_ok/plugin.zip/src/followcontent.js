load("config.js");

// Parse "Truyện theo dõi" from getFollowedBooks HTML endpoint.
// HTML shape: <a href="/truyen/{src}/1/{id}/"><div class="row nowr">
//   <div class="bkl"><img src=... class="im"></div>
//   <div class="bkr"><b>Tên</b><br>Tác giả<br>Số chương: N<br>Cập nhật: <span>...</span><br><button>...</button></div>
// </div></a>
function parseFollowedBooks(doc) {
    var list = [];
    if (!doc) return list;

    var cards = doc.select("a[href*='/truyen/']");
    var seen = {};
    for (var i = 0; i < getSize(cards); i++) {
        var a = getElement(cards, i);
        if (!a) continue;

        var href = a.attr("href") || "";
        if (!href || href === "/truyen/") continue;
        // must contain the row wrapper (avoid unrelated anchors)
        var row = a.select("div.row").first();
        if (!row) continue;

        href = normalizeUrl(href);
        if (seen[href]) continue;
        seen[href] = true;

        var name = "";
        var bEl = a.select("b").first();
        if (bEl) name = cleanText(bEl.text());
        if (!name || name.length < 1) continue;

        var imgEl = a.select("img").first();
        var cover = "";
        if (imgEl) {
            cover = imgEl.attr("src") || imgEl.attr("data-src") || "";
            if (cover && cover.indexOf("http") !== 0) cover = normalizeUrl(cover);
        }

        // description = author + số chương + cập nhật (from bkr text)
        var bkr = a.select("div.bkr").first();
        var description = "";
        if (bkr) {
            // remove <button> unfollow noise from text
            bkr.select("button").remove();
            var span = bkr.select("span.timeelap").first();
            var updated = span ? cleanText(span.text()) : "";
            // bkr text now: "Tên\n Tác giả\n Số chương: N\n Cập nhật: ...\n "
            var raw = cleanText(bkr.text());
            // strip leading name (already in b)
            if (raw.indexOf(name) === 0) raw = raw.substring(name.length).trim();
            // build short desc
            description = raw;
            if (updated && description.indexOf(updated) < 0) description = (description + " " + updated).trim();
            if (description.length > 200) description = description.substring(0, 200);
        }

        list.push({
            name: name,
            link: href,
            cover: cover,
            description: description,
            host: BASE_URL
        });
    }

    return list;
}

function execute(url, page) {
    // url is the getFollowedBooks endpoint (already full or path)
    var fullUrl = url;
    if (fullUrl.indexOf("http") !== 0) {
        fullUrl = BASE_URL + (fullUrl.indexOf("/") === 0 ? "" : "/") + fullUrl;
    }

    var doc = fetchApi(fullUrl);
    if (!doc) return Response.error("Không tải được danh sách truyện theo dõi. Có thể bạn chưa đăng nhập.");

    var list = parseFollowedBooks(doc);
    if (list.length === 0) {
        return Response.error("Không có truyện đang theo dõi hoặc user=0");
    }
    // No pagination in getFollowedBooks response → stop
    return Response.success(list, null);
}