load("config.js");

// Parse /io/comment/webComments HTML response.
// Each root comment:
//   <div class="flex">
//     <img class="comment-avatar"/>
//     <div class="sec">
//       <div class="sec-top bg-gray">CONTENT</div>
//       <div class="sec-bot">
//         <div cmtid="X"><a href="/user/ID/">USERNAME</a> -
//           <span class="t-12 t-gray">RANK</span> -
//           <span class="timeelap t-12 t-gray">DATE</span> -
//           <span onclick="reply...">Trả lời</span>
//         </div>
//       </div>
//     </div>
//   </div>
// Reply: same shape with <img style="margin-left:50px"/>; nested directly inside root's <div class="sec">.
function parseComments(doc) {
    var list = [];
    if (!doc) return list;

    var flexes = doc.select("div.flex");
    for (var i = 0; i < getSize(flexes); i++) {
        var flex = getElement(flexes, i);
        if (!flex) continue;

        var img = flex.select("img.comment-avatar").first();
        var isReply = false;
        if (img) {
            var style = img.attr("style") || "";
            if (style.indexOf("margin-left:50px") >= 0 || style.indexOf("margin-left: 50px") >= 0) isReply = true;
        }

        // CONTENT
        var contentEl = flex.select("div.sec-top.bg-gray").first();
        var content = contentEl ? cleanText(contentEl.text()) : "";
        if (!content) continue;

        // USERNAME + RANK + DATE from sec-bot
        var secBot = flex.select("div.sec-bot").first();
        var username = "";
        var rank = "";
        var date = "";
        if (secBot) {
            var aEl = secBot.select("a").first();
            if (aEl) username = cleanText(aEl.text());
            var spans = secBot.select("span");
            // expected order: t-gray (rank), timeelap (date)
            for (var j = 0; j < getSize(spans); j++) {
                var sp = getElement(spans, j);
                if (!sp) continue;
                var cls = sp.attr("class") || "";
                if (cls.indexOf("timeelap") >= 0) date = cleanText(sp.text());
                else if (cls.indexOf("t-gray") >= 0 && !rank) rank = cleanText(sp.text());
            }
        }

        // desc: rank + date
        var descParts = [];
        if (rank) descParts.push(rank);
        if (date) descParts.push(date);

        list.push({
            name: (username || "Ẩn danh") + (isReply ? " ↳" : ""),
            content: content,
            description: descParts.join(" · ")
        });
    }

    return list;
}

// Extract source + bookId from truyen URL: /truyen/<source>/1/<bookId>/
function parseStoryKey(input) {
    var raw = String(input || "").trim();
    if (!raw) return null;
    var m = raw.match(/\/truyen\/([^/]+)\/1\/([^/]+)/);
    if (!m) return null;
    return { source: m[1], bookId: m[2] };
}

function execute(input, page) {
    var key = parseStoryKey(input);
    if (!key) return Response.error("Không xác định được truyện");

    var currentPage = parseInt(page, 10);
    if (isNaN(currentPage) || currentPage < 0) currentPage = 0;

    var url = BASE_URL + "/io/comment/webComments";
    var body = "start=" + currentPage + "&objectid=" + encodeURIComponent(key.bookId) + "&objecttype=" + encodeURIComponent(key.source);

    var response = fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": BASE_UA,
            "Referer": BASE_URL + "/truyen/" + key.source + "/1/" + key.bookId + "/"
        },
        body: body
    });

    if (!response || !response.ok) return Response.error("Không tải được bình luận");

    var html = response.text();
    if (!html) return Response.error("Phản hồi rỗng");

    var doc = Html.parse(html);
    var list = parseComments(doc);

    if (list.length === 0) {
        return Response.success([], null);
    }

    // Per-page ~17 comments; if returned < 5 we're at the end
    var next = list.length >= 5 ? String(currentPage + 1) : null;
    return Response.success(list, next);
}