load("config.js");

function execute(key, page) {
    var params = parseApiInput(key);
    var pageIndex = parseInt(page || "0", 10);

    var path = buildApiPath(params);
    if (pageIndex > 0) {
        path += "&p=" + pageIndex;
    }

    var doc = fetchApi(path);
    if (!doc) return Response.error("Không thể tải kết quả");

    var list = parseApiList(doc);
    if (list.length === 0) return Response.error("Không tìm thấy truyện");

    // 48 cards per page → has next if full
    var next = list.length >= 48 ? String(pageIndex + 1) : "";
    return Response.success(list, next);
}