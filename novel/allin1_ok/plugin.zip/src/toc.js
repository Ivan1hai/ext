load("config.js");

function execute(url) {
    url = normalizeUrl(url);

    // Extract source + bookId from URL
    // URL format: /truyen/<source>/1/<bookId>/  or  /truyen/<source>/1/<bookId>/<chapId>/
    var urlMatch = url.match(/\/truyen\/([^\/]+)\/1\/([^\/]+)/);
    if (!urlMatch) {
        // Fallback: fetch detail page and extract from page
        var doc = fetchDoc(url, 12000);
        if (!doc) return Response.success([]);

        // Find source from URL path
        var sourceMatch = url.match(/\/truyen\/([^\/]+)\//);
        var source = sourceMatch ? sourceMatch[1] : "qidian";

        // Find bookId from page (bookid='...' or data-bookid)
        var pageHtml = doc.html ? doc.html() : (doc.outerHtml ? doc.outerHtml() : "");
        var pageMatch = pageHtml.match(/bookid['\"]?\s*[:=]\s*['\"]?(\d+)/i);
        var bookId = pageMatch ? pageMatch[1] : "";

        if (!bookId) return Response.success([]);
        return fetchChapters(source, bookId);
    }

    var source = urlMatch[1];
    var bookId = urlMatch[2];
    return fetchChapters(source, bookId);
}

/**
 * Fetch chapter list from STV API.
 * API: GET /index.php?ngmar=chapterlist&h=<source>&bookid=<bookId>&sajax=getchapterlist
 * Response: plain text, rows separated by -//-, fields by -/-.
 * Fallback: parse #chap a elements from detail page.
 */
function fetchChapters(source, bookId) {
    var detailUrl = BASE_URL + "/truyen/" + source + "/1/" + bookId + "/";
    var apiUrl = BASE_URL + "/index.php?ngmar=chapterlist&h=" + encodeURIComponent(source)
        + "&bookid=" + encodeURIComponent(bookId) + "&sajax=getchapterlist";

    var jsonText = fetchText(apiUrl, detailUrl);
    if (jsonText && jsonText.length > 10) {
        var chapters = parseChapterListJson(jsonText, bookId, source);
        if (chapters.length > 0) return Response.success(chapters);
    }

    // Fallback: parse chapter links from detail page HTML
    var doc = fetchDoc(detailUrl, 12000);
    if (!doc) return Response.success([]);

    var chapLinks = doc.select("#chap a[href*='/truyen/']");
    if (chapLinks.size() === 0) chapLinks = doc.select("a[href*='/truyen/']");

    var chapters = [];
    var seen = {};
    for (var i = 0; i < getSize(chapLinks); i++) {
        var link = getElement(chapLinks, i);
        if (!link) continue;
        var name = cleanText(link.text());
        var href = link.attr("href") || "";
        if (!name || !href) continue;
        if (href.indexOf("/truyen/" + source + "/1/" + bookId + "/") < 0) continue;
        href = normalizeUrl(href);
        if (seen[href]) continue;
        seen[href] = true;
        chapters.push({ name: name, url: href, host: BASE_URL });
    }

    return Response.success(chapters);
}