load("config.js");

function execute(url) {
    url = normalizeUrl(url);

    var doc = fetchDoc(url, 15000);
    if (!doc) return Response.error("Không thể tải trang");

    var pageHtml = doc.html ? doc.html() : "";

    // Title: #book_name2 (preferred) → og:title → h1 → meta title
    var titleEl = doc.select("#book_name2").first();
    var name = titleEl ? cleanText(titleEl.text()) : "";
    if (!name) {
        var ogTitle = doc.select("meta[property='og:title']").first();
        if (ogTitle) name = cleanText(ogTitle.attr("content") || "");
    }
    if (!name) {
        var h1 = doc.select("h1").first();
        if (h1) name = cleanText(h1.text());
    }
    if (!name && pageHtml) {
        var titleMatch = pageHtml.match(/<title>([^<]+)<\/title>/i);
        if (titleMatch) name = cleanText(titleMatch[1].replace(/\s*-\s*\d+\s*chương\s*$/i, ""));
    }

    // Cover: og:image (preferred) → first external img
    var cover = "";
    var ogImage = doc.select("meta[property='og:image']").first();
    if (ogImage) cover = ogImage.attr("content") || "";
    if (!cover) {
        var imgs = doc.select("img");
        for (var j = 0; j < getSize(imgs); j++) {
            var img = getElement(imgs, j);
            if (!img) continue;
            var src = img.attr("src") || "";
            if (!src) continue;
            if (src.indexOf("/favicon") >= 0 || src.indexOf("/useravatar") >= 0 || src.indexOf("dmca.com") >= 0) continue;
            if (src.indexOf("http") === 0) {
                cover = src;
                break;
            }
        }
    }

    // Description: #book-sumary → og:description
    var descEl = doc.select("#book-sumary").first();
    var description = descEl ? cleanText(descEl.text()) : "";
    if (!description) {
        var ogDesc = doc.select("meta[property='og:description']").first();
        if (ogDesc) description = cleanText(ogDesc.attr("content") || "");
    }

    // Author: from page text (Tác giả: X) → meta og:novel:author
    var bodyText = doc.text() || "";
    var authorMatch = bodyText.match(/Tác giả\s*[:：]\s*([^\n]{2,40})/i);
    var author = authorMatch ? cleanText(authorMatch[1].replace(/^[:：]\s*/, "").replace(/&nbsp;/g, " ")) : "";
    if (!author) {
        var ogAuthor = doc.select("meta[property='og:novel:author']").first();
        if (ogAuthor) author = cleanText(ogAuthor.attr("content") || "");
    }

    // Original name: #oriname
    var oriName = "";
    var oriEl = doc.select("#oriname").first();
    if (oriEl) {
        var oriSpan = oriEl.select("span").first();
        oriName = oriSpan ? cleanText(oriSpan.text()) : cleanText(oriEl.text());
    }

    // Status: #bookstatus text → og:novel:status meta
    var ongoing = true;
    var statusEl = doc.select("#bookstatus").first();
    if (statusEl) {
        var st = cleanText(statusEl.text()).toLowerCase();
        if (st.indexOf("hoàn") >= 0 || st.indexOf("đã hoàn") >= 0) ongoing = false;
    }
    if (statusEl.size && statusEl.size() === 0) {
        var ogStatus = doc.select("meta[property='og:novel:status']").first();
        if (ogStatus) {
            var st2 = cleanText(ogStatus.attr("content") || "").toLowerCase();
            if (st2.indexOf("hoàn") >= 0 || st2.indexOf("full") >= 0) ongoing = false;
        }
    }

    // Extract source + bookId from URL: /truyen/<source>/1/<bookId>/
    var urlMatch = url.match(/\/truyen\/([^\/]+)\/1\/([^\/]+)/);
    var source = urlMatch ? urlMatch[1] : "";
    var bookId = urlMatch ? urlMatch[2] : "";

    var detail = "";
    if (oriName) detail += "Tên gốc: " + oriName + "<br>";
    if (author) detail += "Tác giả: " + author + "<br>";
    detail += "Trạng thái: " + (ongoing ? "Đang ra" : "Hoàn thành");

    if (!name) name = "Unknown";

    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: description,
        detail: detail,
        host: BASE_URL,
        ongoing: ongoing,
        source: source,
        bookId: bookId,
        comments: [
            { title: "Bình luận", input: url, script: "comment.js" }
        ]
    });
}