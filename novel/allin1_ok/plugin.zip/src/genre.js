load("config.js");

function execute() {
    var items = [];
    items.push({ title: "Đô Thị", input: apiInput({find: "", minc: "0", tag: "dothi,"}), script: "search.js" });
    items.push({ title: "Xuyên Qua", input: apiInput({find: "", minc: "0", tag: "xuyenqua,"}), script: "search.js" });
    items.push({ title: "Bản Gốc", input: apiInput({find: "", minc: "0", tag: "bangoc,"}), script: "search.js" });
    items.push({ title: "Huyền Huyễn Kỳ Huyễn", input: apiInput({find: "", minc: "0", tag: "huyenhuyenkyhuyen,"}), script: "search.js" });
    items.push({ title: "Hệ Thống", input: apiInput({find: "", minc: "0", tag: "hethong,"}), script: "search.js" });
    items.push({ title: "Huyền Huyễn", input: apiInput({find: "", minc: "0", tag: "huyenhuyen,"}), script: "search.js" });
    items.push({ title: "Ngôn Tình", input: apiInput({find: "", minc: "0", tag: "ngontinh,"}), script: "search.js" });
    items.push({ title: "Tình Yêu", input: apiInput({find: "", minc: "0", tag: "tinhyeu,"}), script: "search.js" });
    items.push({ title: "Đô Thị Ngôn Tình", input: apiInput({find: "", minc: "0", tag: "dothingontinh,"}), script: "search.js" });
    items.push({ title: "Hiện Đại Ngôn Tình", input: apiInput({find: "", minc: "0", tag: "hiendaingontinh,"}), script: "search.js" });
    items.push({ title: "Nữ Chính", input: apiInput({find: "", minc: "0", tag: "nuchinh,"}), script: "search.js" });
    items.push({ title: "Đồng Nhân", input: apiInput({find: "", minc: "0", tag: "dongnhan,"}), script: "search.js" });
    items.push({ title: "Cận Đại Hiện Đại", input: apiInput({find: "", minc: "0", tag: "candaihiendai,"}), script: "search.js" });
    items.push({ title: "Cổ Đại Ngôn Tình", input: apiInput({find: "", minc: "0", tag: "codaingontinh,"}), script: "search.js" });
    items.push({ title: "Lịch Sử Vô Căn Cứ", input: apiInput({find: "", minc: "0", tag: "lichsuvocancu,"}), script: "search.js" });
    items.push({ title: "Trùng Sinh", input: apiInput({find: "", minc: "0", tag: "trungsinh,"}), script: "search.js" });
    items.push({ title: "Thuần Ái", input: apiInput({find: "", minc: "0", tag: "thuanai,"}), script: "search.js" });
    items.push({ title: "Nhẹ Nhõm", input: apiInput({find: "", minc: "0", tag: "nhenhom,"}), script: "search.js" });
    items.push({ title: "Lịch Sử", input: apiInput({find: "", minc: "0", tag: "lichsu,"}), script: "search.js" });
    items.push({ title: "Khoa Huyễn", input: apiInput({find: "", minc: "0", tag: "khoahuyen,"}), script: "search.js" });
    items.push({ title: "Tình Cảm", input: apiInput({find: "", minc: "0", tag: "tinhcam,"}), script: "search.js" });
    items.push({ title: "Võ Hiệp Tiên Hiệp", input: apiInput({find: "", minc: "0", tag: "vohieptienhiep,"}), script: "search.js" });
    items.push({ title: "Light Novel", input: apiInput({find: "", minc: "0", tag: "lightnovel,"}), script: "search.js" });
    items.push({ title: "Đô Thị Não Động", input: apiInput({find: "", minc: "0", tag: "dothinaodong,"}), script: "search.js" });
    items.push({ title: "Đông Phương Huyền Huyễn", input: apiInput({find: "", minc: "0", tag: "dongphuonghuyenhuyen,"}), script: "search.js" });
    items.push({ title: "Ngắn Cố Sự", input: apiInput({find: "", minc: "0", tag: "ngancosu,"}), script: "search.js" });
    items.push({ title: "Tiên Hiệp", input: apiInput({find: "", minc: "0", tag: "tienhiep,"}), script: "search.js" });
    items.push({ title: "Sảng Văn", input: apiInput({find: "", minc: "0", tag: "sangvan,"}), script: "search.js" });
    items.push({ title: "Linh Dị", input: apiInput({find: "", minc: "0", tag: "linhdi,"}), script: "search.js" });
    items.push({ title: "Võ Hiệp", input: apiInput({find: "", minc: "0", tag: "vohiep,"}), script: "search.js" });
    items.push({ title: "Huyền Nghi", input: apiInput({find: "", minc: "0", tag: "huyennghi,"}), script: "search.js" });
    items.push({ title: "Trò Chơi", input: apiInput({find: "", minc: "0", tag: "trochoi,"}), script: "search.js" });
    return Response.success(items);
}