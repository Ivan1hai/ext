// chap.js - STV reader chapter loader
// MD5 + webfont decode + grantcontext flow + readchapter sign

var MD5 = (function () {
    var HEX = "0123456789abcdef";
    function md5(text) {
        var s = String(text || "");
        var len = s.length;
        var w = new Array((((len + 8) >> 6) + 1) * 16);
        for (var i = 0; i < w.length; i++) w[i] = 0;
        for (i = 0; i < len; i++) w[i >> 2] |= s.charCodeAt(i) << ((i & 3) << 3);
        w[i >> 2] |= 0x80 << ((i & 3) << 3);
        w[w.length - 2] = len << 3;
        var a = 1732584193, b = -271733879, c = -1732584194, d = 271733878;
        for (var j = 0; j < w.length; j += 16) {
            var oa = a, ob = b, oc = c, od = d;
            a = rot(a + ((b & c) | (~b & d)) + w[j]      + 0xd76aa478,  7) + b;
            d = rot(d + ((a & b) | (~a & c)) + w[j +  1] + 0xe8c7b756, 12) + a;
            c = rot(c + ((d & a) | (~d & b)) + w[j +  2] + 0x242070db, 17) + d;
            b = rot(b + ((c & d) | (~c & a)) + w[j +  3] + 0xc1bdceee, 22) + c;
            a = rot(a + ((b & c) | (~b & d)) + w[j +  4] + 0xf57c0faf,  7) + b;
            d = rot(d + ((a & b) | (~a & c)) + w[j +  5] + 0x4787c62a, 12) + a;
            c = rot(c + ((d & a) | (~d & b)) + w[j +  6] + 0xa8304613, 17) + d;
            b = rot(b + ((c & d) | (~c & a)) + w[j +  7] + 0xfd469501, 22) + c;
            a = rot(a + ((b & c) | (~b & d)) + w[j +  8] + 0x698098d8,  7) + b;
            d = rot(d + ((a & b) | (~a & c)) + w[j +  9] + 0x8b44f7af, 12) + a;
            c = rot(c + ((d & a) | (~d & b)) + w[j + 10] + 0xffff5bb1, 17) + d;
            b = rot(b + ((c & d) | (~c & a)) + w[j + 11] + 0x895cd7be, 22) + c;
            a = rot(a + ((b & c) | (~b & d)) + w[j + 12] + 0x6b901122,  7) + b;
            d = rot(d + ((a & b) | (~a & c)) + w[j + 13] + 0xfd987193, 12) + a;
            c = rot(c + ((d & a) | (~d & b)) + w[j + 14] + 0xa679438e, 17) + d;
            b = rot(b + ((c & d) | (~c & a)) + w[j + 15] + 0x49b40821, 22) + c;
            a = rot(a + ((b & d) | (c & ~d)) + w[j +  1] + 0xf61e2562,  5) + b;
            d = rot(d + ((a & c) | (b & ~c)) + w[j +  6] + 0xc040b340,  9) + a;
            c = rot(c + ((d & b) | (a & ~b)) + w[j + 11] + 0x265e5a51, 14) + d;
            b = rot(b + ((c & a) | (d & ~a)) + w[j     ] + 0xe9b6c7aa, 20) + c;
            a = rot(a + ((b & d) | (c & ~d)) + w[j +  5] + 0xd62f105d,  5) + b;
            d = rot(d + ((a & c) | (b & ~c)) + w[j + 10] + 0x02441453,  9) + a;
            c = rot(c + ((d & b) | (a & ~b)) + w[j + 15] + 0xd8a1e681, 14) + d;
            b = rot(b + ((c & a) | (d & ~a)) + w[j +  4] + 0xe7d3fbc8, 20) + c;
            a = rot(a + ((b & d) | (c & ~d)) + w[j +  9] + 0x21e1cde6,  5) + b;
            d = rot(d + ((a & c) | (b & ~c)) + w[j + 14] + 0xc33707d6,  9) + a;
            c = rot(c + ((d & b) | (a & ~b)) + w[j +  3] + 0xf4d50d87, 14) + d;
            b = rot(b + ((c & a) | (d & ~a)) + w[j +  8] + 0x455a14ed, 20) + c;
            a = rot(a + ((b & d) | (c & ~d)) + w[j + 13] + 0xa9e3e905,  5) + b;
            d = rot(d + ((a & c) | (b & ~c)) + w[j +  2] + 0xfcefa3f8,  9) + a;
            c = rot(c + ((d & b) | (a & ~b)) + w[j +  7] + 0x676f02d9, 14) + d;
            b = rot(b + ((c & a) | (d & ~a)) + w[j + 12] + 0x8d2a4c8a, 20) + c;
            a = rot(a + (b ^ c ^ d)        + w[j +  5] + 0xfffa3942,  4) + b;
            d = rot(d + (a ^ b ^ c)        + w[j +  8] + 0x8771f681, 11) + a;
            c = rot(c + (d ^ a ^ b)        + w[j + 11] + 0x6d9d6122, 16) + d;
            b = rot(b + (c ^ d ^ a)        + w[j + 14] + 0xfde5380c, 23) + c;
            a = rot(a + (b ^ c ^ d)        + w[j +  1] + 0xa4beea44,  4) + b;
            d = rot(d + (a ^ b ^ c)        + w[j +  4] + 0x4bdecfa9, 11) + a;
            c = rot(c + (d ^ a ^ b)        + w[j +  7] + 0xf6bb4b60, 16) + d;
            b = rot(b + (c ^ d ^ a)        + w[j + 10] + 0xbebfbc70, 23) + c;
            a = rot(a + (b ^ c ^ d)        + w[j + 13] + 0x289b7ec6,  4) + b;
            d = rot(d + (a ^ b ^ c)        + w[j     ] + 0xeaa127fa, 11) + a;
            c = rot(c + (d ^ a ^ b)        + w[j +  3] + 0xd4ef3085, 16) + d;
            b = rot(b + (c ^ d ^ a)        + w[j +  6] + 0x04881d05, 23) + c;
            a = rot(a + (b ^ c ^ d)        + w[j +  9] + 0xd9d4d039,  4) + b;
            d = rot(d + (a ^ b ^ c)        + w[j + 12] + 0xe6db99e5, 11) + a;
            c = rot(c + (d ^ a ^ b)        + w[j + 15] + 0x1fa27cf8, 16) + d;
            b = rot(b + (c ^ d ^ a)        + w[j +  2] + 0xc4ac5665, 23) + c;
            a = rot(a + (c ^ (b | ~d))      + w[j     ] + 0xf4292244,  6) + b;
            d = rot(d + (b ^ (a | ~c))      + w[j +  7] + 0x432aff97, 10) + a;
            c = rot(c + (a ^ (d | ~b))      + w[j + 14] + 0xab9423a7, 15) + d;
            b = rot(b + (d ^ (c | ~a))      + w[j +  5] + 0xfc93a039, 21) + c;
            a = rot(a + (c ^ (b | ~d))      + w[j + 12] + 0x655b59c3,  6) + b;
            d = rot(d + (b ^ (a | ~c))      + w[j +  3] + 0x8f0ccc92, 10) + a;
            c = rot(c + (a ^ (d | ~b))      + w[j + 10] + 0xffeff47d, 15) + d;
            b = rot(b + (d ^ (c | ~a))      + w[j +  1] + 0x85845dd1, 21) + c;
            a = rot(a + (c ^ (b | ~d))      + w[j +  8] + 0x6fa87e4f,  6) + b;
            d = rot(d + (b ^ (a | ~c))      + w[j + 15] + 0xfe2ce6e0, 10) + a;
            c = rot(c + (a ^ (d | ~b))      + w[j +  6] + 0xa3014314, 15) + d;
            b = rot(b + (d ^ (c | ~a))      + w[j + 13] + 0x4e0811a1, 21) + c;
            a = rot(a + (c ^ (b | ~d))      + w[j +  4] + 0xf7537e82,  6) + b;
            d = rot(d + (b ^ (a | ~c))      + w[j + 11] + 0xbd3af235, 10) + a;
            c = rot(c + (a ^ (d | ~b))      + w[j +  2] + 0x2ad7d2bb, 15) + d;
            b = rot(b + (d ^ (c | ~a))      + w[j +  9] + 0xeb86d391, 21) + c;
            a = (a + oa) & 0xffffffff; b = (b + ob) & 0xffffffff; c = (c + oc) & 0xffffffff; d = (d + od) & 0xffffffff;
        }
        var out = "";
        for (var k = 0; k < 4; k++) {
            var v = [a, b, c, d][k];
            for (var t = 0; t < 4; t++) {
                var byte = (v >>> (t * 8)) & 0xff;
                out += HEX.charAt((byte >> 4) & 15) + HEX.charAt(byte & 15);
            }
        }
        return out;
    }
    function rot(n, s) { return (n << s) | (n >>> (32 - s)); }
    return { md5: md5, hex_md5: md5 };
})();

// ---- STV webfont → ASCII ----
function stvDecodeWebfont(raw) {
    var text = (raw === null || typeof raw === "undefined") ? "" : String(raw);
    if (!text) return "";
    var pairs = [
        [0xE05F,"3"],[0xE063,"z"],[0xE06B,"K"],[0xE089,"l"],[0xE0D5,"S"],[0xE0D6,"T"],
        [0xE101,"P"],[0xE184,"O"],[0xE1AD,"e"],[0xE1B4,"k"],[0xE1B8,"f"],[0xE1BF,"n"],
        [0xE1C0,"Y"],[0xE1C1,"1"],[0xE1E4,"M"],[0xE215,"C"],[0xE218,"A"],[0xE248,"v"],
        [0xE257,"G"],[0xE2C5,"s"],[0xE2C7,"t"],[0xE30F,"V"],[0xE311,"u"],[0xE37C,"R"],
        [0xE39B,"X"],[0xE3B0,"l"],[0xE3B7,"B"],[0xE41B,"o"],[0xE41C,"H"],[0xE427,"J"],
        [0xE46A,"b"],[0xE477,"y"],[0xE4AE,"2"],[0xE4D3,"5"],[0xE4DB,"L"],[0xE4DF,"N"],
        [0xE550,"E"],[0xE557,"h"],[0xE571,"F"],[0xE5C9,"8"],[0xE5D1,"x"],[0xE5DC,"m"],
        [0xE5E1,"9"],[0xE5FF,"a"],[0xE603,"U"],[0xE62A,"w"],[0xE63E,"D"],[0xE648,"6"],
        [0xE6A4,"q"],[0xE6A5,"c"],[0xE6D7,"W"],[0xE6F5,"g"],[0xE735,"Z"],[0xE762,"r"],
        [0xE77A,"d"],[0xE77E,"4"],[0xE7C7,"Q"],[0xE7E5,"0"],[0xE7F6,"7"],[0xE95D,"9"],
        [0xE9A8,"y"],[0xE9CC,"P"],[0xE9D5,"o"],[0xE9F8,"O"],[0xEA15,"e"],[0xEA24,"N"],
        [0xEA2E,"R"],[0xEA2F,"C"],[0xEA43,"4"],[0xEA47,"l"],[0xEA75,"M"],[0xEA76,"H"],
        [0xEA77,"u"],[0xEAA1,"k"],[0xEAA4,"a"],[0xEAA5,"x"],[0xEAA6,"z"],[0xEAB4,"t"],
        [0xEAC5,"w"],[0xEAE3,"A"],[0xEB06,"s"],[0xEB0E,"f"],[0xEB75,"h"],[0xEB85,"X"],
        [0xEC6D,"g"],[0xEC75,"d"],[0xEC85,"n"],[0xECB4,"S"],[0xECD4,"L"],[0xECE6,"E"],
        [0xED07,"V"],[0xED35,"l"],[0xED37,"J"],[0xED48,"W"],[0xED64,"5"],[0xED71,"2"],
        [0xED72,"v"],[0xEDEB,"Y"],[0xEDED,"m"],[0xEE09,"Q"],[0xEE69,"b"],[0xEE8D,"0"],
        [0xEEBB,"F"],[0xEECC,"B"],[0xEECF,"c"],[0xEEDA,"1"],[0xEEDB,"D"],[0xEF26,"K"],
        [0xEF37,"6"],[0xEF5A,"U"],[0xEF61,"G"],[0xEF91,"8"],[0xEF94,"T"],[0xEFD7,"Z"],
        [0xEFEE,"3"],[0xF00A,"q"],[0xF073,"7"],[0xF0BA,"r"],[0xF8FF,""]
    ];
    var dict = {};
    for (var i = 0; i < pairs.length; i++) dict[String.fromCharCode(pairs[i][0])] = pairs[i][1];
    var out = "";
    for (var j = 0; j < text.length; j++) {
        var ch = text.charAt(j);
        out += (ch in dict) ? dict[ch] : ch;
    }
    return out;
}

// ---- Chapter normalizer ----
function stvCleanChapter(raw) {
    var text = String(raw || "");
    if (!text) return "";
    text = stvDecodeWebfont(text);

    if (/<i\b[^>]*\b(?:t|v|p)\s*=\s*['"][^'"]*['"][^>]*>/i.test(text)) {
        text = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
        text = text.replace(/<br\s*\/?\s*>/gi, "\n");
        text = text.replace(/<\/i>\s*\n+\s*(?=[,.;:!?%)\]}»\u3002\uff0c\u3001\uff01\uff1f\uff1b\uff1a\u201d\u2019])/gi, "</i>");
        text = text.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi, "$1 ");
        text = text.replace(/<\/?(p|div|article|section|li|tr|h[1-6]|blockquote)[^>]*>/gi, "\n");
        text = text.replace(/<[^>]+>/g, "");
        text = text.replace(/&nbsp;/gi, " ").replace(/&quot;/gi, String.fromCharCode(34)).replace(/&#39;/gi, String.fromCharCode(39));
        text = text.replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&amp;/gi, "&");
        text = text.replace(/[ \t\f\v]+/g, " ").replace(/ *\n */g, "\n").replace(/\n{3,}/g, "\n\n").trim();
        if (!text) return "";
        return text.replace(/\n/g, "<br>");
    }

    if (/<\w+[^>]*>/.test(text)) return text;

    text = text.replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">");
    text = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    return text.replace(/\n/g, "<br>");
}

// ---- Constants ----
var STV_BASE = "http://14.225.254.182";
var STV_BASES = [STV_BASE];
var STV_SIGN_SALT = "erogh982^%*%^*";
var STV_UA = "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Mobile Safari/537.36";
var STV_APP_HEADERS = {
    "x-stv-transport": "app",
    "x-requested-with": "com.sangtacviet.mobilereader"
};
var _stvGrantCache = {};

// ---- Phase 1: fetch Grantcontext ----
function stvFetchGrant(base, host, bookId) {
    var url = base + "/io/grantcontext/context?hostid="
        + encodeURIComponent(host) + "&bookid=" + encodeURIComponent(bookId);
    var headers = {
        "User-Agent": STV_UA,
        "Accept": "*/*",
        "Referer": base + "/truyen/" + host + "/1/" + bookId + "/",
        "Cookie": "mac_tt=true"
    };
    for (var k in STV_APP_HEADERS) {
        if (STV_APP_HEADERS.hasOwnProperty(k)) headers[k] = STV_APP_HEADERS[k];
    }
    var resp = fetch(url, { method: "GET", headers: headers });
    if (!resp || !resp.ok) return { ok: false, text: "", setCookie: "" };
    var text = "";
    try { text = resp.text(); } catch (e) {}
    if (!text || text.indexOf("chapterkey") < 0) {
        try {
            var html = resp.html();
            if (html) {
                text = String(html).replace(/^[\s\S]*?<body[^>]*>/i, "").replace(/<\/body>[\s\S]*$/i, "");
                text = text.replace(/&quot;/g, String.fromCharCode(34)).replace(/&#39;/g, String.fromCharCode(39))
                    .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
            }
        } catch (e) {}
    }
    var setCookie = "";
    try {
        if (resp.headers) {
            setCookie = resp.headers["Set-Cookie"] || resp.headers["set-cookie"] || "";
        }
    } catch (e) {}
    return { ok: true, text: text, setCookie: setCookie };
}

// ---- Phase 1b: Extract chapterkey via Engine.newBrowser ----
function stvExtractKey(browser, grantCode, readcontextid) {
    if (!browser || typeof browser.callJs !== "function") {
        return { chapterkey: "", readcontextid: readcontextid, error: "callJs khong kha dung" };
    }
    var keyVar = "stv_key_" + Math.random().toString(36).substring(2);
    var errVar = "stv_err_" + Math.random().toString(36).substring(2);
    var rcidVar = "stv_rcid_" + Math.random().toString(36).substring(2);
    var rcidSnippet = readcontextid
        ? "try{document.cookie=" + JSON.stringify("readcontextid=" + readcontextid + "; path=/") + ";}catch(_){}"
        : "";
    var script = "window.window=window;window.globalThis=window;window.Capacitor=window.Capacitor||{};window.UWNgB=true;";
    script += "window.document=window.document||{};window.document.hidden=false;";
    script += "window.navigator=window.navigator||{};";
    script += "window.localStorage=window.localStorage||{getItem:function(){return null;},setItem:function(){},removeItem:function(){}};";
    script += "window.sessionStorage=window.sessionStorage||{getItem:function(){return null;},setItem:function(){},removeItem:function(){}};";
    script += "window.app=window.app||{};window.app.tcYCI=true;window.app.reader=window.app.reader||{};";
    script += "try{document.cookie=" + JSON.stringify("mac_tt=true; path=/") + ";}catch(_){}";
    script += rcidSnippet;
    script += "var __w=function(n,v){try{if(typeof Cache!=='undefined'&&Cache&&Cache.putVariable){Cache.putVariable(n,String(v||''));}}catch(e){};};";
    script += "var __grantCode=" + JSON.stringify(grantCode || "") + ";";
    script += "var __err='';";
    script += "try{if(!document.getElementById('stv_ck_out')){var d=document.createElement('div');d.innerHTML='<pre id=' + String.fromCharCode(34) + 'stv_ck_out' + String.fromCharCode(34) + '></pre><pre id=' + String.fromCharCode(34) + 'stv_ck_err' + String.fromCharCode(34) + '></pre><pre id=' + String.fromCharCode(34) + 'stv_ck_rcid' + String.fromCharCode(34) + '></pre>';if(document.body)document.body.appendChild(d);}}catch(_){}";
    script += "try{eval(__grantCode);}catch(e){__err=String(e&&e.message?e.message:e);}";
    script += "var __ck='';try{__ck=String((window.app&&window.app.reader&&window.app.reader.chapterkey)||'');}catch(e){__err+='|rd:'+String(e&&e.message?e.message:e);}";
    script += "var __rc='';try{var __m=String(document.cookie||'').match(/(?:^|;\\s*)readcontextid=([^;]+)/i);__rc=__m&&__m[1]?__m[1]:'';}catch(e){__rc='';}";
    script += "try{document.getElementById('stv_ck_out').innerText=(__ck?('__KEY__:'+__ck):('__ERR__:'+__err));}catch(_){}";
    script += "try{document.getElementById('stv_ck_err').innerText=String(__err||'');}catch(_){}";
    script += "try{document.getElementById('stv_ck_rcid').innerText=String(__rc||'');}catch(_){}";
    script += "__w(" + JSON.stringify(keyVar) + ",__ck);";
    script += "__w(" + JSON.stringify(errVar) + ",__err);";
    script += "__w(" + JSON.stringify(rcidVar) + ",__rc);";
    browser.callJs(script, 6000);

    var chapterkey = "";
    var error = "";
    var browserRcid = "";
    if (typeof browser.getVariable === "function") {
        try { chapterkey = String(browser.getVariable(keyVar) || "").trim(); } catch (e) {}
        try { error = String(browser.getVariable(errVar) || "").trim(); } catch (e) {}
        try { browserRcid = String(browser.getVariable(rcidVar) || "").trim(); } catch (e) {}
    }
    if (!chapterkey) {
        try {
            var doc = browser.html();
            if (doc) {
                var outNode = doc.select("#stv_ck_out").first();
                var output = outNode ? String(outNode.text() || "").trim() : "";
                if (output.indexOf("__KEY__:") === 0) chapterkey = output.substring(8).trim();
                else if (output.indexOf("__ERR__:") === 0) error = error || output.substring(8).trim();
                if (!browserRcid) {
                    var rcidNode = doc.select("#stv_ck_rcid").first();
                    browserRcid = rcidNode ? String(rcidNode.text() || "").trim() : "";
                }
            }
        } catch (e) {}
    }
    return {
        chapterkey: chapterkey,
        readcontextid: browserRcid || readcontextid,
        error: chapterkey ? "" : (error || "chapterkey empty")
    };
}

// ---- Phase 2: Sign + read chapter ----
function stvMakeSign(params) {
    var keys = [];
    for (var k in params) {
        if (params.hasOwnProperty(k)) keys.push(k);
    }
    keys.sort();
    var sorted = "";
    for (var i = 0; i < keys.length; i++) {
        sorted += keys[i] + "=" + params[keys[i]] + "&";
    }
    return MD5.md5(sorted + STV_SIGN_SALT);
}

function stvReadChapter(base, host, bookId, chapterId, chapterkey, rcid, sign) {
    var url = base + "/?sajax=readchapter"
        + "&h=" + encodeURIComponent(host)
        + "&bookid=" + encodeURIComponent(bookId)
        + "&c=" + encodeURIComponent(chapterId)
        + "&key=" + encodeURIComponent(chapterkey);
    var cookieParts = [];
    if (rcid) cookieParts.push("readcontextid=" + rcid);
    cookieParts.push("mac_tt=true");
    var headers = {
        "User-Agent": STV_UA,
        "Accept": "*/*",
        "x-stv-sign": sign,
        "Referer": base + "/truyen/" + host + "/1/" + bookId + "/" + chapterId + "/",
        "Cookie": cookieParts.join("; ")
    };
    for (var k in STV_APP_HEADERS) {
        if (STV_APP_HEADERS.hasOwnProperty(k)) headers[k] = STV_APP_HEADERS[k];
    }
    var resp = fetch(url, { method: "GET", headers: headers });
    if (!resp || !resp.ok) return null;
    try { return resp.json(); } catch (e) { return null; }
}

// ---- Entry point ----
function execute(url) {
    try { fetch(STV_BASE + "/"); } catch (e) {}
    var match = String(url || "").match(/\/truyen\/([^\/]+)\/\d+\/(\d+)\/(\d+)/);
    if (!match) return Response.error("URL chuong khong hop le");
    var host = match[1];
    var bookId = match[2];
    var chapterId = match[3];
    var lastErr = "";

    for (var bi = 0; bi < STV_BASES.length; bi++) {
        var base = STV_BASES[bi];
        for (var attempt = 0; attempt < 2; attempt++) {
            var chapterkey = "";
            var rcid = "";

            var cached = _stvGrantCache[bookId];
            if (cached && cached.chapterkey && cached.readcontextid) {
                var age = Date.now() - (cached.updatedAt || 0);
                if (age < 1800000) {
                    chapterkey = cached.chapterkey;
                    rcid = cached.readcontextid;
                } else {
                    delete _stvGrantCache[bookId];
                }
            }

            if (!chapterkey) {
                var grantResult = stvFetchGrant(base, host, bookId);
                if (!grantResult.ok) {
                    lastErr = "Khong tai duoc grantcontext";
                    break;
                }
                try {
                    var sc = grantResult.setCookie || "";
                    var m = sc.match(/readcontextid=([^;]+)/i);
                    if (m) rcid = m[1];
                } catch (e) { rcid = ""; }

                if (typeof Engine === "undefined" || !Engine || typeof Engine.newBrowser !== "function") {
                    lastErr = "Engine khong kha dung";
                    break;
                }

                var browser = null;
                try {
                    browser = Engine.newBrowser();
                    if (typeof browser.setUserAgent === "function") browser.setUserAgent(STV_UA);
                    browser.launch(base + "/truyen/" + host + "/1/" + bookId + "/" + chapterId + "/", 12000);

                    var keyResult = stvExtractKey(browser, grantResult.text, rcid);
                    if (!keyResult.chapterkey) {
                        lastErr = keyResult.error || "Khong lay duoc chapterkey";
                        continue;
                    }
                    chapterkey = keyResult.chapterkey;
                    rcid = keyResult.readcontextid || rcid;
                } catch (e) {
                    lastErr = "Engine error: " + (e.message || e);
                    continue;
                } finally {
                    try { if (browser) browser.close(); } catch (e) {}
                }
            }

            var signParams = {
                sajax: "readchapter",
                h: host,
                bookid: bookId,
                c: chapterId,
                key: chapterkey
            };
            var sign = stvMakeSign(signParams);

            var json = stvReadChapter(base, host, bookId, chapterId, chapterkey, rcid, sign);
            if (!json || String(json.code) !== "0") {
                delete _stvGrantCache[bookId];
                lastErr = json ? (json.err || json.info || "API code " + json.code) : "Khong doc duoc readchapter";
                continue;
            }

            _stvGrantCache[bookId] = {
                chapterkey: chapterkey,
                readcontextid: rcid,
                updatedAt: Date.now()
            };

            var raw = String(json.data || "");
            var content = stvCleanChapter(raw);
            if (!content) return Response.error("Da nhan du lieu nhung khong co noi dung");

            return Response.success(content);
        }
    }

    return Response.error(lastErr || "Khong the tai noi dung chuong");
}