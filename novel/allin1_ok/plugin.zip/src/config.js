var BASE_URL = "http://14.225.254.182";
try { if (CONFIG_URL) BASE_URL = CONFIG_URL; } catch (e) { }

var BASE_UA = "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Mobile Safari/537.36";
var ACCEPT_HEADER = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";

// ---- STV grantcontext + readchapter config ----
var STV_SIGN_SALT = "erogh982^%*%^*";
var STV_APP_HEADERS = {
    "x-stv-transport": "app",
    "x-requested-with": "com.sangtacviet.mobilereader"
};
var STV_BASES = ["http://14.225.254.182"];

// Chapter grant cache (in-memory, per session)
var _stvGrantCache = {};

var _sessionDone = false;
function stvEnsureSession() {
    if (_sessionDone) return;
    _sessionDone = true;
    try { fetch(BASE_URL + "/"); } catch (e) {}
}

function cleanText(text) {
    if (!text) return "";
    return String(text).replace(/\\s+/g, " ").trim();
}

function normalizeUrl(url) {
    if (!url) return "";
    url = String(url).trim();
    if (url.indexOf("http") === 0) return url;
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("/") === 0) return BASE_URL + url;
    return BASE_URL + "/" + url;
}

function getSize(list) {
    if (!list) return 0;
    if (typeof list.size === "function") return list.size();
    if (typeof list.length !== "undefined") return list.length;
    return 0;
}

function getElement(list, index) {
    if (!list) return null;
    if (typeof list.get === "function") return list.get(index);
    if (typeof list[index] !== "undefined") return list[index];
    return null;
}

/**
 * Fetch a page as parsed HTML Document.
 * Primary: Engine.newBrowser() (handles JS, cookies, Cloudflare bot detection).
 * Fallback: direct fetch() with proper headers.
 */
function fetchDoc(url, timeout) {
    try {
        if (typeof Engine !== "undefined" && Engine && typeof Engine.newBrowser === "function") {
            var browser = Engine.newBrowser();
            browser.setUserAgent(BASE_UA);
            var doc = browser.launch(url, timeout || 15000);
            if (doc) {
                var result = browser.html();
                browser.close();
                return result;
            }
            browser.close();
        }
    } catch (e) { }

    var response = fetch(url, {
        headers: {
            "User-Agent": BASE_UA,
            "Accept": ACCEPT_HEADER
        }
    });
    if (response && response.ok) {
        return response.html();
    }
    return null;
}

/**
 * Fetch raw text response (used for JSON API responses).
 */
function fetchText(url, referer) {
    var headers = {
        "User-Agent": BASE_UA,
        "Accept": "text/plain,text/html,application/json,*/*;q=0.8"
    };
    if (referer) headers["Referer"] = referer;
    var response = fetch(url, { headers: headers });
    if (response && response.ok) {
        return response.text();
    }
    return "";
}

/**
 * Browser-based fetch with wait for a CSS selector to appear.
 * Used for chapter pages with AJAX-loaded content.
 */
function fetchDocWithWait(url, selector, timeout) {
    try {
        if (typeof Engine !== "undefined" && Engine && typeof Engine.newBrowser === "function") {
            var browser = Engine.newBrowser();
            browser.setUserAgent(BASE_UA);
            var doc = browser.launch(url, timeout || 15000);
            if (!doc) { browser.close(); return null; }

            if (selector) {
                var elapsed = 0;
                var interval = 500;
                var maxWait = timeout || 12000;
                var lastLen = 0;
                while (elapsed < maxWait) {
                    var found = doc.select(selector);
                    var curLen = found.size ? found.size() : (found.length || 0);
                    if (curLen > 0) {
                        var text = cleanText(found.first().text());
                        if (text.length > 50 && curLen === lastLen) break;
                        lastLen = curLen;
                    }
                    sleep(interval);
                    elapsed += interval;
                    doc = browser.html();
                }
            }

            var result = browser.html();
            browser.close();
            return result;
        }
    } catch (e) { }

    return fetchDoc(url, timeout || 10000);
}

/**
 * STV API endpoint (returns HTML fragment).
 * Path: /index.php?ajax=... or /index.php?ngmar=...&sajax=...
 */
function fetchApi(path) {
    var apiUrl = path.indexOf("http") === 0 ? path : BASE_URL + path;
    var response = fetch(apiUrl, {
        headers: {
            "User-Agent": BASE_UA,
            "Accept": ACCEPT_HEADER
        }
    });
    if (response && response.ok) {
        return response.html();
    }
    return null;
}

/**
 * Parse chapter list from API response.
 * Server returns JSON envelope: {"code":1,"data":"<plain text rows>"} or plain text.
 * Inside data: rows separated by -//- , fields by -/-.
 * Row: vipFlag-/-chapId-/-chapterName
 */
function parseChapterListJson(jsonText, bookId, source) {
    var chapters = [];
    if (!jsonText || !bookId || !source) return chapters;

    var data = jsonText;
    try {
        var obj = JSON.parse(jsonText);
        if (obj && obj.code === 1 && obj.data) {
            data = obj.data;
        }
        // Else: not JSON envelope — assume plain text rows
    } catch (e) {
        // Plain text response — use as-is
    }

    try {
        var items = data.split("-//-");
        var seen = {};

        for (var i = 0; i < items.length; i++) {
            var item = items[i].trim();
            if (!item) continue;

            var parts = item.split("-/-");
            if (parts.length < 3) continue;

            var chapId = parts[1].trim();
            var rawName = parts[2] || "";
            // Clean: take only first line before any \n
            var newlineIdx = rawName.indexOf("\\n");
            var name = newlineIdx >= 0 ? rawName.substring(0, newlineIdx) : rawName;
            name = cleanText(name);
            // Remove trailing separators
            var dashSepIdx = name.indexOf("-//");
            if (dashSepIdx >= 0) name = name.substring(0, dashSepIdx);
            name = name.trim();

            if (!chapId || !name) continue;

            var chapUrl = BASE_URL + "/truyen/" + source + "/1/" + bookId + "/" + chapId + "/";
            if (seen[chapUrl]) continue;
            seen[chapUrl] = true;

            // Remove "Chương XX::" prefix noise
            name = name.replace(/^::\\s*/, "").replace(/^:\\s*:\\s*/, "");

            chapters.push({
                name: name,
                url: chapUrl,
                host: BASE_URL
            });
        }
    } catch (e) { }

    return chapters;
}

/**
 * Parse story list items from HTML (used by search/gen pages).
 * Cards: a.nb.cap or a.nb or a.booksearch with href=/truyen/...
 */
function parseApiList(doc) {
    var list = [];
    if (!doc) return list;

    var cards = doc.select("a.nb.cap[href*='/truyen/']");
    if (cards.size() === 0) cards = doc.select("a.nb[href*='/truyen/']");
    if (cards.size() === 0) cards = doc.select("a.booksearch[href*='/truyen/']");
    if (cards.size() === 0) cards = doc.select("a[href*='/truyen/']");

    var seen = {};
    for (var i = 0; i < getSize(cards); i++) {
        var card = getElement(cards, i);
        if (!card) continue;

        var href = card.attr("href") || "";
        if (!href || href === "/truyen/") continue;
        href = normalizeUrl(href);
        if (seen[href]) continue;
        seen[href] = true;

        // Title
        var titleEl = card.select("b.searchbooktitle").first();
        if (!titleEl) titleEl = card.select("b").first();
        if (!titleEl) titleEl = card.select("span, div").first();
        var name = titleEl ? cleanText(titleEl.text()) : "";
        if (!name || name.length < 2) continue;
        if (name.indexOf("/truyen/") >= 0) continue;

        // Cover
        var imgEl = card.select("img").first();
        var cover = "";
        if (imgEl) {
            cover = imgEl.attr("src") || imgEl.attr("data-src") || "";
            if (cover && cover.indexOf("http") !== 0) cover = normalizeUrl(cover);
        }

        // Author
        var authorEl = card.select("span.searchbookauthor").first();
        var author = authorEl ? cleanText(authorEl.text()) : "";

        // Description
        var descEls = card.select("span.lhr");
        var description = "";
        for (var j = 0; j < getSize(descEls); j++) {
            var el = getElement(descEls, j);
            if (!el) continue;
            var style = el.attr("style") || "";
            if (style.indexOf("font-size:12px") >= 0) {
                var text = cleanText(el.text());
                if (text.length > 30) {
                    description = text.substring(0, 200);
                    break;
                }
            }
        }

        var desc = (author ? author + " · " : "") + (description ? description.substring(0, 80) : "");

        list.push({
            name: name || "Unknown",
            link: href,
            cover: cover,
            description: desc,
            host: BASE_URL
        });
    }

    return list;
}

/**
 * Parse story items from generic list pages (a.cap cards).
 */
function parseListItems(doc) {
    var list = [];
    if (!doc) return list;

    var cards = doc.select("a.cap[href*='/truyen/']");
    if (cards.size() === 0) cards = doc.select("a[class*=cap][href*='/truyen/']");

    var seen = {};
    for (var i = 0; i < getSize(cards); i++) {
        var card = getElement(cards, i);
        if (!card) continue;

        var href = card.attr("href") || "";
        if (!href || href === "/truyen/") continue;
        href = normalizeUrl(href);
        if (seen[href]) continue;
        seen[href] = true;

        var titleEl = card.select("b").first();
        if (!titleEl) titleEl = card.select("span, div").first();
        var name = cleanText(titleEl ? titleEl.text() : card.text());
        if (!name || name.length < 2) continue;
        if (name.indexOf("/truyen/") >= 0) continue;

        var imgEl = card.select("img").first();
        var cover = "";
        if (imgEl) {
            cover = imgEl.attr("src") || imgEl.attr("data-src") || "";
            if (cover && cover.indexOf("http") !== 0) cover = normalizeUrl(cover);
        }

        var descEl = card.select("span[class*=author], span[class*=chap], span[class*=desc]").first();
        var description = descEl ? cleanText(descEl.text()) : "";

        list.push({
            name: name,
            link: href,
            cover: cover,
            description: description,
            host: BASE_URL
        });
    }

    return list;
}

/**
 * Build STV API URL with search params (used by home, genre, search).
 */
function buildApiPath(params) {
    var p = [];
    p.push("find=" + encodeURIComponent(params.find || ""));
    p.push("minc=" + encodeURIComponent(params.minc || "0"));
    if (params.sort) p.push("sort=" + encodeURIComponent(params.sort));
    if (params.tag) p.push("tag=" + encodeURIComponent(params.tag));
    if (params.findinname) p.push("findinname=" + encodeURIComponent(params.findinname));
    return "/io/searchtp/searchBooks?" + p.join("&");
}

/**
 * Parse stvapi:// protocol into query params.
 */
function parseApiInput(raw) {
    if (raw.indexOf("stvapi://") === 0) {
        var qPos = raw.indexOf("?");
        var qs = qPos >= 0 ? raw.substring(qPos + 1) : "";
        var pairs = qs.split("&");
        var params = {};
        for (var i = 0; i < pairs.length; i++) {
            var kv = pairs[i].split("=");
            if (kv.length >= 2) {
                params[decodeURIComponent(kv[0])] = decodeURIComponent(kv.slice(1).join("="));
            }
        }
        return params;
    }
    return { find: "", findinname: raw, minc: "0", sort: "update", tag: "" };
}

/**
 * Encode params as stvapi:// protocol string.
 */
function apiInput(params) {
    return "stvapi://?" + Object.keys(params).map(function (k) {
        return encodeURIComponent(k) + "=" + encodeURIComponent(params[k]);
    }).join("&");
}