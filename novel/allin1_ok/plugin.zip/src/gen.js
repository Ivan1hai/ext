load("config.js");

function execute(input, page) {
    if (!input) return Response.success([]);

    var pageIndex = parseInt(page || "0", 10);

    // stvapi:// protocol
    if (input.indexOf("stvapi://") === 0) {
        var qPos = input.indexOf("?");
        var qs = qPos >= 0 ? input.substring(qPos + 1) : "";
        var pairs = qs.split("&");
        var params = {};
        for (var i = 0; i < pairs.length; i++) {
            var kv = pairs[i].split("=");
            if (kv.length >= 2) {
                params[decodeURIComponent(kv[0])] = decodeURIComponent(kv.slice(1).join("="));
            }
        }

        var path = "/io/searchtp/searchBooks?find=" + encodeURIComponent(params.find || "")
            + "&minc=" + encodeURIComponent(params.minc || "0");
        if (params.sort) path += "&sort=" + encodeURIComponent(params.sort);
        if (params.tag) path += "&tag=" + encodeURIComponent(params.tag);
        if (params.findinname) path += "&findinname=" + encodeURIComponent(params.findinname);
        if (pageIndex > 0) path += "&p=" + pageIndex;

        var doc = fetchApi(path);
        if (!doc) return Response.success([]);

        var list = parseApiList(doc);
        var next = list.length >= 48 ? String(pageIndex + 1) : "";
        return Response.success(list, next);
    }

    // Direct URL
    var url = normalizeUrl(input);
    var doc = fetchDoc(url, 12000);
    if (!doc) return Response.success([]);

    var list = parseListItems(doc);
    return Response.success(list, "");
}